# Kensei 1.2 — Enemy Combat Archetypes

Built directly on Ronin 1.1.

## New combat behaviors
- Fox Shades, Tengu Scouts, Yomi Wraiths and Reed Specters now use a ranged spirit archetype instead of sharing the same melee-only chase loop.
- Ranged yōkai maintain preferred spacing, strafe around hunters and retreat if pressured.
- Spirit projectiles use a visible travel arc plus a ground impact telegraph before server-authoritative AoE damage.
- Projectile cadence scales independently from melee attack slots, preserving readable co-op pressure.
- Melee yōkai keep Ronin 1.1 crowd separation and two-attacker slot control.

The projectile is intentionally telegraphed and avoidable: target position is sampled at cast start, so a hunter can dodge out before impact.
