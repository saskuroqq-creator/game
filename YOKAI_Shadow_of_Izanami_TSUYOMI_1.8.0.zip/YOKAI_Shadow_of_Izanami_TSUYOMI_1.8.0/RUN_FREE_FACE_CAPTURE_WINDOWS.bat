@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Usage: RUN_FREE_FACE_CAPTURE_WINDOWS.bat path\to\face_landmarker.task
  echo Install dependencies first: py -m pip install -r tools\requirements_face_capture.txt
  exit /b 1
)
py tools\mediapipe_face_sender.py --model "%~1"
