# Original IP / provenance boundary

YOKAI: Shadows of Izanami keeps project-original work separate from third-party material.

## Project-original layer

The repository's game-specific source code, original narrative text, combat/AI/network implementation, UI implementation, balancing/configuration, procedural world geometry, and project-authored modifications are treated as project-original material to the extent those elements are protectable under applicable law.

## Third-party boundary

Any third-party asset remains governed by its original license. CC0/public-domain source assets are non-exclusive and are never represented as originally authored by YOKAI. Optional authoring tools and external libraries retain their own licenses.

## Audit trail

Before bundling any external binary asset, record provider, exact source URL, license, verification date, destination, and role in `ASSET_PROVENANCE_LEDGER.csv` and `assets/third_party/ASSET_MANIFEST.json`. Keep source screenshots/receipts separately for release archives when practical.
