# SHINRA 1.6.0

Mobile production and provenance hardening pass.

- Mobile renderer becomes the default with OpenGL Compatibility fallback.
- Four runtime quality tiers with conservative adaptive up/down shifting.
- FSR-based internal-resolution profiles on Vulkan renderer.
- Decorative vegetation, rocks and grass use MultiMesh batching.
- Distant/decorative geometry receives visibility ranges and avoids unnecessary dynamic shadows.
- Glow reserved for ULTRA only; primary moon shadow distance is tier-dependent.
- In-game Graphics button cycles quality tier.
- Added proprietary-project notice, third-party notices, and an asset provenance ledger.
- Third-party CC0 material is explicitly treated as non-exclusive; project-original work remains separately identifiable.
- Android export metadata updated to 1.6.0-alpha / versionCode 160.
