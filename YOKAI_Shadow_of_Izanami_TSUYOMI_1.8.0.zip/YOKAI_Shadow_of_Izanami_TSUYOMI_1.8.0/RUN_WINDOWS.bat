@echo off
setlocal
set "GODOT="
for %%G in (godot.exe godot4.exe) do (
  where %%G >nul 2>nul && set "GODOT=%%G"
)
if exist "%~dp0Godot_v4.7.2-stable_win64.exe" set "GODOT=%~dp0Godot_v4.7.2-stable_win64.exe"
if "%GODOT%"=="" (
  echo Godot 4.7.x not found. Install Godot or put Godot_v4.7.2-stable_win64.exe in this folder.
  pause
  exit /b 1
)
"%GODOT%" --editor --path "%~dp0"
