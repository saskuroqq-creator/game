## 1.4.0-alpha-boss-signatures
- Added distinct phase-3 signature attacks for every story boss.
- Added targeted multi-wave spirit barrages and boss signature telegraph FX.
- Kept special damage server-authoritative and avoidable through movement/dodge.

## 1.3.0-alpha-visual-combat
- Added lock-on reticle and floating combat damage feedback.
- Added samurai silhouette upgrade for the procedural fallback.
- Added rigged model socket and animation bridge with authored-animation aliases.
- Added asset pipeline documentation for GLB/TSCN character replacement.

# YOKAI changelog

## 1.2.0-alpha — Kensei
- Ranged combat archetypes for Fox Shade, Tengu Scout, Yomi Wraith and Reed Specter.
- Telegraphable server-authoritative spirit bolts with AoE impact.
- Ranged spacing, strafing and retreat behavior.

## 1.1.0-alpha — Ronin
- Combat input buffering and sprint.
- Target cycling and lock-on camera polish.
- Frontal guard/parry rules.
- Heavy attack forward commitment.
- Enemy separation/orbit steering and melee attack slots.
- Mobile sprint control and updated HUD instructions.

# Changelog

## v0.2.0 — Hunter Build
- Expanded seamless prototype world from 240×240 to 320×320.
- Added Drowned Shrine (Lv.24+) and Bamboo Hollow (Lv.28+).
- Added Nure-Onna and Namahage Lord story bosses; story now has 8 chapters.
- Bosses now have three combat phases and telegraphed area attacks.
- Added lock-on targeting for third-person combat.
- Replaced instant death with co-op DOWNED / REVIVE / bleedout flow.
- Added persistent inventory, item rarity, equipment slots and Gear Score.
- Added boss-specific gear drops and world relic caches.
- Added weapon rarity glow and real equipment stat bonuses.
- Added side hunts with persistent progress and rewards.
- Added NPCs Hina, Gensai and Mio to Hoshikawa Village.
- Skill system now supports skill levels 1–5.
- Added Raijin Break as a fourth combat skill.
- Added mobile LOCK / USE / Skill 4 / OFUDA buttons.
- Shrines now heal the player and set the respawn checkpoint.
- Healing Ofuda is now a usable combat consumable.
- Added boss HP UI, lock target UI, gear display, side-hunt tracker and loot toast.
- Expanded Hunter Status screen with equipment, inventory and quests.

## v0.1.0 — Open World / Progression
- Seamless six-zone Hoshikawa map.
- Five story bosses and persistent chapters.
- Level/rank/stat/skill progression and saves.
- Three active skills and 3-hit combo.
- Minimap and open-world boss warnings.

## v0.0.1 — Co-op Core
- Third-person movement, mobile controls and LAN host/join prototype.

## v0.3.0 — Ascendant Build
- Added Hunter Resonance: nearby co-op allies increase damage up to +12%.
- Added cross-player Resonance Strikes: alternating attackers trigger bonus damage and stagger.
- Added enemy stagger meter and STAGGER BREAK windows for coordinated burst damage.
- Added Perfect Dodge timing window that restores Spirit and fires a local counter-flash.
- Reworked third-person camera feel with shoulder framing, dynamic FOV and combat/dodge kick.
- Added stronger boss-threat presentation and a dynamic danger vignette in phase combat.
- Added Drowned Shrine water surfaces, Bamboo Hollow bamboo dressing and spirit lights across all regions.
- Rebalanced world lighting, fog, tonemapping and color response for a more cinematic presentation.
- Tightened camera distance and combat framing while preserving mobile controls and LAN co-op authority.

## v0.4.0 — Shogun Visual Build
- Added hold-to-guard with Spirit drain and Guard Break recovery.
- Added 180 ms Perfect Parry window; successful parries restore Spirit and inflict heavy stagger.
- Added Spirit Heavy Attack with unique wind-up, camera impulse and high stagger damage.
- Reworked enemy melee attacks from instant hits to readable server-authoritative wind-ups.
- Added three boss telegraph patterns: Cursed Pulse, Cleaving Howl and Hollow Ring.
- Extended stagger so heavy attacks, skills, perfect dodges and parries create coordinated burst windows.
- Reworked revive into a 1.85 second hold channel that slows the rescuer and can be abandoned under pressure.
- Added party HUD for up to four hunters with live HP/downed state.
- Added world-space lock-on reticle and combat-state feedback for guard, parry, revive and heavy attacks.
- Added zone-adaptive atmosphere grading: fog, ambient color, moon light and boss-pressure lighting now shift dynamically.
- Added desktop Guard (V) and Heavy Attack (G) inputs plus matching mobile controls.
- Hardened host-side combat RPC validation by clamping client-supplied hit parameters and validating revive ownership.
- Enabled 3D MSAA, screen-space anti-aliasing and occlusion-culling defaults where supported.

## SHINRA 1.6.0 — mobile production + provenance hardening
- Switched default renderer to Godot Mobile with OpenGL Compatibility fallback.
- Added Performance/Balanced/High/Ultra quality profiles with FSR/internal resolution scaling, MSAA/SMAA selection, shadow distance and adaptive guard.
- Ultra now renders at native 3D scale; lower tiers preserve image quality through controlled upscaling.
- Batched procedural trees, rocks and grass using MultiMesh and added tier-scaled visibility ranges.
- Disabled unnecessary decorative shadows on ground, foliage, water, distant mountains and spirit-orb geometry.
- Added tier-aware color grading and reserved expensive glow for Ultra.
- Replaced box-like sword flash with curved emissive ribbon geometry whose tessellation follows the device quality tier.
- Added fail-closed third-party binary license audit, provenance ledger and download receipt support.
- Added project-original license boundary, release legal checklist and SHA-256 source snapshot manifest.
- Updated Android version metadata to 1.6.0-alpha / 160.

## KAGE 1.7.0 — mobile fidelity budget + authored-art optimization
- Added global transient VFX budgeting by quality tier.
- Added cached enemy target/separation/attack-slot queries and distance-aware state replication.
- Added batched bamboo MultiMeshes and mobile vertex wind for grass/bamboo/tree crowns.
- Added distance-faded spirit and lantern lighting with per-tier energy policy.
- Added runtime FSR sharpness, anisotropic filtering and global mesh LOD bias profiles.
- Added authored GLB/GLTF mobile optimizer for material filtering, LOD and shadow policy.
- Android export metadata updated to 1.7.0-alpha / versionCode 170.

## TSUYOMI 1.8.0 — visual production pass
- Added procedural night-sky IBL/reflection response and a low-cost distant silhouette/moon layer.
- Added mobile wet-surface PBR shader and quality-scaled authored-material polish.
- Added Ultra-only practical DOF plus refined lock-on/sprint camera framing.
- Added additive sword ribbons, budgeted impact shock rings and Ultra micro-light hit flashes.
- Kept all new cosmetic layers under existing mobile quality/VFX budgets.
- Android metadata updated to 1.8.0-alpha / versionCode 180.
