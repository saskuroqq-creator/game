# Complete RC1 — Kagutsuchi

RC1 consolidates the Shogun branch into a campaign-complete systems build.

## New in RC1
- Final Veiled Gate zone and Shadow of Izanami boss.
- Chapter 8 final hunt and Chapter 9 post-game state.
- Legendary Veilbreaker Katana reward.
- Persistent dodge momentum, improved airborne/ground acceleration and landing feedback.
- Animation-synced attack hit timing.
- Procedural sword arcs and hit sparks.
- Original generated combat/ambient audio.
- Smoother enemy pursuit and boss strafing.
- Rotating boss special patterns instead of a fixed deterministic pattern.
- Dynamic 1–4 player enemy health/damage/stagger scaling.
- Collision bodies for trees, rocks and boundary mountains.
- Final-zone atmosphere and audio ambience.
- Android export metadata updated for 1.0.0-rc1.

## Inherited from Shogun v0.4.0
Guard / Perfect Parry, Spirit Heavy, attack windups, radial/cone/ring boss telegraphs, hold-to-revive, four-player HUD, lock-on reticle, dynamic fog/lighting, Hunter Resonance, stagger and Perfect Dodge.
