@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 tools\fetch_cc0_art.py
) else (
  python tools\fetch_cc0_art.py
)
echo.
echo If the downloads completed, restart Godot once so imported GLBs are indexed.
pause
