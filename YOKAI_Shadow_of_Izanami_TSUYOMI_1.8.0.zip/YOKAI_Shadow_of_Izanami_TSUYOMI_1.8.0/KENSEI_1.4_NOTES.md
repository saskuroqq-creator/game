# KENSEI 1.4 — Boss Signature Combat

Built on KENSEI 1.3.

## Added
- Phase-3 bosses now alternate the generic telegraphed special with a boss-specific signature attack.
- Jorogumo: Silken Grave targeted barrage.
- Karasu Tengu: Tempest Feathers fast spirit barrage.
- Gashadokuro: Bone Earthquake expanding danger ring.
- Orochi Wraith: Orochi Devour long cone punish.
- Nure-Onna: Drowned Reflection multi-wave pools.
- Namahage Lord: War Drum Charge forward pressure.
- Izanami Shadow: Mirror of Izanami barrage followed by a ring punish.
- Signature moves preserve server-authoritative damage and use the existing dodge/parry/co-op model.

The attacks deliberately snapshot target positions before impact so the player can read, move, dodge and counter instead of taking unavoidable tracking damage.
