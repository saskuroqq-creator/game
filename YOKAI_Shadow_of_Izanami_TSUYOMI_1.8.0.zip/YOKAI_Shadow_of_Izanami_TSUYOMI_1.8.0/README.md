# YOKAI: Shadows of Izanami — TSUYOMI 1.8

**Current visual-production branch.** See `TSUYOMI_1.8_NOTES.md`, `MOBILE_PRODUCTION_GUIDE.md`, `LICENSE_PROJECT_PROPRIETARY.txt`, and `ASSET_PROVENANCE_LEDGER.csv`.

# YOKAI: Shadows of Izanami — Ronin 1.1

> Current development branch: `1.1.0-alpha-ronin`

# YŌKAI: Shadows of Izanami — Complete RC1

**Version:** 1.0.0-rc1-kagutsuchi  
**Engine target:** Godot 4.7.x  
**Platforms:** Windows/Linux editor test, Android export preset included  
**Genre:** third-person folklore action RPG, 1–4 player LAN co-op

This package is the consolidated release-candidate branch built from the Shogun v0.4.0 project. It is a complete playable systems build using original procedural geometry, UI and generated audio. It deliberately contains no copied commercial game assets.

## Playable campaign
Explore Hoshikawa Province, accept side hunts, defeat yōkai and story bosses, gain XP and equipment, allocate stats and skill points, raise Gear Score, and complete the Black Moon storyline through the Veiled Gate.

### Zones
- Hoshikawa Village
- Kitsune Forest
- Tengu Ridge
- Yomi Marsh
- Oni Highlands
- Moonfall Shrine
- Drowned Shrine
- Bamboo Hollow
- Veiled Gate — final hunt

### Story bosses
Akagane Oni → Jorōgumo → Karasu-Tengu → Gashadokuro → Orochi Wraith → Nure-Onna → Namahage Lord → **Shadow of Izanami**.

The final boss can drop the Legendary **Veilbreaker Katana**.

## Combat
- three-hit katana combo with animation-synced damage frames
- Spirit Heavy attack
- four active skills
- Guard and Perfect Parry window
- dodge with persistent momentum and Perfect Dodge reward
- lock-on targeting
- stagger / guard-break feedback
- multi-phase bosses with rotating radial, cone and ring telegraphs
- procedural sword arcs, hit sparks, camera kick, handheld vibration and landing feedback

## Co-op
One player hosts on local Wi-Fi or a phone hotspot. Up to three additional hunters can join. Host-authoritative combat, four-player party HUD, DOWNED state, hold-to-revive and party-size enemy scaling are included.

## Progression
Persistent Level, Rank E→S, STR/VIT/AGI/SPI/FOC, stat points, skill points, equipment rarity, stat bonuses, consumables and Gear Score.

## Controls — desktop test
- WASD — move
- RMB drag — camera
- F / LMB — attack
- Space — dodge
- E — jump
- Q — lock-on
- R — interact / hold to revive
- 1 / 2 / 3 / 4 — skills
- 5 — Healing Ofuda
- G — Spirit Heavy
- V — Guard / Perfect Parry timing
- Tab — Hunter Status
- Esc — pause

Touch controls are included for the same actions on Android.

## Audio
RC1 adds original procedurally generated WAV effects for sword swings, impacts, parry, skills, dodge, boss roar and night ambience. These were generated for this project and do not depend on third-party sound packs.

## Running the project
Open the folder in Godot 4.7.x and run `scenes/Main.tscn` (the project main scene is already configured). Convenience launch scripts are included for Windows and Linux.

## Android export
The Android preset is configured to produce:

`build/YOKAI_Shadow_of_Izanami_COMPLETE_1.0_RC1.apk`

A local Android SDK/JDK and Godot export templates are still required to compile/sign the APK. Use `EXPORT_ANDROID_WINDOWS.bat` or `./export_android_linux.sh` after configuring Godot Android export.

## Production-art note
The gameplay architecture and campaign loop are implemented, but the current characters and world use procedural stylized geometry rather than a studio-authored AAA asset library. A commercial art pass would still replace those meshes with authored skeletal characters, motion-captured/keyframed animation, PBR environments, cinematic VFX and professionally mixed music/voice. This RC does not pretend those assets exist.


## Ronin 1.1 controls
- WASD — move
- Shift — sprint
- Space — dodge / perfect dodge window
- F / LMB — light combo (buffered)
- G — Spirit Heavy
- V — guard / perfect parry
- Q — lock-on / unlock
- C — cycle locked target
- 1–4 — skills
- R — interact / revive
- 5 — Healing Ofuda

Mobile has the same core combat actions plus a dedicated Sprint button.
