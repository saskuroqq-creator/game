# Third-party notices — SHINRA 1.6

This build follows a **provenance-first** policy. Third-party files are not silently absorbed into the proprietary project license.

## Default production sources

- **3DAssets.dev** — selected Feudal Japan environment/prop GLB files. Listed source pages state **CC0 1.0**. These files, when downloaded, remain CC0 and non-exclusive.
- **Quaternius** — Universal Animation Library 1/2, Universal Base Characters, selected older CC0 packs. Listed pack pages state **CC0 1.0**.
- **Poly Haven** — selected materials/HDRIs. Poly Haven publishes its assets under **CC0**.
- **LOWPO Samurai Free** — optional interim rig source; source page states **CC0 1.0**.
- **MakeHuman/MPFB output/core graphical assets** — optional realistic human base route. Verify the exact asset category at export time.
- **MediaPipe / OpenSeeFace** — optional authoring tools only; not bundled into the default game runtime. Their software licenses remain separate.
- **CMU Motion Capture Database** — optional mocap source. Do not redistribute or resell raw mocap files as a standalone asset pack; keep a per-clip source record when importing.

## Important ownership rule

CC0/public-domain material is intentionally reusable by anyone. YOKAI may use, modify, combine and ship such material, but the project does **not** claim exclusive authorship of the underlying CC0 source asset. Project-specific modifications and the larger game compilation are tracked separately.

See `ASSET_PROVENANCE_LEDGER.csv` and `assets/third_party/ASSET_MANIFEST.json` for the auditable record.
