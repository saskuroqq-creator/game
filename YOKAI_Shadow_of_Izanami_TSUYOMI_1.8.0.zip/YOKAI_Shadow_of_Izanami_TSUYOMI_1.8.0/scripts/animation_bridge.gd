extends Node

## Authored animation bridge with fuzzy semantic matching.
## Designed to tolerate Quaternius, MakeHuman-retargeted and Mixamo-style clip names
## without hard-wiring gameplay code to a specific art pack.

@export var model_socket_path: NodePath = NodePath("../Visuals/ModelSocket")
@export var hide_placeholder_when_authored_model_present := false

var animation_player: AnimationPlayer = null
var model_socket: Node3D = null
var _normalized_lookup: Dictionary = {}
var _semantic_cache: Dictionary = {}

const SEMANTIC_ALIASES := {
    "idle": ["idle", "combatidle", "breathidle", "standingidle", "idleloops"],
    "run": ["run", "running", "jog", "jogforward", "runforward"],
    "sprint": ["sprint", "sprinting", "fastrun", "runfast"],
    "walk": ["walk", "walking", "walkforward"],
    "dodge": ["dodge", "roll", "combatroll", "evade", "sidestep"],
    "attack1": ["attack1", "lightattack1", "meleeattack1", "swordattack1", "combo1", "slash1"],
    "attack2": ["attack2", "lightattack2", "meleeattack2", "swordattack2", "combo2", "slash2"],
    "attack3": ["attack3", "lightattack3", "meleeattack3", "swordattack3", "combo3", "slash3"],
    "heavyattack": ["heavyattack", "attackheavy", "strongattack", "chargedattack", "heavyslash"],
    "guard": ["guard", "block", "guardraise", "blocking", "defend"],
    "parry": ["parry", "deflect", "guardcounter", "counter", "parryattack"],
    "skill": ["skill", "cast", "spellcast", "special", "ability"],
    "death": ["death", "die", "dying", "knockdown", "downed", "fallbackdeath"],
    "revive": ["revive", "standup", "getup", "recover", "rise"],
    "jump": ["jump", "jumpstart", "takeoff"],
    "fall": ["fall", "falling", "airborne"],
    "land": ["land", "landing", "jumpend"]
}

func _ready() -> void:
    model_socket = get_node_or_null(model_socket_path) as Node3D
    call_deferred("_resolve_animation_player")

func _resolve_animation_player() -> void:
    animation_player = null
    _normalized_lookup.clear()
    _semantic_cache.clear()
    if model_socket == null:
        model_socket = get_node_or_null(model_socket_path) as Node3D
    if model_socket == null:
        return
    animation_player = _find_animation_player(model_socket)
    if animation_player != null:
        _build_lookup()
    if hide_placeholder_when_authored_model_present and animation_player != null:
        _set_placeholder_visible(false)

func refresh() -> void:
    _resolve_animation_player()

func has_authored_animation_player() -> bool:
    return animation_player != null and is_instance_valid(animation_player)

func play_first(candidates: Array[String], speed: float = 1.0, blend: float = 0.08) -> bool:
    if not has_authored_animation_player():
        _resolve_animation_player()
    if animation_player == null:
        return false

    # 1) exact names remain the safest / cheapest path.
    for anim_name in candidates:
        if animation_player.has_animation(anim_name):
            return _play(anim_name, speed, blend)

    # 2) normalize engine/exporter naming differences.
    for anim_name in candidates:
        var normalized := _normalize(anim_name)
        if _normalized_lookup.has(normalized):
            return _play(String(_normalized_lookup[normalized]), speed, blend)

    # 3) semantic aliases + constrained fuzzy match.
    for anim_name in candidates:
        var resolved := _resolve_semantic(anim_name)
        if resolved != "":
            return _play(resolved, speed, blend)
    return false

func available_animations() -> Array[String]:
    var result: Array[String] = []
    if not has_authored_animation_player():
        _resolve_animation_player()
    if animation_player == null:
        return result
    for name in animation_player.get_animation_list():
        result.append(String(name))
    return result

func _play(anim_name: String, speed: float, blend: float) -> bool:
    if animation_player == null or not animation_player.has_animation(anim_name):
        return false
    animation_player.speed_scale = speed
    animation_player.play(anim_name, blend)
    return true

func _build_lookup() -> void:
    if animation_player == null:
        return
    for raw_name in animation_player.get_animation_list():
        var name := String(raw_name)
        var normalized := _normalize(name)
        if normalized != "" and not _normalized_lookup.has(normalized):
            _normalized_lookup[normalized] = name

func _resolve_semantic(candidate: String) -> String:
    var candidate_norm := _normalize(candidate)
    if _semantic_cache.has(candidate_norm):
        return String(_semantic_cache[candidate_norm])

    var aliases: Array[String] = []
    aliases.append(candidate_norm)
    for semantic in SEMANTIC_ALIASES.keys():
        var semantic_norm := _normalize(String(semantic))
        var entries: Array = SEMANTIC_ALIASES[semantic]
        if candidate_norm == semantic_norm or candidate_norm in entries:
            for alias in entries:
                aliases.append(String(alias))

    var best_name := ""
    var best_score := 0
    for normalized_key in _normalized_lookup.keys():
        var key := String(normalized_key)
        for alias in aliases:
            var score := _match_score(key, alias)
            if score > best_score:
                best_score = score
                best_name = String(_normalized_lookup[key])
    # Avoid surprising mappings: weak substring overlap is worse than fallback art.
    if best_score < 62:
        best_name = ""
    _semantic_cache[candidate_norm] = best_name
    return best_name

func _match_score(name: String, alias: String) -> int:
    if name == alias:
        return 100
    if name.ends_with(alias) or name.begins_with(alias):
        return 88
    if name.contains(alias):
        return 76
    if alias.contains(name) and name.length() >= 5:
        return 68
    # Keep fuzzy matching conservative; weak guesses are worse than fallback art.
    if abs(name.length() - alias.length()) <= 2 and name.left(mini(name.length(), 5)) == alias.left(mini(alias.length(), 5)):
        return 62
    return 0

func _normalize(value: String) -> String:
    var out := value.to_lower()
    # Common exporter prefixes and separators.
    for prefix in ["mixamo.com|", "mixamorig:", "armature|", "rig|", "animation|"]:
        out = out.replace(prefix, "")
    for char in [" ", "_", "-", ".", ":", "|", "/", "\\", "(", ")", "[", "]"]:
        out = out.replace(char, "")
    out = out.replace("01", "1").replace("02", "2").replace("03", "3").replace("04", "4")
    return out

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node as AnimationPlayer
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found != null:
            return found
    return null

func _set_placeholder_visible(value: bool) -> void:
    var visuals := get_node_or_null("../Visuals")
    if visuals == null:
        return
    for child in visuals.get_children():
        if child == model_socket or child.name == "SwordPivot":
            continue
        if child is VisualInstance3D:
            (child as VisualInstance3D).visible = value
