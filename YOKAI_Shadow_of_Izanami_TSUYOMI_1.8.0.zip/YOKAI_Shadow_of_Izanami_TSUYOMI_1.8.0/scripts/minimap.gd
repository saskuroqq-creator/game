extends Control

@export var world_extent := 115.0

func _process(_delta: float) -> void:
    queue_redraw()

func _draw() -> void:
    var center := size * 0.5
    var radius := minf(size.x, size.y) * 0.47
    draw_circle(center, radius, Color(0.015, 0.02, 0.035, 0.86))
    draw_arc(center, radius, 0.0, TAU, 64, Color(0.7, 0.16, 0.18, 0.9), 2.0)
    _marker(Vector3(0,0,0), Color(0.9,0.85,0.75), 4.0)
    _marker(Vector3(-62,0,-42), Color(0.9,0.35,0.75), 4.0)
    _marker(Vector3(55,0,-66), Color(0.5,0.75,1.0), 4.0)
    _marker(Vector3(72,0,30), Color(0.5,0.9,0.65), 4.0)
    _marker(Vector3(18,0,76), Color(1.0,0.35,0.25), 4.0)
    _marker(Vector3(0,0,-102), Color(0.75,0.25,1.0), 5.0)
    var player := _local_player()
    if player != null:
        var p := _to_map(player.global_position)
        draw_circle(p, 5.0, Color(0.25,0.75,1.0,1.0))
        var dir := -player.global_transform.basis.z
        draw_line(p, p + Vector2(dir.x, dir.z).normalized() * 11.0, Color.WHITE, 2.0)

func _marker(pos: Vector3, color: Color, r: float) -> void:
    draw_circle(_to_map(pos), r, color)

func _to_map(pos: Vector3) -> Vector2:
    var center := size * 0.5
    var scale := minf(size.x, size.y) * 0.45 / world_extent
    return center + Vector2(pos.x, pos.z) * scale

func _local_player() -> Node3D:
    for p in get_tree().get_nodes_in_group("players"):
        if p.is_multiplayer_authority():
            return p
    return null
