extends CharacterBody3D

const SFX_SWING = preload("res://audio/sword_swing.wav")
const SFX_IMPACT = preload("res://audio/impact.wav")
const SFX_PARRY = preload("res://audio/parry.wav")
const SFX_SKILL = preload("res://audio/skill_cast.wav")
const SFX_DODGE = preload("res://audio/dodge.wav")

signal local_hud_changed
signal level_fx(level: int)

@export var move_speed := 5.8
@export var acceleration := 20.0
@export var gravity := 24.0
@export var dodge_speed := 12.5
@export var sprint_multiplier := 1.38
@export var sprint_spirit_per_second := 5.5
@export var attack_buffer_window := 0.18

var health: int = 100
var spirit_energy: float = 100.0
var dodge_time := 0.0
var attack_cooldown := 0.0
var skill_1_cd := 0.0
var skill_2_cd := 0.0
var skill_3_cd := 0.0
var skill_4_cd := 0.0
var camera_yaw := 0.0
var camera_pitch := -0.18
var combo_step := 0
var combo_reset := 0.0
var downed := false
var bleedout_remaining := 0.0
var lock_on_target: Node3D = null
var anim_time := 0.0
var checkpoint_position := Vector3(0, 0.3, 8)
var camera_kick := 0.0
var camera_kick_x := 0.0
var combat_focus := 0.0
var resonance_strength := 0.0
var perfect_dodge_window := 0.0
var guard_active := false
var parry_window := 0.0
var guard_break_time := 0.0
var heavy_attack_cd := 0.0
var revive_progress := 0.0
var revive_target_name := ""
var combat_message := ""
var combat_message_time := 0.0
var dodge_direction := Vector3.ZERO
var landing_kick := 0.0
var previous_on_floor := true
var visual_speed := 0.0
var attack_buffer_time := 0.0
var sprinting := false
var target_cycle_cooldown := 0.0
var camera_attributes: CameraAttributesPractical
var camera_motion_phase := 0.0

# Replicated combat profile. Authority owns these values.
var profile_level := 1
var profile_strength := 5
var profile_vitality := 5
var profile_agility := 5
var profile_spirit := 5
var profile_focus := 5
var profile_rank := "E"
var profile_gear_score := 0
var profile_gear_attack := 0
var profile_gear_hp := 0
var profile_gear_spirit := 0
var profile_gear_crit := 0.0

@onready var camera_rig: Node3D = $CameraRig
@onready var spring_arm: SpringArm3D = $CameraRig/SpringArm3D
@onready var camera: Camera3D = $CameraRig/SpringArm3D/Camera3D
@onready var visuals: Node3D = $Visuals
@onready var torso: MeshInstance3D = $Visuals/Torso
@onready var coat: MeshInstance3D = $Visuals/Coat
@onready var arm_l: MeshInstance3D = $Visuals/ArmL
@onready var arm_r: MeshInstance3D = $Visuals/ArmR
@onready var leg_l: MeshInstance3D = $Visuals/LegL
@onready var leg_r: MeshInstance3D = $Visuals/LegR
@onready var sword_pivot: Node3D = $Visuals/SwordPivot
@onready var blade: MeshInstance3D = $Visuals/SwordPivot/Blade
@onready var attack_flash: MeshInstance3D = $AttackFlash
@onready var skill_flash: MeshInstance3D = $SkillFlash
@onready var aura: MeshInstance3D = $Aura
@onready var hp_label: Label3D = $HPLabel
@onready var lock_marker: Label3D = $LockMarker
@onready var animation_bridge = $AnimationBridge
@onready var facial_bridge = $FacialBlendshapeBridge

var face_expression_token := 0

func _ready() -> void:
    add_to_group("players")
    camera.current = is_multiplayer_authority()
    spring_arm.rotation.x = camera_pitch
    _configure_cinematic_camera()
    if not MobileQualityManager.quality_changed.is_connected(_on_visual_quality_changed):
        MobileQualityManager.quality_changed.connect(_on_visual_quality_changed)
    previous_on_floor = is_on_floor()
    attack_flash.visible = false
    skill_flash.visible = false
    aura.visible = false
    if aura.material_override != null:
        aura.material_override = aura.material_override.duplicate()
    if is_multiplayer_authority():
        Progression.profile_changed.connect(_on_progression_changed)
        Progression.leveled_up.connect(_on_level_up)
        InventoryManager.inventory_changed.connect(_on_inventory_changed)
        _pull_local_profile()
        call_deferred("_broadcast_profile")
    else:
        _apply_team_color(false)
    health = _max_health()
    spirit_energy = float(_max_spirit())
    checkpoint_position = global_position
    _update_hp_label()

func _physics_process(delta: float) -> void:
    if not is_multiplayer_authority():
        return

    attack_cooldown = maxf(attack_cooldown - delta, 0.0)
    skill_1_cd = maxf(skill_1_cd - delta, 0.0)
    skill_2_cd = maxf(skill_2_cd - delta, 0.0)
    skill_3_cd = maxf(skill_3_cd - delta, 0.0)
    skill_4_cd = maxf(skill_4_cd - delta, 0.0)
    dodge_time = maxf(dodge_time - delta, 0.0)
    perfect_dodge_window = maxf(perfect_dodge_window - delta, 0.0)
    parry_window = maxf(parry_window - delta, 0.0)
    guard_break_time = maxf(guard_break_time - delta, 0.0)
    heavy_attack_cd = maxf(heavy_attack_cd - delta, 0.0)
    attack_buffer_time = maxf(attack_buffer_time - delta, 0.0)
    target_cycle_cooldown = maxf(target_cycle_cooldown - delta, 0.0)
    combat_message_time = maxf(combat_message_time - delta, 0.0)
    if combat_message_time <= 0.0:
        combat_message = ""
    camera_kick = move_toward(camera_kick, 0.0, 5.5 * delta)
    camera_kick_x = move_toward(camera_kick_x, 0.0, 7.0 * delta)
    combat_focus = move_toward(combat_focus, 0.0, 0.7 * delta)
    combo_reset = maxf(combo_reset - delta, 0.0)
    if combo_reset <= 0.0:
        combo_step = 0

    if downed:
        bleedout_remaining = maxf(bleedout_remaining - delta, 0.0)
        velocity = Vector3.ZERO
        _animate_visuals(delta, false)
        local_hud_changed.emit()
        return

    var spirit_regen := 4.0 + profile_spirit * 0.22
    if sprinting:
        spirit_regen *= 0.20
    spirit_energy = minf(spirit_energy + spirit_regen * delta, float(_max_spirit()))

    if not is_on_floor():
        velocity.y -= gravity * delta
    elif Input.is_action_just_pressed("jump"):
        velocity.y = 7.2

    if Input.is_action_just_pressed("lock_on"):
        _toggle_lock_on()
    if Input.is_action_just_pressed("target_cycle") and target_cycle_cooldown <= 0.0:
        _cycle_lock_target(1)
        target_cycle_cooldown = 0.16
    if Input.is_action_just_pressed("heal"):
        _use_healing_ofuda()

    _validate_lock_on()
    _update_lock_marker()
    _update_guard_state()
    _update_revive_channel(delta)

    var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var cam_forward := -camera_rig.global_transform.basis.z
    var cam_right := camera_rig.global_transform.basis.x
    cam_forward.y = 0.0
    cam_right.y = 0.0
    cam_forward = cam_forward.normalized()
    cam_right = cam_right.normalized()
    var wish_dir := (cam_right * input_vec.x + cam_forward * input_vec.y).normalized()

    var base_speed := move_speed + profile_agility * 0.035
    sprinting = Input.is_action_pressed("sprint") and wish_dir.length() > 0.01 and is_on_floor() and not guard_active and dodge_time <= 0.0 and lock_on_target == null and spirit_energy > 2.0
    if sprinting:
        base_speed *= sprint_multiplier
        spirit_energy = maxf(0.0, spirit_energy - sprint_spirit_per_second * delta)
    if guard_active:
        base_speed *= 0.58
    var grounded_accel := acceleration if is_on_floor() else acceleration * 0.46
    if dodge_time > 0.0 and dodge_direction.length() > 0.01:
        var dodge_target := dodge_direction * (dodge_speed + profile_agility * 0.05)
        velocity.x = move_toward(velocity.x, dodge_target.x, grounded_accel * 2.4 * delta)
        velocity.z = move_toward(velocity.z, dodge_target.z, grounded_accel * 2.4 * delta)
    elif wish_dir.length() > 0.01:
        velocity.x = move_toward(velocity.x, wish_dir.x * base_speed, grounded_accel * delta)
        velocity.z = move_toward(velocity.z, wish_dir.z * base_speed, grounded_accel * delta)
        if lock_on_target == null:
            rotation.y = lerp_angle(rotation.y, atan2(-wish_dir.x, -wish_dir.z), 13.0 * delta)
    else:
        var braking := acceleration * (1.25 if is_on_floor() else 0.28)
        velocity.x = move_toward(velocity.x, 0.0, braking * delta)
        velocity.z = move_toward(velocity.z, 0.0, braking * delta)

    if lock_on_target != null:
        var to_lock := lock_on_target.global_position - global_position
        var flat_lock := Vector3(to_lock.x, 0.0, to_lock.z)
        if flat_lock.length() > 0.1:
            rotation.y = lerp_angle(rotation.y, atan2(-flat_lock.x, -flat_lock.z), 10.0 * delta)

    if Input.is_action_just_pressed("dodge") and not guard_active:
        dodge_direction = wish_dir if wish_dir.length() > 0.01 else -global_transform.basis.z.normalized()
        dodge_direction.y = 0.0
        dodge_direction = dodge_direction.normalized()
        dodge_time = 0.34
        perfect_dodge_window = 0.17
        camera_kick = -1.6
        _play_dodge.rpc()

    if Input.is_action_just_pressed("attack"):
        attack_buffer_time = attack_buffer_window
    if attack_buffer_time > 0.0 and attack_cooldown <= 0.0 and not guard_active and dodge_time <= 0.06:
        attack_buffer_time = 0.0
        _perform_light_attack()

    if Input.is_action_just_pressed("heavy_attack"):
        _use_spirit_heavy()

    if Input.is_action_just_pressed("skill_1"):
        _use_moon_slash()
    if Input.is_action_just_pressed("skill_2"):
        _use_kage_step()
    if Input.is_action_just_pressed("skill_3"):
        _use_spirit_burst()
    if Input.is_action_just_pressed("skill_4"):
        _use_raijin_break()

    var pre_move_vertical := velocity.y
    move_and_slide()
    var now_on_floor := is_on_floor()
    if now_on_floor and not previous_on_floor and pre_move_vertical < -5.0:
        landing_kick = clampf(abs(pre_move_vertical) * 0.035, 0.12, 0.55)
        camera_kick = minf(camera_kick - landing_kick * 1.4, -0.35)
    previous_on_floor = now_on_floor
    landing_kick = move_toward(landing_kick, 0.0, delta * 2.4)
    resonance_strength = _team_resonance()
    _update_camera_feel(delta, wish_dir.length() > 0.01)
    _animate_visuals(delta, wish_dir.length() > 0.01)
    _sync_state.rpc(global_position, rotation.y, velocity)
    local_hud_changed.emit()


func _perform_light_attack() -> void:
    combo_step = (combo_step % 3) + 1
    combo_reset = 0.92
    attack_cooldown = 0.31 if combo_step < 3 else 0.47
    sprinting = false
    _face_lock_target()
    _play_attack.rpc(combo_step)
    camera_kick = 1.0 + combo_step * 0.22
    camera_kick_x = (-0.22 if combo_step % 2 == 1 else 0.22)
    combat_focus = 1.0
    _commit_attack_after(_attack_damage(combo_step), 2.7 + combo_step * 0.15, 0.05, 2.0 + combo_step * 2.0, 0.09 + combo_step * 0.012)

func _unhandled_input(event: InputEvent) -> void:
    if not is_multiplayer_authority() or downed:
        return
    if event is InputEventScreenDrag:
        var drag := event as InputEventScreenDrag
        if drag.position.x > get_viewport().get_visible_rect().size.x * 0.42 and lock_on_target == null:
            _rotate_camera(drag.relative.x, drag.relative.y)
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) and lock_on_target == null:
        var motion := event as InputEventMouseMotion
        _rotate_camera(motion.relative.x, motion.relative.y)

func _rotate_camera(dx: float, dy: float) -> void:
    camera_yaw -= dx * 0.004
    camera_pitch = clampf(camera_pitch - dy * 0.003, -0.78, 0.38)
    camera_rig.rotation.y = camera_yaw
    $CameraRig/SpringArm3D.rotation.x = camera_pitch

func _toggle_lock_on() -> void:
    if lock_on_target != null:
        lock_on_target = null
        return
    lock_on_target = _nearest_enemy(20.0)


func _cycle_lock_target(direction: int) -> void:
    var enemies: Array[Node3D] = []
    for e in get_tree().get_nodes_in_group("enemies"):
        if is_instance_valid(e) and global_position.distance_to(e.global_position) <= 24.0:
            enemies.append(e)
    if enemies.is_empty():
        lock_on_target = null
        return
    if lock_on_target == null or not is_instance_valid(lock_on_target):
        lock_on_target = _nearest_enemy(24.0)
        return
    var current_vec := lock_on_target.global_position - global_position
    var current_angle := atan2(current_vec.z, current_vec.x)
    var best: Node3D = null
    var best_step := INF
    for e in enemies:
        if e == lock_on_target:
            continue
        var v := e.global_position - global_position
        var angle := atan2(v.z, v.x)
        var diff := wrapf(angle - current_angle, -PI, PI)
        var step := 0.0
        if direction >= 0:
            step = diff if diff > 0.03 else diff + TAU
        else:
            step = -diff if diff < -0.03 else TAU - diff
        if step < best_step:
            best_step = step
            best = e
    if best != null:
        lock_on_target = best
        combat_message = "TARGET SWITCH"
        combat_message_time = 0.35

func _validate_lock_on() -> void:
    if lock_on_target == null:
        return
    if not is_instance_valid(lock_on_target) or global_position.distance_to(lock_on_target.global_position) > 26.0:
        lock_on_target = null

func _update_lock_marker() -> void:
    if not is_multiplayer_authority():
        lock_marker.visible = false
        return
    if lock_on_target == null or not is_instance_valid(lock_on_target):
        lock_marker.visible = false
        return
    lock_marker.visible = true
    lock_marker.global_position = lock_on_target.global_position + Vector3(0.0, 2.75, 0.0)
    var pulse := 1.0 + sin(Time.get_ticks_msec() * 0.008) * 0.08
    lock_marker.scale = Vector3.ONE * pulse

func _face_expression(expression_name: String, strength: float = 1.0, hold_seconds: float = 0.28) -> void:
    if facial_bridge == null or not facial_bridge.has_method("set_expression"):
        return
    face_expression_token += 1
    var token := face_expression_token
    facial_bridge.set_expression(expression_name, strength)
    if hold_seconds <= 0.0:
        return
    await get_tree().create_timer(hold_seconds).timeout
    if token == face_expression_token and facial_bridge != null and facial_bridge.has_method("clear_expression"):
        facial_bridge.clear_expression()

func _play_authored_animation(candidates: Array[String], speed: float = 1.0) -> bool:
    if animation_bridge == null or not animation_bridge.has_method("play_first"):
        return false
    return animation_bridge.play_first(candidates, speed)

func _nearest_enemy(max_range: float) -> Node3D:
    var best: Node3D = null
    var best_score := INF
    var forward := -global_transform.basis.z.normalized()
    for e in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(e):
            continue
        var to_enemy: Vector3 = e.global_position - global_position
        var flat := Vector3(to_enemy.x, 0.0, to_enemy.z)
        var dist := flat.length()
        if dist > max_range or dist <= 0.01:
            continue
        var facing_penalty := (1.0 - maxf(forward.dot(flat.normalized()), -1.0)) * 4.0
        var score := dist + facing_penalty
        if score < best_score:
            best_score = score
            best = e
    return best

func _face_lock_target() -> void:
    if lock_on_target == null or not is_instance_valid(lock_on_target):
        return
    var to_target := lock_on_target.global_position - global_position
    var flat := Vector3(to_target.x, 0.0, to_target.z)
    if flat.length() > 0.05:
        rotation.y = atan2(-flat.x, -flat.z)

func _use_moon_slash() -> void:
    if skill_1_cd > 0.0 or spirit_energy < 18.0 or not Progression.has_skill("moon_slash") or downed or guard_active:
        return
    var sl := max(Progression.skill_level("moon_slash"), 1)
    skill_1_cd = maxf(1.8, 3.2 - sl * 0.16)
    spirit_energy -= 18.0
    _face_lock_target()
    _play_skill.rpc(Color(0.3, 0.75, 1.0), 1.7 + sl * 0.08)
    _commit_attack_after(int(_base_attack() * (1.58 + sl * 0.17)), 4.8 + sl * 0.15, -0.25, 18.0 + sl * 2.0, 0.16)

func _use_kage_step() -> void:
    if skill_2_cd > 0.0 or spirit_energy < 24.0 or not Progression.has_skill("kage_step") or downed or guard_active:
        return
    var sl := max(Progression.skill_level("kage_step"), 1)
    skill_2_cd = maxf(3.4, 6.0 - sl * 0.25)
    spirit_energy -= 24.0
    _face_lock_target()
    var forward := -global_transform.basis.z.normalized()
    velocity.x += forward.x * (16.0 + sl * 0.8)
    velocity.z += forward.z * (16.0 + sl * 0.8)
    dodge_time = 0.36 + sl * 0.02
    _play_skill.rpc(Color(0.55, 0.25, 1.0), 1.25)
    _commit_attack_after(int(_base_attack() * (1.8 + sl * 0.22)), 3.6, -0.15, 22.0 + sl * 3.0, 0.11)

func _use_spirit_burst() -> void:
    if skill_3_cd > 0.0 or spirit_energy < 40.0 or not Progression.has_skill("spirit_burst") or downed or guard_active:
        return
    var sl := max(Progression.skill_level("spirit_burst"), 1)
    skill_3_cd = maxf(6.2, 10.0 - sl * 0.42)
    spirit_energy -= 40.0
    _play_skill.rpc(Color(0.25, 0.95, 0.85), 2.35 + sl * 0.12)
    _commit_attack_after(int(_base_attack() * (2.15 + sl * 0.32)), 5.8 + sl * 0.25, -1.0, 28.0 + sl * 3.0, 0.22)

func _use_healing_ofuda() -> void:
    if health >= _max_health() or downed:
        return
    if not InventoryManager.consume_item("healing_ofuda", 1):
        return
    health = mini(_max_health(), health + int(_max_health() * 0.36))
    spirit_energy = minf(float(_max_spirit()), spirit_energy + _max_spirit() * 0.16)
    _sync_health.rpc(health)
    _play_skill.rpc(Color(0.55, 1.0, 0.65), 1.15)
    _update_hp_label()

func _use_raijin_break() -> void:
    if skill_4_cd > 0.0 or spirit_energy < 58.0 or not Progression.has_skill("raijin_break") or downed or guard_active:
        return
    var sl := max(Progression.skill_level("raijin_break"), 1)
    skill_4_cd = maxf(9.5, 15.0 - sl * 0.55)
    spirit_energy -= 58.0
    _face_lock_target()
    _play_skill.rpc(Color(0.72, 0.88, 1.0), 3.0 + sl * 0.15)
    _commit_attack_after(int(_base_attack() * (3.05 + sl * 0.42)), 6.4 + sl * 0.3, -0.4, 42.0 + sl * 4.0, 0.28)

func _use_spirit_heavy() -> void:
    if heavy_attack_cd > 0.0 or attack_cooldown > 0.0 or spirit_energy < 22.0 or downed or guard_active:
        return
    heavy_attack_cd = 1.15
    attack_cooldown = 0.72
    spirit_energy -= 22.0
    attack_buffer_time = 0.0
    sprinting = false
    combo_step = 0
    combo_reset = 0.0
    _face_lock_target()
    var heavy_forward := -global_transform.basis.z.normalized()
    velocity.x += heavy_forward.x * 3.8
    velocity.z += heavy_forward.z * 3.8
    camera_kick = 2.4
    combat_focus = 1.0
    combat_message = "SPIRIT HEAVY"
    combat_message_time = 0.9
    _play_heavy.rpc()
    _commit_attack_after(int(_base_attack() * 1.72), 3.7, -0.05, 38.0, 0.24)

func _commit_attack_after(damage_value: int, radius: float, dot_limit: float, stagger_bonus: float, delay: float) -> void:
    await get_tree().create_timer(maxf(delay, 0.0)).timeout
    if downed:
        return
    _request_attack(damage_value, radius, dot_limit, stagger_bonus)

func _request_attack(damage_value: int, radius: float, dot_limit: float, stagger_bonus: float = 0.0) -> void:
    if multiplayer.multiplayer_peer is OfflineMultiplayerPeer or multiplayer.is_server():
        _server_attack(damage_value, radius, dot_limit, stagger_bonus)
    else:
        _server_attack.rpc_id(1, damage_value, radius, dot_limit, stagger_bonus)

@rpc("any_peer", "reliable")
func _server_attack(damage_value: int, radius: float, dot_limit: float, stagger_bonus: float) -> void:
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    if not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        var sender := multiplayer.get_remote_sender_id()
        if sender != 0 and sender != get_multiplayer_authority():
            return
    var max_server_damage := int(_base_attack() * 5.6)
    damage_value = clampi(damage_value, 1, max_server_damage)
    radius = clampf(radius, 0.5, 8.5)
    dot_limit = clampf(dot_limit, -1.0, 0.95)
    stagger_bonus = clampf(stagger_bonus, 0.0, 72.0)
    var forward := -global_transform.basis.z.normalized()
    for enemy in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(enemy):
            continue
        var to_enemy: Vector3 = enemy.global_position - global_position
        var flat := Vector3(to_enemy.x, 0.0, to_enemy.z)
        if flat.length() <= radius and (dot_limit <= -0.9 or forward.dot(flat.normalized()) > dot_limit):
            var final_damage := damage_value
            if randf() < _crit_chance():
                final_damage = int(final_damage * 1.65)
            enemy.apply_damage(final_damage, get_multiplayer_authority(), stagger_bonus)

func receive_damage(amount: int, source: Node = null) -> void:
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    if downed:
        return
    if dodge_time > 0.0:
        if perfect_dodge_window > 0.0:
            perfect_dodge_window = 0.0
            spirit_energy = minf(float(_max_spirit()), spirit_energy + 16.0)
            combat_message = "PERFECT DODGE • +SPIRIT"
            combat_message_time = 1.15
            if source != null and is_instance_valid(source) and source.has_method("apply_deflect"):
                source.apply_deflect(get_multiplayer_authority(), 24.0)
            _perfect_dodge_fx.rpc()
        return
    var source_in_front := true
    if source != null and is_instance_valid(source) and source is Node3D:
        var source_3d := source as Node3D
        var source_vec: Vector3 = source_3d.global_position - global_position
        var source_flat := Vector3(source_vec.x, 0.0, source_vec.z)
        if source_flat.length() > 0.05:
            source_in_front = (-global_transform.basis.z).dot(source_flat.normalized()) > -0.08
    if guard_active and guard_break_time <= 0.0 and source_in_front:
        if parry_window > 0.0:
            parry_window = 0.0
            spirit_energy = minf(float(_max_spirit()), spirit_energy + 22.0)
            combat_message = "PERFECT PARRY • STAGGER"
            combat_message_time = 1.3
            if source != null and is_instance_valid(source) and source.has_method("apply_deflect"):
                source.apply_deflect(get_multiplayer_authority(), 52.0)
            _parry_fx.rpc()
            return
        var guard_cost := maxf(10.0, amount * 0.62)
        if spirit_energy >= guard_cost:
            spirit_energy -= guard_cost
            amount = maxi(int(amount * 0.28), 1)
            combat_message = "GUARD"
            combat_message_time = 0.45
            _guard_fx.rpc()
        else:
            spirit_energy = 0.0
            guard_active = false
            guard_break_time = 1.35
            amount = maxi(int(amount * 0.85), 1)
            combat_message = "GUARD BROKEN"
            combat_message_time = 1.2
            _guard_break_fx.rpc()
    health = maxi(health - amount, 0)
    _sync_health.rpc(health)
    if health <= 0:
        downed = true
        var duration := 4.0 if multiplayer.multiplayer_peer is OfflineMultiplayerPeer else 16.0
        _enter_downed.rpc(duration)
        _server_bleedout(duration)

func _server_bleedout(duration: float) -> void:
    await get_tree().create_timer(duration).timeout
    if downed:
        _respawn_server()

func _respawn_server() -> void:
    health = _max_health()
    downed = false
    _respawn_now.rpc(checkpoint_position, health, _max_spirit())

@rpc("any_peer", "call_local", "reliable")
func _enter_downed(duration: float) -> void:
    _face_expression("pain", 1.0, 1.2)
    downed = true
    bleedout_remaining = duration
    visuals.rotation.z = 1.15
    _play_authored_animation(["downed", "death", "knockdown"], 1.0)
    hp_label.text = "DOWNED • REVIVE ME"
    aura.visible = true

@rpc("any_peer", "call_local", "reliable")
func _respawn_now(pos: Vector3, hp_value: int, spirit_value: int) -> void:
    downed = false
    bleedout_remaining = 0.0
    visuals.rotation.z = 0.0
    global_position = pos
    health = hp_value
    spirit_energy = float(spirit_value)
    aura.visible = false
    _play_authored_animation(["idle", "revive", "stand_up"], 1.0)
    _update_hp_label()

func _update_guard_state() -> void:
    var wants_guard := Input.is_action_pressed("guard")
    if Input.is_action_just_pressed("guard") and guard_break_time <= 0.0 and spirit_energy > 4.0:
        parry_window = 0.18
        combat_message = "PARRY WINDOW"
        combat_message_time = 0.35
        _guard_raise_fx.rpc()
    guard_active = wants_guard and guard_break_time <= 0.0 and spirit_energy > 0.5 and dodge_time <= 0.0

func _nearest_downed_ally(max_range: float = 3.2) -> Node3D:
    var target: Node3D = null
    var best := max_range
    for p in get_tree().get_nodes_in_group("players"):
        if p == self or not is_instance_valid(p) or not p.downed:
            continue
        var d := global_position.distance_to(p.global_position)
        if d < best:
            best = d
            target = p
    return target

func _update_revive_channel(delta: float) -> void:
    if not Input.is_action_pressed("interact"):
        revive_progress = maxf(revive_progress - delta * 2.5, 0.0)
        revive_target_name = ""
        return
    var target := _nearest_downed_ally(3.2)
    if target == null:
        revive_progress = 0.0
        revive_target_name = ""
        return
    if revive_target_name != String(target.name):
        revive_progress = 0.0
        revive_target_name = String(target.name)
    revive_progress += delta
    combat_message = "REVIVING • %d%%" % int(clampf(revive_progress / 1.85, 0.0, 1.0) * 100.0)
    combat_message_time = 0.2
    velocity.x *= 0.42
    velocity.z *= 0.42
    if revive_progress >= 1.85:
        revive_progress = 0.0
        var target_name := revive_target_name
        revive_target_name = ""
        if multiplayer.multiplayer_peer is OfflineMultiplayerPeer or multiplayer.is_server():
            _revive_target_server(target_name)
        else:
            _revive_target_server.rpc_id(1, target_name)
        combat_message = "ALLY RESTORED"
        combat_message_time = 1.25

@rpc("any_peer", "reliable")
func _revive_target_server(target_name: String) -> void:
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    if not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        var sender := multiplayer.get_remote_sender_id()
        if sender != 0 and sender != get_multiplayer_authority():
            return
    var target: Node3D = null
    for p in get_tree().get_nodes_in_group("players"):
        if String(p.name) == target_name:
            target = p as Node3D
            break
    if target == null or not target.downed or global_position.distance_to(target.global_position) > 3.5:
        return
    target.health = maxi(int(target._max_health() * 0.42), 1)
    target.downed = false
    target._revive_now.rpc(target.health, int(target._max_spirit() * 0.35))

@rpc("any_peer", "call_local", "reliable")
func _revive_now(hp_value: int, spirit_value: int) -> void:
    _face_expression("calm", 0.72, 0.8)
    downed = false
    bleedout_remaining = 0.0
    visuals.rotation.z = 0.0
    health = hp_value
    spirit_energy = float(spirit_value)
    aura.visible = false
    _play_authored_animation(["revive", "stand_up", "idle"], 1.0)
    _update_hp_label()

func set_checkpoint(pos: Vector3) -> void:
    checkpoint_position = pos
    health = _max_health()
    spirit_energy = float(_max_spirit())
    _update_hp_label()

func award_xp_server(amount: int) -> void:
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
        _receive_xp(amount)
    else:
        _receive_xp.rpc_id(get_multiplayer_authority(), amount)

@rpc("any_peer", "call_local", "reliable")
func _receive_xp(amount: int) -> void:
    if not is_multiplayer_authority():
        return
    Progression.add_xp(amount)

func award_loot_server(item_id: String, amount: int = 1) -> void:
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
        _receive_loot(item_id, amount)
    else:
        _receive_loot.rpc_id(get_multiplayer_authority(), item_id, amount)

@rpc("any_peer", "call_local", "reliable")
func _receive_loot(item_id: String, amount: int) -> void:
    if not is_multiplayer_authority():
        return
    InventoryManager.add_item(item_id, amount)

func notify_kill_server(enemy_name: String) -> void:
    if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
        _receive_kill(enemy_name)
    else:
        _receive_kill.rpc_id(get_multiplayer_authority(), enemy_name)

@rpc("any_peer", "call_local", "reliable")
func _receive_kill(enemy_name: String) -> void:
    if is_multiplayer_authority():
        QuestManager.enemy_defeated(enemy_name)

func _on_progression_changed() -> void:
    _pull_local_profile()
    health = mini(health + 12, _max_health())
    spirit_energy = minf(spirit_energy + 12.0, float(_max_spirit()))
    _broadcast_profile()
    _update_hp_label()
    local_hud_changed.emit()

func _on_inventory_changed() -> void:
    var hp_ratio := float(health) / float(maxi(_max_health(), 1))
    _pull_local_profile()
    health = maxi(int(_max_health() * hp_ratio), 1)
    spirit_energy = minf(spirit_energy, float(_max_spirit()))
    _broadcast_profile()
    _refresh_gear_visual()
    _update_hp_label()
    local_hud_changed.emit()

func _on_level_up(new_level: int) -> void:
    level_fx.emit(new_level)
    _level_up_fx.rpc(new_level)

func _pull_local_profile() -> void:
    profile_level = Progression.level
    profile_strength = Progression.strength + int(InventoryManager.bonus("strength"))
    profile_vitality = Progression.vitality + int(InventoryManager.bonus("vitality"))
    profile_agility = Progression.agility + int(InventoryManager.bonus("agility"))
    profile_spirit = Progression.spirit + int(InventoryManager.bonus("spirit"))
    profile_focus = Progression.focus + int(InventoryManager.bonus("focus"))
    profile_rank = Progression.rank_name()
    profile_gear_score = InventoryManager.gear_score()
    profile_gear_attack = int(InventoryManager.bonus("atk"))
    profile_gear_hp = int(InventoryManager.bonus("hp"))
    profile_gear_spirit = int(InventoryManager.bonus("spirit_max"))
    profile_gear_crit = InventoryManager.bonus("crit")
    _apply_team_color(true)
    _refresh_gear_visual()

func _broadcast_profile() -> void:
    _sync_profile.rpc(profile_level, profile_strength, profile_vitality, profile_agility, profile_spirit, profile_focus, profile_rank, profile_gear_score, profile_gear_attack, profile_gear_hp, profile_gear_spirit, profile_gear_crit)

@rpc("authority", "call_local", "reliable")
func _sync_profile(lvl: int, str_v: int, vit_v: int, agi_v: int, spi_v: int, foc_v: int, rank_v: String, gear_v: int, atk_gear: int, hp_gear: int, spirit_gear: int, crit_gear: float) -> void:
    profile_level = lvl
    profile_strength = str_v
    profile_vitality = vit_v
    profile_agility = agi_v
    profile_spirit = spi_v
    profile_focus = foc_v
    profile_rank = rank_v
    profile_gear_score = gear_v
    profile_gear_attack = atk_gear
    profile_gear_hp = hp_gear
    profile_gear_spirit = spirit_gear
    profile_gear_crit = crit_gear
    if not is_multiplayer_authority():
        _apply_team_color(false)
    _update_hp_label()

@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_state(pos: Vector3, rot_y: float, new_velocity: Vector3) -> void:
    global_position = global_position.lerp(pos, 0.38)
    rotation.y = lerp_angle(rotation.y, rot_y, 0.38)
    velocity = new_velocity

@rpc("authority", "call_local", "reliable")
func _play_attack(step: int) -> void:
    _face_expression("focus", 0.58, 0.24)
    _play_authored_animation(["attack_%d" % step, "light_attack_%d" % step, "attack"], 1.0 + step * 0.03)
    _play_sfx(SFX_SWING, 0.96 + step * 0.045, -7.0)
    _spawn_weapon_arc(Color(0.34, 0.76, 1.0), 1.15 + step * 0.10, -0.22 if step % 2 == 1 else 0.22)
    attack_flash.visible = true
    attack_flash.scale = Vector3(0.25, 0.25, 0.25)
    sword_pivot.rotation.x = -1.0
    sword_pivot.rotation.z = -0.5 if step % 2 == 1 else 0.5
    var tween := create_tween()
    tween.set_parallel(true)
    tween.tween_property(sword_pivot, "rotation:x", 1.15, 0.17)
    tween.tween_property(attack_flash, "scale", Vector3(1.5 + step * 0.14, 0.45, 1.6), 0.14)
    tween.chain().tween_callback(func(): attack_flash.visible = false; sword_pivot.rotation = Vector3.ZERO)

@rpc("authority", "call_local", "reliable")
func _play_dodge() -> void:
    _play_authored_animation(["dodge", "roll", "evade"], 1.08)
    _play_sfx(SFX_DODGE, 1.0, -10.0)
    _spawn_weapon_arc(Color(0.34, 0.48, 0.70), 0.72, 0.0)
    var tween := create_tween()
    tween.tween_property(visuals, "rotation:z", -0.5, 0.10)
    tween.tween_property(visuals, "rotation:z", 0.0, 0.16)

@rpc("authority", "call_local", "reliable")
func _play_skill(color: Color, scale_value: float) -> void:
    _face_expression("battle_cry", 0.78, 0.42)
    _play_authored_animation(["skill", "cast", "special"], 1.0)
    _play_sfx(SFX_SKILL, 0.92 + minf(scale_value * 0.03, 0.18), -8.0)
    _spawn_weapon_arc(color, minf(scale_value * 0.72, 2.25), 0.0)
    skill_flash.visible = true
    var mat := skill_flash.material_override as StandardMaterial3D
    if mat != null:
        mat.albedo_color = Color(color.r, color.g, color.b, 0.32)
        mat.emission = color
    skill_flash.scale = Vector3(0.25, 0.25, 0.25)
    var tween := create_tween()
    tween.tween_property(skill_flash, "scale", Vector3(scale_value, scale_value, scale_value), 0.24)
    tween.tween_callback(func(): skill_flash.visible = false)

@rpc("authority", "call_local", "reliable")
func _play_heavy() -> void:
    _face_expression("battle_cry", 1.0, 0.52)
    _play_authored_animation(["heavy_attack", "attack_heavy", "strong_attack"], 0.94)
    _play_sfx(SFX_SWING, 0.72, -4.5)
    _spawn_weapon_arc(Color(0.82, 0.92, 1.0), 2.25, -0.08)
    attack_flash.visible = true
    attack_flash.scale = Vector3(0.35, 0.35, 0.35)
    sword_pivot.rotation.x = -1.45
    sword_pivot.rotation.z = -0.18
    var tween := create_tween()
    tween.tween_property(sword_pivot, "rotation:x", 1.55, 0.31).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.parallel().tween_property(attack_flash, "scale", Vector3(2.25, 0.62, 2.35), 0.24)
    tween.tween_callback(func(): attack_flash.visible = false; sword_pivot.rotation = Vector3.ZERO)

@rpc("authority", "call_local", "reliable")
func _guard_raise_fx() -> void:
    _play_authored_animation(["guard", "block", "guard_raise"], 1.0)
    var tween := create_tween()
    tween.tween_property(sword_pivot, "rotation", Vector3(-0.42, 0.0, -0.88), 0.10)

@rpc("authority", "call_local", "reliable")
func _guard_fx() -> void:
    aura.visible = true
    aura.scale = Vector3(0.8, 0.10, 0.8)
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(1.35, 0.13, 1.35), 0.08)
    tween.tween_property(aura, "modulate:a", 0.0, 0.14)
    tween.tween_callback(func(): aura.modulate.a = 1.0; aura.visible = false)

@rpc("authority", "call_local", "reliable")
func _parry_fx() -> void:
    _face_expression("focus", 0.92, 0.38)
    _play_authored_animation(["parry", "deflect", "guard_counter"], 1.12)
    _play_sfx(SFX_PARRY, 1.0, -3.0)
    Input.vibrate_handheld(38)
    _spawn_weapon_arc(Color(1.0, 0.72, 0.18), 1.65, 0.0)
    aura.visible = true
    aura.scale = Vector3(0.35, 0.35, 0.35)
    var mat := aura.material_override as StandardMaterial3D
    if mat != null:
        mat.albedo_color = Color(1.0, 0.86, 0.48, 0.38)
        mat.emission = Color(1.0, 0.67, 0.18)
        mat.emission_energy_multiplier = 5.0
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(2.8, 0.22, 2.8), 0.13)
    tween.tween_property(aura, "modulate:a", 0.0, 0.20)
    tween.tween_callback(func(): aura.modulate.a = 1.0; aura.visible = false)

@rpc("authority", "call_local", "reliable")
func _guard_break_fx() -> void:
    _face_expression("pain", 0.85, 0.55)
    _play_sfx(SFX_IMPACT, 0.72, -2.5)
    Input.vibrate_handheld(70)
    visuals.rotation.z = -0.22
    var tween := create_tween()
    tween.tween_property(visuals, "rotation:z", 0.20, 0.10)
    tween.tween_property(visuals, "rotation:z", 0.0, 0.18)

@rpc("authority", "call_local", "reliable")
func _level_up_fx(new_level: int) -> void:
    aura.visible = true
    aura.scale = Vector3(0.4, 0.4, 0.4)
    hp_label.text = "LEVEL %d • ASCENDED" % new_level
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(2.5, 2.5, 2.5), 0.6)
    tween.tween_interval(0.8)
    tween.tween_callback(func(): aura.visible = false; _update_hp_label())

@rpc("any_peer", "call_local", "reliable")
func _sync_health(value: int) -> void:
    health = value
    _update_hp_label()

func _attack_damage(step: int) -> int:
    return int(_base_attack() * (0.72 + step * 0.19))

func _base_attack() -> int:
    var base := 13 + profile_strength * 4 + profile_level * 2 + profile_gear_attack
    return int(base * (1.0 + resonance_strength))

func _max_health() -> int:
    return 105 + profile_vitality * 13 + profile_level * 4 + profile_gear_hp

func _max_spirit() -> int:
    return 70 + profile_spirit * 11 + profile_level * 3 + profile_gear_spirit

func _crit_chance() -> float:
    return clampf(0.04 + profile_focus * 0.012 + profile_gear_crit, 0.04, 0.58)

func _update_hp_label() -> void:
    if downed:
        hp_label.text = "DOWNED • %.0fs" % bleedout_remaining
    else:
        hp_label.text = "[%s] LV.%d  GS.%d  %d/%d" % [profile_rank, profile_level, profile_gear_score, health, _max_health()]

func _apply_team_color(local: bool) -> void:
    var main_color := Color(0.12, 0.26, 0.50) if local else Color(0.45, 0.12, 0.15)
    torso.material_override = _make_material(main_color)
    coat.material_override = _make_material(Color(main_color.r * 0.52, main_color.g * 0.52, main_color.b * 0.58))

func _refresh_gear_visual() -> void:
    if not is_multiplayer_authority():
        return
    var weapon_id := String(InventoryManager.equipped.get("weapon", "iron_katana"))
    var color := InventoryManager.rarity_color(weapon_id)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color.lightened(0.2)
    mat.metallic = 0.85
    mat.roughness = 0.14
    if InventoryManager.rarity(weapon_id) in ["Rare", "Epic", "Legendary"]:
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 1.4 if InventoryManager.rarity(weapon_id) == "Rare" else 2.6
    blade.material_override = mat


func _team_resonance() -> float:
    var allies := 0
    for p in get_tree().get_nodes_in_group("players"):
        if p == self or not is_instance_valid(p) or p.downed:
            continue
        if global_position.distance_to(p.global_position) <= 8.0:
            allies += 1
    return minf(0.12, allies * 0.04)

func _update_camera_feel(delta: float, moving: bool) -> void:
    if not is_multiplayer_authority():
        return
    var target_distance := 18.0
    var target_side := 0.0
    if lock_on_target != null and is_instance_valid(lock_on_target):
        camera_yaw = lerp_angle(camera_yaw, 0.0, minf(delta * 5.8, 1.0))
        camera_pitch = lerpf(camera_pitch, -0.15, minf(delta * 3.2, 1.0))
        camera_rig.rotation.y = camera_yaw
        spring_arm.rotation.x = camera_pitch
        target_distance = global_position.distance_to(lock_on_target.global_position)
        var to_target := (lock_on_target.global_position - global_position).normalized()
        target_side = clampf(to_target.dot(camera_rig.global_transform.basis.x), -1.0, 1.0)

    var speed_ratio := clampf(Vector2(velocity.x, velocity.z).length() / maxf(dodge_speed, 0.1), 0.0, 1.0)
    var sprint_boost := 5.5 if sprinting else 0.0
    var lock_focus := -2.4 if lock_on_target != null else 0.0
    var boss_breathing_room := clampf((8.0 - target_distance) * 0.42, 0.0, 3.2) if lock_on_target != null else 0.0
    var target_fov := 65.0 + speed_ratio * 4.0 + sprint_boost + lock_focus + boss_breathing_room + (1.4 if combat_focus > 0.0 else 0.0) + camera_kick
    camera.fov = lerpf(camera.fov, target_fov, minf(delta * 7.5, 1.0))

    camera_motion_phase += delta * (4.2 + speed_ratio * 7.0)
    var motion_weight := speed_ratio * (1.0 if moving else 0.0)
    var micro_sway := sin(camera_motion_phase) * 0.018 * motion_weight
    var micro_bob := abs(sin(camera_motion_phase * 0.5)) * 0.014 * motion_weight
    var target_shoulder := (0.28 - target_side * 0.08) if lock_on_target != null else 0.48
    camera.h_offset = lerpf(camera.h_offset, target_shoulder + camera_kick_x + micro_sway, minf(delta * 8.5, 1.0))
    camera.v_offset = lerpf(camera.v_offset, (-0.055 if moving else 0.0) - landing_kick * 0.10 + micro_bob, minf(delta * 4.6, 1.0))
    var target_arm := (4.15 + clampf((5.5 - target_distance) * 0.18, 0.0, 0.85)) if lock_on_target != null else (5.25 if sprinting else 4.82)
    spring_arm.spring_length = lerpf(spring_arm.spring_length, target_arm, minf(delta * 5.5, 1.0))

    if camera_attributes != null:
        var dof_active := MobileQualityManager.current_tier == MobileQualityManager.QualityTier.ULTRA and RenderingServer.get_current_rendering_method() != "gl_compatibility"
        camera_attributes.dof_blur_far_enabled = dof_active
        camera_attributes.dof_blur_amount = 0.035 if lock_on_target == null else 0.028
        camera_attributes.dof_blur_far_distance = lerpf(camera_attributes.dof_blur_far_distance, maxf(target_distance + 10.0, 24.0), minf(delta * 2.2, 1.0))
        camera_attributes.dof_blur_far_transition = 12.0


func _configure_cinematic_camera() -> void:
    camera_attributes = CameraAttributesPractical.new()
    camera_attributes.exposure_multiplier = 1.0
    camera_attributes.dof_blur_far_enabled = false
    camera_attributes.dof_blur_near_enabled = false
    camera_attributes.dof_blur_amount = 0.03
    camera_attributes.dof_blur_far_distance = 28.0
    camera_attributes.dof_blur_far_transition = 12.0
    camera.attributes = camera_attributes
    _on_visual_quality_changed(MobileQualityManager.quality_name())

func _on_visual_quality_changed(_tier_name: String) -> void:
    if camera_attributes == null:
        return
    var rd_available := RenderingServer.get_current_rendering_method() != "gl_compatibility"
    camera_attributes.dof_blur_far_enabled = rd_available and MobileQualityManager.current_tier == MobileQualityManager.QualityTier.ULTRA
    camera_attributes.dof_blur_amount = 0.03

@rpc("authority", "call_local", "reliable")
func _perfect_dodge_fx() -> void:
    Input.vibrate_handheld(24)
    aura.visible = true
    aura.scale = Vector3(0.55, 0.55, 0.55)
    var mat := aura.material_override as StandardMaterial3D
    if mat != null:
        mat.albedo_color = Color(0.72, 0.92, 1.0, 0.3)
        mat.emission = Color(0.55, 0.86, 1.0)
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(2.1, 0.4, 2.1), 0.18)
    tween.tween_property(aura, "modulate:a", 0.0, 0.22)
    tween.tween_callback(func(): aura.visible = false; aura.modulate.a = 1.0)

func _animate_visuals(delta: float, moving: bool) -> void:
    var horizontal_speed := Vector2(velocity.x, velocity.z).length()
    if animation_bridge != null and animation_bridge.has_method("has_authored_animation_player") and animation_bridge.has_authored_animation_player():
        if downed:
            return
        if guard_active:
            _play_authored_animation(["guard_idle", "guard", "block"], 1.0)
        elif attack_cooldown <= 0.08 and dodge_time <= 0.0:
            if sprinting and moving:
                _play_authored_animation(["sprint", "run"], 1.15)
            elif moving:
                _play_authored_animation(["run", "jog", "walk"], 1.0)
            else:
                _play_authored_animation(["idle", "combat_idle"], 1.0)
        return
    visual_speed = lerpf(visual_speed, horizontal_speed, minf(delta * 8.0, 1.0))
    var locomotion := clampf(visual_speed / maxf(move_speed, 0.1), 0.0, 1.45)
    anim_time += delta * lerpf(2.1, 9.4, clampf(locomotion, 0.0, 1.0))
    if downed:
        return
    var stride := sin(anim_time) * (0.45 * clampf(locomotion, 0.08, 1.0))
    var bob := abs(sin(anim_time)) * (0.060 * clampf(locomotion, 0.18, 1.0))
    var local_velocity := global_transform.basis.inverse() * Vector3(velocity.x, 0.0, velocity.z)
    var lean_x := clampf(-local_velocity.z / maxf(dodge_speed, 0.1), -1.0, 1.0) * 0.11
    var lean_z := clampf(local_velocity.x / maxf(dodge_speed, 0.1), -1.0, 1.0) * -0.13
    if dodge_time > 0.0:
        lean_x -= 0.20
        lean_z *= 1.8
    visuals.position.y = bob - landing_kick * 0.11
    visuals.rotation.x = lerpf(visuals.rotation.x, lean_x, minf(delta * 8.5, 1.0))
    visuals.rotation.z = lerpf(visuals.rotation.z, lean_z, minf(delta * 9.5, 1.0))
    leg_l.rotation.x = stride
    leg_r.rotation.x = -stride
    if guard_active:
        arm_l.rotation.x = lerpf(arm_l.rotation.x, -0.68, minf(delta * 15.0, 1.0))
        arm_r.rotation.x = lerpf(arm_r.rotation.x, -0.52, minf(delta * 15.0, 1.0))
        sword_pivot.rotation = sword_pivot.rotation.lerp(Vector3(-0.42, 0.0, -0.88), minf(delta * 12.0, 1.0))
    elif attack_cooldown <= 0.08:
        arm_l.rotation.x = lerpf(arm_l.rotation.x, -stride * 0.45, minf(delta * 11.0, 1.0))
        arm_r.rotation.x = lerpf(arm_r.rotation.x, stride * 0.45, minf(delta * 11.0, 1.0))
        sword_pivot.rotation = sword_pivot.rotation.lerp(Vector3.ZERO, minf(delta * 8.0, 1.0))
    var blade_mat := blade.material_override as StandardMaterial3D
    if blade_mat != null and blade_mat.emission_enabled:
        blade_mat.emission_energy_multiplier = 1.6 + sin(anim_time * 0.55) * 0.22 + clampf(spirit_energy / maxf(float(_max_spirit()), 1.0), 0.0, 1.0) * 0.75

func _spawn_weapon_arc(color: Color, size_value: float, yaw_offset: float) -> void:
    # SHINRA: curved emissive ribbon instead of the old rectangular slash.
    # Segment count follows the mobile quality tier so the silhouette stays smooth on
    # flagship phones without wasting geometry on low-end devices.
    var segments := clampi(int(14.0 * MobileQualityManager.detail_multiplier()), 8, 20)
    var surface := SurfaceTool.new()
    surface.begin(Mesh.PRIMITIVE_TRIANGLE_STRIP)
    var inner_radius := 0.54
    var outer_radius := 1.18
    for i in range(segments + 1):
        var t := float(i) / float(segments)
        var angle := lerpf(-1.18, 1.18, t)
        var edge_fade := sin(t * PI)
        var inner := Vector3(cos(angle) * inner_radius, sin(angle) * inner_radius, 0.0)
        var outer := Vector3(cos(angle) * outer_radius, sin(angle) * outer_radius, 0.0)
        surface.set_color(Color(color.r, color.g, color.b, 0.16 * edge_fade))
        surface.add_vertex(inner)
        surface.set_color(Color(color.r, color.g, color.b, 0.82 * edge_fade))
        surface.add_vertex(outer)
    var ribbon_mesh := surface.commit()
    var arc := MeshInstance3D.new()
    arc.mesh = ribbon_mesh
    arc.position = Vector3(0.0, 1.12, -1.08)
    arc.rotation = Vector3(0.02, yaw_offset, -0.34)
    arc.scale = Vector3.ONE * 0.24
    arc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var mat := StandardMaterial3D.new()
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    mat.vertex_color_use_as_albedo = true
    mat.albedo_color = Color(1.0, 1.0, 1.0, 0.86)
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 3.2 if MobileQualityManager.current_tier < 3 else 4.4
    arc.material_override = mat
    add_child(arc)
    if not MobileVFXBudget.try_register(arc, 2, 2, 0.0):
        arc.queue_free()
        return
    var target_scale := Vector3.ONE * size_value
    var tween := create_tween().set_parallel(true)
    tween.tween_property(arc, "scale", target_scale, 0.11).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_property(arc, "rotation:z", 0.82, 0.17).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_property(arc, "modulate:a", 0.0, 0.20).set_delay(0.055)
    tween.chain().tween_callback(arc.queue_free)

func _play_sfx(stream: AudioStream, pitch: float = 1.0, volume_db: float = -8.0) -> void:
    var player := AudioStreamPlayer3D.new()
    player.stream = stream
    player.pitch_scale = pitch
    player.volume_db = volume_db
    player.max_distance = 28.0
    add_child(player)
    player.finished.connect(player.queue_free)
    player.play()

func _make_material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.08
    mat.roughness = 0.72
    return mat
