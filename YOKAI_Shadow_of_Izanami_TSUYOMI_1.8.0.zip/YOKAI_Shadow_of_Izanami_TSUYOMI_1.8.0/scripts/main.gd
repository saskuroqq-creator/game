extends Control

@onready var ip_edit: LineEdit = $Panel/VBox/IP
@onready var status_label: Label = $Panel/VBox/Status

func _ready() -> void:
    NetworkManager.status_changed.connect(_on_status_changed)
    $Panel/VBox/Host.pressed.connect(NetworkManager.host_game)
    $Panel/VBox/Join.pressed.connect(_join)
    $Panel/VBox/Solo.pressed.connect(NetworkManager.start_solo)
    $Panel/VBox/NewJourney.pressed.connect(_new_journey)
    $Panel/VBox/Quit.pressed.connect(get_tree().quit)

func _new_journey() -> void:
    Progression.reset_profile()
    StoryManager.reset_story()
    NetworkManager.start_solo()

func _join() -> void:
    NetworkManager.join_game(ip_edit.text)

func _on_status_changed(message: String) -> void:
    status_label.text = message
