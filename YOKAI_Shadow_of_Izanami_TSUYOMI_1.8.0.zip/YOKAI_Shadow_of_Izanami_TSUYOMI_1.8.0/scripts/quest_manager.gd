extends Node

signal quests_changed
signal quest_completed(quest_id: String)

const SAVE_PATH := "user://yokai_quests.cfg"

const QUESTS := {
    "fox_hunt": {"title":"FOX-FIRE HUNT", "target":"Fox Shade", "need":4, "min_level":3, "xp":260, "item":"foxfire_charm", "text":"Hunt Fox Shades in Kitsune Forest"},
    "tengu_feathers": {"title":"FEATHERS OF THE RIDGE", "target":"Tengu Scout", "need":3, "min_level":7, "xp":420, "item":"tengu_edge", "text":"Defeat Tengu Scouts on the ridge"},
    "war_oni": {"title":"CRIMSON HORNS", "target":"War Oni", "need":4, "min_level":14, "xp":650, "item":"boneguard_armor", "text":"Break the War Oni patrol in the Highlands"},
    "yomi_wraiths": {"title":"NAMES OF THE DEAD", "target":"Yomi Wraith", "need":4, "min_level":12, "xp":540, "item":"spirit_shard", "text":"Release the Yomi Wraiths in the marsh"}
}

var progress: Dictionary = {}
var completed: Dictionary = {}

func _ready() -> void:
    load_quests()
    Progression.profile_changed.connect(_on_profile_changed)
    _activate_for_level()

func _on_profile_changed() -> void:
    _activate_for_level()

func _activate_for_level() -> void:
    var changed := false
    for id in QUESTS.keys():
        var q: Dictionary = QUESTS[id]
        if Progression.level >= int(q.get("min_level", 1)) and not progress.has(id) and not completed.get(id, false):
            progress[id] = 0
            changed = true
    if changed:
        save_quests()
        quests_changed.emit()

func enemy_defeated(enemy_name: String) -> void:
    var changed := false
    for id in progress.keys():
        if completed.get(id, false):
            continue
        var q: Dictionary = QUESTS.get(id, {})
        if String(q.get("target", "")) != enemy_name:
            continue
        progress[id] = mini(int(progress[id]) + 1, int(q.get("need", 1)))
        changed = true
        if int(progress[id]) >= int(q.get("need", 1)):
            _complete(String(id))
    if changed:
        save_quests()
        quests_changed.emit()

func _complete(id: String) -> void:
    if completed.get(id, false):
        return
    var q: Dictionary = QUESTS.get(id, {})
    completed[id] = true
    Progression.add_xp(int(q.get("xp", 0)))
    var item_id := String(q.get("item", ""))
    if item_id != "":
        InventoryManager.add_item(item_id, 1)
    quest_completed.emit(id)

func active_summary() -> String:
    var lines: Array[String] = []
    for id in progress.keys():
        if completed.get(id, false):
            continue
        var q: Dictionary = QUESTS.get(id, {})
        lines.append("%s  %d/%d\n%s" % [String(q.get("title", id)), int(progress[id]), int(q.get("need", 1)), String(q.get("text", ""))])
        if lines.size() >= 2:
            break
    if lines.is_empty():
        return "No active side hunts. Explore the province."
    return "\n\n".join(lines)

func save_quests() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("quests", "progress", progress)
    cfg.set_value("quests", "completed", completed)
    cfg.save(SAVE_PATH)

func load_quests() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    progress = cfg.get_value("quests", "progress", progress)
    completed = cfg.get_value("quests", "completed", completed)
