extends Node3D

const ENEMY_SCENE := preload("res://scenes/Enemy.tscn")
const WET_SURFACE_SHADER := preload("res://shaders/mobile_wet_surface.gdshader")
var rng := RandomNumberGenerator.new()
var _material_cache: Dictionary = {}
var _foliage_material_cache: Dictionary = {}

func _ready() -> void:
    rng.seed = 944771
    _build_land()
    _build_distant_silhouette()
    _build_moon_disc()
    _build_landmarks()
    _build_vegetation()
    _build_atmosphere_details()
    _build_shogun_details()
    _spawn_population()

func _build_land() -> void:
    _plane("WorldGround", Vector3(0,0,0), Vector2(320,320), Color(0.055,0.085,0.065), 0.0)
    _plane("VillageGround", Vector3(0,0.012,4), Vector2(48,48), Color(0.13,0.12,0.105), 0.0)
    _plane("KitsuneGround", Vector3(-62,0.016,-42), Vector2(58,52), Color(0.095,0.055,0.085), 0.0)
    _plane("TenguGround", Vector3(55,0.018,-66), Vector2(56,50), Color(0.075,0.09,0.105), 0.0)
    _plane("YomiGround", Vector3(72,0.014,30), Vector2(50,56), Color(0.055,0.105,0.085), 0.0)
    _plane("OniGround", Vector3(18,0.015,76), Vector2(58,50), Color(0.13,0.065,0.045), 0.0)
    _plane("MoonfallGround", Vector3(0,0.019,-102), Vector2(46,30), Color(0.085,0.045,0.11), 0.0)
    _plane("DrownedGround", Vector3(118,0.019,-8), Vector2(54,48), Color(0.045,0.10,0.11), 0.0)
    _plane("BambooGround", Vector3(-92,0.019,92), Vector2(60,54), Color(0.055,0.12,0.065), 0.0)
    _plane("VeiledGateGround", Vector3(0,0.020,132), Vector2(52,42), Color(0.12,0.035,0.065), 0.0)

    # Main roads connect the open world instead of loading separate levels.
    _plane("RoadNorth", Vector3(0,0.025,-48), Vector2(8,104), Color(0.19,0.17,0.14), 0.0)
    _plane("RoadWest", Vector3(-31,0.026,-20), Vector2(66,7), Color(0.19,0.17,0.14), 0.0)
    _plane("RoadEast", Vector3(37,0.027,15), Vector2(78,7), Color(0.19,0.17,0.14), 0.0)
    _plane("RoadSouth", Vector3(12,0.028,42), Vector2(7,78), Color(0.19,0.17,0.14), 0.0)
    _plane("RoadFarEast", Vector3(96,0.028,8), Vector2(54,7), Color(0.16,0.16,0.14), 0.0)
    _plane("RoadSouthWest", Vector3(-54,0.028,63), Vector2(95,7), Color(0.16,0.16,0.14), -0.35)
    _plane("RoadVeiledGate", Vector3(0,0.029,111), Vector2(7,64), Color(0.18,0.12,0.13), 0.0)

    for i in range(28):
        var angle := TAU * float(i) / 28.0
        var r := 156.0 + rng.randf_range(-5.0, 6.0)
        _mountain(Vector3(cos(angle)*r,0,sin(angle)*r), rng.randf_range(7.0,14.0), rng.randf_range(10.0,22.0))

func _build_landmarks() -> void:
    _zone_label("HOSHIKAWA VILLAGE", Vector3(0,4.8,10), Color(0.95,0.88,0.72))
    _zone_label("KITSUNE FOREST • LV 5+", Vector3(-62,5,-42), Color(1.0,0.45,0.78))
    _zone_label("TENGU RIDGE • LV 9+", Vector3(55,6,-66), Color(0.55,0.75,1.0))
    _zone_label("YOMI MARSH • LV 14+", Vector3(72,5,30), Color(0.45,1.0,0.67))
    _zone_label("ONI HIGHLANDS • LV 17+", Vector3(18,6,76), Color(1.0,0.35,0.24))
    _zone_label("MOONFALL SHRINE • LV 20+", Vector3(0,7,-102), Color(0.8,0.4,1.0))
    _zone_label("DROWNED SHRINE • LV 24+", Vector3(118,6,-8), Color(0.4,0.9,1.0))
    _zone_label("BAMBOO HOLLOW • LV 28+", Vector3(-92,6,92), Color(0.55,1.0,0.62))
    _zone_label("VEILED GATE • FINAL HUNT • LV 32+", Vector3(0,7,132), Color(1.0,0.38,0.52))

    _torii(Vector3(0,0,-12), 1.3, Color(0.58,0.055,0.055))
    _torii(Vector3(-43,0,-29), 0.9, Color(0.65,0.12,0.2))
    _torii(Vector3(35,0,-48), 0.95, Color(0.25,0.3,0.38))
    _torii(Vector3(50,0,22), 0.85, Color(0.15,0.35,0.24))
    _torii(Vector3(12,0,55), 1.0, Color(0.65,0.1,0.06))
    _torii(Vector3(0,0,-88), 1.55, Color(0.34,0.04,0.45))
    _torii(Vector3(102,0,-4), 1.15, Color(0.06,0.35,0.42))
    _torii(Vector3(-78,0,78), 1.18, Color(0.12,0.38,0.14))
    _torii(Vector3(0,0,116), 1.65, Color(0.52,0.025,0.09))

    _shrine(Vector3(0,0,22), Color(0.34,0.08,0.06))
    _shrine(Vector3(-63,0,-50), Color(0.28,0.05,0.14))
    _shrine(Vector3(56,0,-78), Color(0.12,0.16,0.22))
    _shrine(Vector3(72,0,39), Color(0.05,0.18,0.12))
    _shrine(Vector3(18,0,87), Color(0.32,0.08,0.035))
    _shrine(Vector3(0,0,-108), Color(0.19,0.04,0.28), 1.45)
    _shrine(Vector3(121,0,-10), Color(0.04,0.25,0.30), 1.15)
    _shrine(Vector3(-96,0,96), Color(0.08,0.30,0.10), 1.15)
    _shrine(Vector3(0,0,145), Color(0.38,0.025,0.10), 1.55)

    _npc("HinaNPC", Vector3(-3,0,18), "HINA • SHRINE KEEPER", "The Black Moon is changing the province. Return when your blade grows stronger.", "fox_hunt", Color(0.5,0.72,1.0))
    _npc("GensaiNPC", Vector3(5,0,15), "GENSAI • RONIN", "A hunter survives by reading the battlefield, not by chasing damage.", "tengu_feathers", Color(0.95,0.55,0.26))
    _npc("MioNPC", Vector3(-8,0,12), "MIO • RELIC SMITH", "Bring me cursed relics. Strong gear changes what your body can endure.", "war_oni", Color(0.8,0.45,1.0))

    _loot_chest("VillageCache", Vector3(9,0,19), "healing_ofuda", 2, Color(0.72,0.55,0.18))
    _loot_chest("FoxShrineCache", Vector3(-76,0,-54), "foxfire_blade", 1, Color(0.72,0.30,1.0))
    _loot_chest("RidgeCache", Vector3(69,0,-79), "spirit_shard", 3, Color(0.3,0.65,1.0))
    _loot_chest("YomiCache", Vector3(84,0,38), "healing_ofuda", 3, Color(0.32,0.9,0.62))
    _loot_chest("VeiledGateCache", Vector3(11,0,136), "healing_ofuda", 5, Color(1.0,0.30,0.42))

    for z in [-6.0, 2.0, 10.0, 18.0]:
        _lantern(Vector3(-5.5,0,z), Color(1.0,0.35,0.08))
        _lantern(Vector3(5.5,0,z), Color(1.0,0.35,0.08))

func _build_vegetation() -> void:
    # SHINRA 1.6: mobile-first batching. Decorative vegetation is rendered with MultiMesh
    # to collapse hundreds of draw calls while a single StaticBody keeps world collision.
    var tree_records: Array = []
    var tree_target := maxi(42, int(105.0 * MobileQualityManager.detail_multiplier()))
    var attempts := 0
    while tree_records.size() < tree_target and attempts < tree_target * 4:
        attempts += 1
        var p := Vector3(rng.randf_range(-145,145),0,rng.randf_range(-145,145))
        if abs(p.x) < 9.0 or _near_landmark(p):
            continue
        var tint_id := 0
        if p.x < -35 and p.z < -15:
            tint_id = 1
        elif p.x > 42 and p.z > 4:
            tint_id = 2
        elif p.z > 48:
            tint_id = 3
        tree_records.append({
            "position": p,
            "scale": rng.randf_range(0.75,1.45),
            "rotation": rng.randf_range(-PI, PI),
            "tint": tint_id
        })
    _build_tree_multimeshes(tree_records)

    var rock_records: Array = []
    var rock_target := maxi(22, int(55.0 * MobileQualityManager.detail_multiplier()))
    attempts = 0
    while rock_records.size() < rock_target and attempts < rock_target * 4:
        attempts += 1
        var p := Vector3(rng.randf_range(-148,148),0,rng.randf_range(-148,148))
        if _near_landmark(p):
            continue
        rock_records.append({
            "position": p,
            "scale": rng.randf_range(0.55,1.7),
            "rotation": Vector3(rng.randf_range(-0.2,0.2),rng.randf_range(-PI,PI),rng.randf_range(-0.18,0.18))
        })
    _build_rock_multimesh(rock_records)


func _build_atmosphere_details() -> void:
    # v0.3.0 visual pass: authored-looking local atmosphere without external assets.
    _water_sheet(Vector3(118,0.035,-8), Vector2(48,40), Color(0.04,0.28,0.34,0.72))
    _water_sheet(Vector3(78,0.034,34), Vector2(30,24), Color(0.035,0.20,0.16,0.58))
    var bamboo_records: Array = []
    var bamboo_target := maxi(14, int(28.0 * MobileQualityManager.detail_multiplier()))
    for i in range(bamboo_target):
        bamboo_records.append({
            "position": Vector3(rng.randf_range(-116.0,-70.0),0,rng.randf_range(70.0,112.0)),
            "scale": rng.randf_range(0.8,1.35),
            "rotation": rng.randf_range(-PI, PI)
        })
    _build_bamboo_multimesh(bamboo_records)
    for p in [Vector3(0,3.8,16), Vector3(-62,3.4,-47), Vector3(55,4.0,-73), Vector3(72,3.5,36), Vector3(18,4.0,83), Vector3(0,4.8,-105), Vector3(118,3.8,-9), Vector3(-92,3.8,96), Vector3(0,4.8,136)]:
        _spirit_light(p)

func _build_shogun_details() -> void:
    # v0.4.0 authored-procedural dressing pass. Keeps the prototype self-contained and copyright-safe.
    for i in range(26):
        var z := -10.0 + i * 3.25
        _stone_step(Vector3(sin(i * 0.73) * 0.55, 0.055, z), rng.randf_range(0.82, 1.18))
    var grass_records: Array = []
    var grass_target := maxi(14, int(38.0 * MobileQualityManager.detail_multiplier()))
    var grass_attempts := 0
    while grass_records.size() < grass_target and grass_attempts < grass_target * 4:
        grass_attempts += 1
        var p := Vector3(rng.randf_range(-138.0,138.0),0,rng.randf_range(-138.0,138.0))
        if _near_landmark(p) or abs(p.x) < 7.0:
            continue
        grass_records.append({"position": p, "scale": rng.randf_range(0.65,1.35), "rotation": rng.randf_range(-PI,PI)})
    _build_grass_multimesh(grass_records, Color(0.20,0.31,0.16))
    for p in [Vector3(-5.7,0,-92), Vector3(5.7,0,-92), Vector3(-6.8,0,-101), Vector3(6.8,0,-101)]:
        _banner(p, Color(0.42,0.035,0.07))
    _wood_bridge(Vector3(99.5,0.12,-8), Vector2(17.0,3.3), -0.02)
    for i in range(7):
        _spirit_light(Vector3(104.0 + i * 4.4, 2.0 + sin(i)*0.4, -18.0 + (i%2)*19.0))
    for p in [Vector3(-7.5,0,121), Vector3(7.5,0,121), Vector3(-8.5,0,134), Vector3(8.5,0,134), Vector3(-7.0,0,145), Vector3(7.0,0,145)]:
        _banner(p, Color(0.48,0.02,0.09))

func _stone_step(pos: Vector3, scale_v: float) -> void:
    var m := MeshInstance3D.new()
    var c := CylinderMesh.new()
    c.top_radius = 0.62 * scale_v
    c.bottom_radius = 0.72 * scale_v
    c.height = 0.10
    c.radial_segments = 7
    m.mesh = c
    m.position = pos
    m.rotation.y = rng.randf_range(-0.4,0.4)
    m.material_override = _mat(Color(0.24,0.25,0.23),0.98)
    m.visibility_range_end = MobileQualityManager.far_detail_distance(72.0)
    m.visibility_range_end_margin = 6.0
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _register_mobile_detail(m, 72.0)
    add_child(m)

func _grass_clump(pos: Vector3, scale_v: float, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    root.scale = Vector3.ONE * scale_v
    add_child(root)
    for i in range(3):
        var blade := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(0.05, 0.65 + i * 0.08, 0.16)
        blade.mesh = box
        blade.position = Vector3((i-1)*0.12, 0.30, (i%2)*0.08)
        blade.rotation.z = (i-1) * 0.14
        blade.rotation.y = i * 0.8
        blade.material_override = _mat(color.lightened(i*0.05),0.92)
        root.add_child(blade)

func _banner(pos: Vector3, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    add_child(root)
    _box(root, Vector3(0,1.8,0), Vector3(0.12,3.6,0.12), Color(0.10,0.07,0.05))
    _box(root, Vector3(0.48,2.65,0), Vector3(0.86,1.45,0.06), color)
    var seal := MeshInstance3D.new()
    var ring := TorusMesh.new()
    ring.inner_radius = 0.10
    ring.outer_radius = 0.22
    seal.mesh = ring
    seal.position = Vector3(0.48,2.78,-0.05)
    seal.rotation.x = PI/2.0
    var mat: StandardMaterial3D = _mat(Color(0.85,0.68,0.40),0.35).duplicate()
    mat.emission_enabled = true
    mat.emission = Color(0.42,0.12,0.05)
    mat.emission_energy_multiplier = 1.2
    seal.material_override = mat
    root.add_child(seal)

func _wood_bridge(pos: Vector3, dims: Vector2, rot: float) -> void:
    var root := Node3D.new()
    root.position = pos
    root.rotation.y = rot
    add_child(root)
    var planks := maxi(int(dims.x / 0.75), 4)
    for i in range(planks):
        var x := -dims.x * 0.5 + (i + 0.5) * dims.x / planks
        _box(root, Vector3(x,0,0), Vector3(dims.x/planks*0.90,0.16,dims.y), Color(0.20 + (i%2)*0.02,0.12,0.065))
    _box(root, Vector3(0,0.55,-dims.y*0.52), Vector3(dims.x,0.10,0.10), Color(0.15,0.08,0.04))
    _box(root, Vector3(0,0.55,dims.y*0.52), Vector3(dims.x,0.10,0.10), Color(0.15,0.08,0.04))

func _water_sheet(pos: Vector3, dims: Vector2, color: Color) -> void:
    var m := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = dims
    m.mesh = mesh
    m.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.roughness = 0.18
    mat.metallic = 0.15
    mat.emission_enabled = true
    mat.emission = Color(color.r*0.42,color.g*0.55,color.b*0.65)
    mat.emission_energy_multiplier = 0.45
    m.material_override = mat
    m.visibility_range_end = MobileQualityManager.far_detail_distance(125.0)
    m.visibility_range_end_margin = 10.0
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _register_mobile_detail(m, 125.0)
    add_child(m)

func _build_bamboo_multimesh(records: Array) -> void:
    if records.is_empty():
        return
    var stem_mesh := CylinderMesh.new()
    stem_mesh.top_radius = 0.10
    stem_mesh.bottom_radius = 0.13
    stem_mesh.height = 5.6
    stem_mesh.radial_segments = 6
    var ring_mesh := CylinderMesh.new()
    ring_mesh.top_radius = 0.145
    ring_mesh.bottom_radius = 0.145
    ring_mesh.height = 0.055
    ring_mesh.radial_segments = 6
    var stem_transforms: Array = []
    var ring_transforms: Array = []
    for record in records:
        var p: Vector3 = record["position"]
        var scale_v: float = record["scale"]
        var rot: float = record["rotation"]
        var basis := Basis(Vector3.UP, rot).scaled(Vector3.ONE * scale_v)
        stem_transforms.append(Transform3D(basis, p + Vector3(0, 2.8 * scale_v, 0)))
        for y in [1.0, 2.1, 3.2, 4.3]:
            ring_transforms.append(Transform3D(basis, p + Vector3(0, y * scale_v, 0)))
    _spawn_multimesh("BambooStems", stem_mesh, _foliage_mat(Color(0.09,0.33,0.13),0.58,0.045), stem_transforms, 94.0, false)
    _spawn_multimesh("BambooRings", ring_mesh, _foliage_mat(Color(0.16,0.46,0.18),0.5,0.025), ring_transforms, 76.0, false)

func _bamboo(pos: Vector3, scale_v: float) -> void:
    var root := Node3D.new()
    root.position = pos
    root.scale = Vector3.ONE * scale_v
    add_child(root)
    var stem := MeshInstance3D.new()
    var c := CylinderMesh.new()
    c.top_radius = 0.10
    c.bottom_radius = 0.13
    c.height = 5.6
    stem.mesh = c
    stem.position.y = 2.8
    stem.material_override = _mat(Color(0.09,0.33,0.13),0.58)
    stem.visibility_range_end = MobileQualityManager.far_detail_distance(92.0)
    stem.visibility_range_end_margin = 8.0
    stem.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _register_mobile_detail(stem, 92.0)
    root.add_child(stem)
    for y in [1.0,2.1,3.2,4.3]:
        var ring := MeshInstance3D.new()
        var rc := CylinderMesh.new()
        rc.top_radius = 0.145
        rc.bottom_radius = 0.145
        rc.height = 0.055
        ring.mesh = rc
        ring.position.y = y
        ring.material_override = _mat(Color(0.16,0.46,0.18),0.5)
        ring.visibility_range_end = MobileQualityManager.far_detail_distance(72.0)
        ring.visibility_range_end_margin = 7.0
        ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        _register_mobile_detail(ring, 72.0)
        root.add_child(ring)

func _spirit_light(pos: Vector3) -> void:
    var light := OmniLight3D.new()
    light.position = pos
    light.light_color = Color(0.33,0.72,1.0)
    light.light_energy = 1.35
    light.omni_range = 8.0
    light.omni_attenuation = 1.8
    light.shadow_enabled = false
    light.distance_fade_enabled = true
    light.distance_fade_begin = 26.0
    light.distance_fade_length = 10.0
    light.add_to_group("mobile_local_light")
    light.set_meta("base_energy", 1.35)
    light.set_meta("light_role", "spirit")
    add_child(light)
    var orb := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.18
    sm.height = 0.36
    orb.mesh = sm
    orb.position = pos
    var mat: StandardMaterial3D = _mat(Color(0.32,0.78,1.0),0.12).duplicate()
    mat.emission_enabled = true
    mat.emission = Color(0.22,0.72,1.0)
    mat.emission_energy_multiplier = 4.0
    orb.material_override = mat
    orb.visibility_range_end = MobileQualityManager.far_detail_distance(84.0)
    orb.visibility_range_end_margin = 8.0
    orb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    _register_mobile_detail(orb, 84.0)
    add_child(orb)


func _build_distant_silhouette() -> void:
    # Low-cost distant geometry gives the open world a much deeper silhouette.
    # It lives behind the gameplay spaces and is softened by exponential fog.
    var mountain_mesh := CylinderMesh.new()
    mountain_mesh.top_radius = 0.0
    mountain_mesh.bottom_radius = 8.5
    mountain_mesh.height = 24.0
    mountain_mesh.radial_segments = 7
    var transforms: Array = []
    for i in range(22):
        var a := TAU * float(i) / 22.0 + rng.randf_range(-0.09, 0.09)
        var radius := rng.randf_range(128.0, 154.0)
        var scale_v := rng.randf_range(0.72, 1.55)
        var p := Vector3(cos(a) * radius, 8.0 * scale_v - 1.2, sin(a) * radius)
        var basis := Basis(Vector3.UP, rng.randf_range(-PI, PI)).scaled(Vector3(scale_v, scale_v, scale_v))
        transforms.append(Transform3D(basis, p))
    _spawn_multimesh("DistantMountainSilhouette", mountain_mesh, _premium_surface_mat(Color(0.025,0.035,0.052),0.98,0.08,0.03,0.0), transforms, 210.0, false)

func _build_moon_disc() -> void:
    var moon := MeshInstance3D.new()
    moon.name = "MoonDisc"
    var sphere := SphereMesh.new()
    sphere.radius = 5.8
    sphere.height = 11.6
    sphere.radial_segments = 20
    sphere.rings = 10
    moon.mesh = sphere
    moon.position = Vector3(-92.0, 72.0, -188.0)
    moon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(0.70,0.79,1.0)
    mat.emission_enabled = true
    mat.emission = Color(0.56,0.68,1.0)
    mat.emission_energy_multiplier = 2.1
    mat.disable_fog = true
    moon.material_override = mat
    add_child(moon)

func _premium_surface_mat(color: Color, roughness: float, wetness: float, macro_scale: float, rim_strength: float) -> ShaderMaterial:
    var key := "premium_%s_%0.3f_%0.3f_%0.3f_%0.3f" % [color.to_html(), roughness, wetness, macro_scale, rim_strength]
    if _material_cache.has(key):
        return _material_cache[key]
    var mat := ShaderMaterial.new()
    mat.shader = WET_SURFACE_SHADER
    mat.set_shader_parameter("base_color", color)
    mat.set_shader_parameter("base_roughness", roughness)
    mat.set_shader_parameter("wetness", wetness)
    mat.set_shader_parameter("macro_scale", macro_scale)
    mat.set_shader_parameter("macro_strength", 0.08 if MobileQualityManager.current_tier <= MobileQualityManager.QualityTier.BALANCED else 0.13)
    mat.set_shader_parameter("rim_strength", rim_strength)
    mat.set_shader_parameter("clearcoat_strength", 0.18 if MobileQualityManager.current_tier >= MobileQualityManager.QualityTier.HIGH else 0.0)
    _material_cache[key] = mat
    return mat

func _spawn_population() -> void:
    _enemy("VillageOniA", Vector3(-8,0,-5), "Ash Oni", 1, 105, 15, 50, Color(0.48,0.07,0.07))
    _enemy("VillageOniB", Vector3(9,0,-7), "Ash Oni", 2, 125, 17, 58, Color(0.5,0.08,0.06))
    _boss("AkaganeOni", Vector3(0,0,-20), "akagane_oni", "AKAGANE ONI", 3, 520, 24, 260, Color(0.62,0.055,0.03), 1.6)

    for i in range(4):
        _enemy("FoxYokai%d"%i, Vector3(-71+i*7,0,-34-(i%2)*9), "Fox Shade", 5+i, 160+i*22, 20+i*2, 85+i*8, Color(0.52,0.12,0.34))
    _boss("Jorogumo", Vector3(-63,0,-57), "jorogumo", "JORŌGUMO", 7, 980, 34, 520, Color(0.62,0.08,0.38), 1.75)

    for i in range(4):
        _enemy("TenguScout%d"%i, Vector3(45+i*7,0,-60-(i%2)*10), "Tengu Scout", 9+i, 240+i*30, 28+i*2, 115+i*10, Color(0.18,0.25,0.36))
    _boss("KarasuTengu", Vector3(57,0,-84), "karasu_tengu", "KARASU-TENGU", 11, 1500, 46, 760, Color(0.14,0.18,0.28), 1.85)

    for i in range(4):
        _enemy("YomiWraith%d"%i, Vector3(61+i*8,0,23+(i%2)*12), "Yomi Wraith", 14+i, 330+i*40, 36+i*3, 145+i*12, Color(0.07,0.34,0.2))
    _boss("Gashadokuro", Vector3(76,0,47), "gashadokuro", "GASHADOKURO", 16, 2300, 61, 1050, Color(0.10,0.42,0.27), 2.15)

    for i in range(4):
        _enemy("HighlandOni%d"%i, Vector3(7+i*8,0,68+(i%2)*11), "War Oni", 17+i, 450+i*55, 45+i*4, 180+i*16, Color(0.60,0.12,0.05))

    _boss("OrochiWraith", Vector3(0,0,-114), "orochi_wraith", "OROCHI WRAITH", 20, 3900, 78, 1800, Color(0.38,0.06,0.55), 2.45)

    for i in range(5):
        _enemy("ReedSpecter%d"%i, Vector3(107+i*5,0,-3-(i%2)*9), "Reed Specter", 22+i, 520+i*65, 52+i*4, 205+i*18, Color(0.05,0.32,0.38))
    _boss("NureOnna", Vector3(126,0,-15), "nure_onna", "NURE-ONNA", 24, 5200, 92, 2350, Color(0.05,0.46,0.52), 2.35)

    for i in range(5):
        _enemy("NamahageGuard%d"%i, Vector3(-103+i*6,0,84+(i%2)*10), "Namahage Guard", 26+i, 650+i*70, 61+i*4, 240+i*20, Color(0.28,0.38,0.12))
    _boss("NamahageLord", Vector3(-98,0,104), "namahage_lord", "NAMAHAGE LORD", 28, 6900, 108, 3150, Color(0.34,0.50,0.12), 2.55)
    _boss("IzanamiShadow", Vector3(0,0,138), "izanami_shadow", "SHADOW OF IZANAMI", 32, 9200, 126, 5000, Color(0.46,0.025,0.12), 2.75)

func _enemy(node_name: String, pos: Vector3, title: String, lvl: int, hp: int, dmg: int, xp: int, color: Color) -> void:
    var e = ENEMY_SCENE.instantiate()
    e.name = node_name
    e.enemy_name = title
    e.enemy_level = lvl
    e.max_health = hp
    e.damage = dmg
    e.xp_reward = xp
    e.speed = 1.9 + minf(lvl * 0.035, 0.8)
    e.global_position = pos
    add_child(e, true)
    _enemy_color(e, color)

func _boss(node_name: String, pos: Vector3, id: String, title: String, lvl: int, hp: int, dmg: int, xp: int, color: Color, scale_v: float) -> void:
    var e = ENEMY_SCENE.instantiate()
    e.name = node_name
    e.enemy_name = title
    e.boss_id = id
    e.boss_title = title
    e.recommended_level = lvl
    e.enemy_level = lvl
    e.max_health = hp
    e.damage = dmg
    e.xp_reward = xp
    e.speed = 2.0 + minf(lvl * 0.028, 0.65)
    e.aggro_range = 28.0
    e.elite = true
    e.scale = Vector3.ONE * scale_v
    e.global_position = pos
    add_child(e, true)
    _enemy_color(e, color)

func _enemy_color(e: Node, color: Color) -> void:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.78
    e.get_node("Body").material_override = mat

func _plane(node_name: String, pos: Vector3, dims: Vector2, color: Color, rot: float) -> void:
    var m := MeshInstance3D.new()
    m.name = node_name
    var mesh := PlaneMesh.new()
    mesh.size = dims
    m.mesh = mesh
    m.position = pos
    m.rotation.y = rot
    m.material_override = _premium_surface_mat(color, 0.96, 0.34 if node_name.contains("Road") else 0.22, 0.055, 0.0)
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(m)

func _build_tree_multimeshes(records: Array) -> void:
    if records.is_empty():
        return
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.16
    trunk_mesh.bottom_radius = 0.25
    trunk_mesh.height = 2.7
    trunk_mesh.radial_segments = 7
    var trunk_transforms: Array = []
    var crowns: Array = [[], [], [], []]
    var collision_root := StaticBody3D.new()
    collision_root.name = "VegetationCollision"
    add_child(collision_root)
    for record in records:
        var p: Vector3 = record["position"]
        var scale_v: float = record["scale"]
        var rot: float = record["rotation"]
        var base_basis := Basis(Vector3.UP, rot).scaled(Vector3.ONE * scale_v)
        trunk_transforms.append(Transform3D(base_basis, p + Vector3(0, 1.35 * scale_v, 0)))
        var tint_id: int = record["tint"]
        for off in [Vector3(0,3.1,0), Vector3(0.45,2.8,0.2), Vector3(-0.42,2.75,-0.1)]:
            var crown_basis := Basis(Vector3.UP, rot).scaled(Vector3(1.25,0.8,1.15) * scale_v)
            crowns[tint_id].append(Transform3D(crown_basis, p + off * scale_v))
        var shape := CylinderShape3D.new()
        shape.radius = 0.24 * scale_v
        shape.height = 2.7 * scale_v
        var cs := CollisionShape3D.new()
        cs.shape = shape
        cs.position = p + Vector3(0, 1.35 * scale_v, 0)
        collision_root.add_child(cs)
    _spawn_multimesh("TreeTrunks", trunk_mesh, _mat(Color(0.16,0.08,0.04), 1.0), trunk_transforms, 112.0, false)
    var crown_mesh := SphereMesh.new()
    crown_mesh.radius = 1.0
    crown_mesh.height = 2.0
    crown_mesh.radial_segments = 8
    crown_mesh.rings = 4
    var colors := [Color(0.12,0.24,0.14), Color(0.48,0.16,0.3), Color(0.10,0.28,0.16), Color(0.27,0.13,0.07)]
    for i in range(4):
        if not crowns[i].is_empty():
            _spawn_multimesh("TreeCrowns%d" % i, crown_mesh, _foliage_mat(colors[i], 0.9, 0.055), crowns[i], 108.0, false)

func _build_rock_multimesh(records: Array) -> void:
    if records.is_empty():
        return
    var mesh := BoxMesh.new()
    mesh.size = Vector3(1.5,1.0,1.25)
    var transforms: Array = []
    var collision_root := StaticBody3D.new()
    collision_root.name = "RockCollision"
    add_child(collision_root)
    for record in records:
        var p: Vector3 = record["position"]
        var scale_v: float = record["scale"]
        var rot: Vector3 = record["rotation"]
        var basis := Basis.from_euler(rot).scaled(Vector3.ONE * scale_v)
        transforms.append(Transform3D(basis, p + Vector3(0,0.5*scale_v,0)))
        var shape := BoxShape3D.new()
        shape.size = Vector3(1.5,1.0,1.25) * scale_v
        var cs := CollisionShape3D.new()
        cs.shape = shape
        cs.position = p + Vector3(0,0.5*scale_v,0)
        cs.rotation = rot
        collision_root.add_child(cs)
    _spawn_multimesh("WorldRocks", mesh, _premium_surface_mat(Color(0.10,0.11,0.12),0.92,0.38,0.11,0.16), transforms, 96.0, false)

func _build_grass_multimesh(records: Array, color: Color) -> void:
    if records.is_empty():
        return
    var blade_mesh := BoxMesh.new()
    blade_mesh.size = Vector3(0.05, 0.72, 0.16)
    var transforms: Array = []
    for record in records:
        var p: Vector3 = record["position"]
        var scale_v: float = record["scale"]
        var rot: float = record["rotation"]
        for i in range(3):
            var local_offset := Vector3((i-1)*0.12, 0.34, (i%2)*0.08) * scale_v
            var basis := Basis(Vector3.UP, rot + i * 0.8)
            basis = basis.rotated(Vector3.FORWARD, (i-1) * 0.14)
            basis = basis.scaled(Vector3(scale_v, scale_v * (1.0 + i * 0.10), scale_v))
            transforms.append(Transform3D(basis, p + local_offset))
    _spawn_multimesh("GrassBatches", blade_mesh, _foliage_mat(color,0.92, 0.11), transforms, 52.0, false)

func _register_mobile_detail(instance: GeometryInstance3D, base_visibility: float) -> void:
    instance.add_to_group("mobile_detail")
    instance.set_meta("base_visibility", base_visibility)

func _spawn_multimesh(node_name: String, mesh: Mesh, material: Material, transforms: Array, base_visibility: float, casts_shadow: bool) -> void:
    if transforms.is_empty():
        return
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = transforms.size()
    for i in range(transforms.size()):
        mm.set_instance_transform(i, transforms[i])
    var instance := MultiMeshInstance3D.new()
    instance.name = node_name
    instance.multimesh = mm
    instance.material_override = material
    instance.visibility_range_end = MobileQualityManager.far_detail_distance(base_visibility)
    instance.visibility_range_end_margin = 8.0
    instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if casts_shadow else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    instance.add_to_group("mobile_detail")
    instance.set_meta("base_visibility", base_visibility)
    add_child(instance)

func _tree(pos: Vector3, scale_v: float, crown_color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    root.scale = Vector3.ONE * scale_v
    add_child(root)
    var trunk := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.16
    cm.bottom_radius = 0.25
    cm.height = 2.7
    trunk.mesh = cm
    trunk.position.y = 1.35
    trunk.material_override = _mat(Color(0.16,0.08,0.04), 1.0)
    root.add_child(trunk)
    var trunk_body := StaticBody3D.new()
    var trunk_collision := CollisionShape3D.new()
    var trunk_shape := CylinderShape3D.new()
    trunk_shape.radius = 0.24
    trunk_shape.height = 2.7
    trunk_collision.shape = trunk_shape
    trunk_collision.position.y = 1.35
    trunk_body.add_child(trunk_collision)
    root.add_child(trunk_body)
    for off in [Vector3(0,3.1,0), Vector3(0.45,2.8,0.2), Vector3(-0.42,2.75,-0.1)]:
        var crown := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 1.0
        sm.height = 2.0
        crown.mesh = sm
        crown.position = off
        crown.scale = Vector3(1.25,0.8,1.15)
        crown.material_override = _mat(crown_color, 0.9)
        root.add_child(crown)

func _rock(pos: Vector3, scale_v: float) -> void:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = Vector3(1.5,1.0,1.25)
    m.mesh = b
    m.position = pos + Vector3(0,0.5*scale_v,0)
    m.rotation = Vector3(rng.randf_range(-0.2,0.2),rng.randf_range(-PI,PI),rng.randf_range(-0.18,0.18))
    m.scale = Vector3.ONE*scale_v
    m.material_override = _mat(Color(0.10,0.11,0.12),1.0)
    add_child(m)
    var body := StaticBody3D.new()
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(1.5,1.0,1.25) * scale_v
    collision.shape = shape
    collision.position = pos + Vector3(0,0.5*scale_v,0)
    collision.rotation = m.rotation
    body.add_child(collision)
    add_child(body)

func _mountain(pos: Vector3, radius: float, height: float) -> void:
    var m := MeshInstance3D.new()
    var c := CylinderMesh.new()
    c.top_radius = radius * 0.12
    c.bottom_radius = radius
    c.height = height
    c.radial_segments = 7
    m.mesh = c
    m.position = pos + Vector3(0,height*0.5-0.15,0)
    m.material_override = _mat(Color(0.055,0.065,0.07),1.0)
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(m)
    var body := StaticBody3D.new()
    var collision := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = radius * 0.82
    shape.height = height
    collision.shape = shape
    collision.position = pos + Vector3(0,height*0.5-0.15,0)
    body.add_child(collision)
    add_child(body)

func _torii(pos: Vector3, scale_v: float, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    root.scale = Vector3.ONE*scale_v
    add_child(root)
    _box(root, Vector3(-2.1,2.2,0), Vector3(0.34,4.4,0.34), color)
    _box(root, Vector3(2.1,2.2,0), Vector3(0.34,4.4,0.34), color)
    _box(root, Vector3(0,4.25,0), Vector3(5.9,0.38,0.48), color)
    _box(root, Vector3(0,3.62,0), Vector3(4.8,0.27,0.38), color)

func _shrine(pos: Vector3, color: Color, scale_v: float = 1.0) -> void:
    var root := Node3D.new()
    root.position = pos
    root.add_to_group("sanctuaries")
    root.scale = Vector3.ONE*scale_v
    add_child(root)
    _box(root, Vector3(0,1.2,0), Vector3(5.5,2.4,4.0), Color(0.16,0.12,0.095))
    _box(root, Vector3(0,2.65,0), Vector3(6.8,0.38,4.9), color)
    _box(root, Vector3(0,3.0,0), Vector3(5.7,0.30,4.2), color)
    _box(root, Vector3(0,0.35,2.55), Vector3(6.4,0.7,1.5), Color(0.22,0.2,0.17))

func _lantern(pos: Vector3, color: Color) -> void:
    var root := Node3D.new()
    root.position = pos
    add_child(root)
    _box(root, Vector3(0,0.7,0), Vector3(0.16,1.4,0.16), Color(0.12,0.09,0.06))
    var m := MeshInstance3D.new()
    var c := CylinderMesh.new()
    c.top_radius = 0.28
    c.bottom_radius = 0.28
    c.height = 0.62
    m.mesh = c
    m.position.y = 1.45
    var mat: StandardMaterial3D = _mat(color,0.5).duplicate()
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 2.3
    m.material_override = mat
    root.add_child(m)
    var light := OmniLight3D.new()
    light.position = Vector3(0, 1.45, 0)
    light.light_color = color
    light.light_energy = 0.72
    light.omni_range = 4.6
    light.omni_attenuation = 1.65
    light.shadow_enabled = false
    light.distance_fade_enabled = true
    light.distance_fade_begin = 18.0
    light.distance_fade_length = 7.0
    light.add_to_group("mobile_local_light")
    light.set_meta("base_energy", 0.72)
    light.set_meta("light_role", "lantern")
    root.add_child(light)

func _zone_label(txt: String, pos: Vector3, color: Color) -> void:
    var l := Label3D.new()
    l.text = txt
    l.position = pos
    l.font_size = 42
    l.outline_size = 12
    l.modulate = color
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = true
    l.visibility_range_end = MobileQualityManager.far_detail_distance(105.0)
    l.visibility_range_end_margin = 12.0
    _register_mobile_detail(l, 105.0)
    add_child(l)

func _box(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
    var m := MeshInstance3D.new()
    var b := BoxMesh.new()
    b.size = size
    m.mesh = b
    m.position = pos
    m.material_override = _mat(color,0.82)
    parent.add_child(m)

func _npc(node_name: String, pos: Vector3, title: String, dialogue: String, quest_id: String, color: Color) -> void:
    var root := Node3D.new()
    root.name = node_name
    root.position = pos
    root.add_to_group("npcs")
    root.set_meta("title", title)
    root.set_meta("dialogue", dialogue)
    root.set_meta("quest_id", quest_id)
    add_child(root)
    var body := MeshInstance3D.new()
    var cap := CapsuleMesh.new()
    cap.radius = 0.32
    cap.height = 1.45
    body.mesh = cap
    body.position.y = 0.78
    body.material_override = _mat(color.darkened(0.35), 0.8)
    root.add_child(body)
    var head := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.28
    sm.height = 0.56
    head.mesh = sm
    head.position.y = 1.72
    head.material_override = _mat(Color(0.78,0.62,0.53), 0.9)
    root.add_child(head)
    var label := Label3D.new()
    label.text = title + "\n[INTERACT]"
    label.position = Vector3(0,2.45,0)
    label.font_size = 22
    label.outline_size = 8
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.no_depth_test = true
    root.add_child(label)

func _loot_chest(chest_id: String, pos: Vector3, item_id: String, amount: int, color: Color) -> void:
    var root := Node3D.new()
    root.name = chest_id
    root.position = pos
    root.add_to_group("world_loot")
    root.set_meta("chest_id", chest_id)
    root.set_meta("item_id", item_id)
    root.set_meta("amount", amount)
    add_child(root)
    var box := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(1.25,0.72,0.82)
    box.mesh = bm
    box.position.y = 0.42
    box.material_override = _mat(color.darkened(0.45), 0.75)
    root.add_child(box)
    var glow := MeshInstance3D.new()
    var gm := SphereMesh.new()
    gm.radius = 0.34
    gm.height = 0.68
    glow.mesh = gm
    glow.position.y = 1.25
    var mat: StandardMaterial3D = _mat(color,0.2).duplicate()
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 2.2
    glow.material_override = mat
    root.add_child(glow)
    var label := Label3D.new()
    label.text = "RELIC CACHE"
    label.position = Vector3(0,1.85,0)
    label.font_size = 20
    label.outline_size = 7
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.no_depth_test = true
    root.add_child(label)

func _mat(color: Color, roughness: float) -> StandardMaterial3D:
    var key := "%s|%.3f" % [color.to_html(true), roughness]
    if _material_cache.has(key):
        return _material_cache[key]
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = roughness
    _material_cache[key] = mat
    return mat

func _foliage_mat(color: Color, roughness: float, sway_strength: float) -> ShaderMaterial:
    var scaled_sway := sway_strength * (0.55 if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.PERFORMANCE else (0.78 if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.BALANCED else 1.0))
    var key := "%s|%.3f|%.3f" % [color.to_html(true), roughness, scaled_sway]
    if _foliage_material_cache.has(key):
        return _foliage_material_cache[key]
    var shader := Shader.new()
    shader.code = """shader_type spatial;
render_mode cull_disabled;
uniform vec4 albedo_color : source_color = vec4(0.2, 0.35, 0.2, 1.0);
uniform float roughness_value = 0.9;
uniform float sway_strength = 0.06;
uniform float sway_speed = 1.45;
void vertex() {
    float phase = (MODEL_MATRIX[3].x + MODEL_MATRIX[3].z) * 0.11;
    float height_weight = clamp(VERTEX.y + 0.25, 0.0, 1.4);
    float wave = sin(TIME * sway_speed + phase) * sway_strength * height_weight;
    VERTEX.x += wave;
    VERTEX.z += cos(TIME * sway_speed * 0.71 + phase) * sway_strength * 0.28 * height_weight;
}
void fragment() {
    ALBEDO = albedo_color.rgb;
    ROUGHNESS = roughness_value;
}
"""
    var mat := ShaderMaterial.new()
    mat.shader = shader
    mat.set_shader_parameter("albedo_color", color)
    mat.set_shader_parameter("roughness_value", roughness)
    mat.set_shader_parameter("sway_strength", scaled_sway)
    _foliage_material_cache[key] = mat
    return mat

func _near_landmark(p: Vector3) -> bool:
    for center in [Vector3(0,0,8),Vector3(-62,0,-42),Vector3(55,0,-66),Vector3(72,0,30),Vector3(18,0,76),Vector3(0,0,-102),Vector3(118,0,-8),Vector3(-92,0,92),Vector3(0,0,132)]:
        if Vector2(p.x-center.x,p.z-center.z).length() < 14.0:
            return true
    return false
