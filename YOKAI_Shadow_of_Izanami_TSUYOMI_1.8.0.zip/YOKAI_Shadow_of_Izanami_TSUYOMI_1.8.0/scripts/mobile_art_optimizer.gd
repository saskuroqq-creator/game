extends Node

# KAGE 1.7 — runtime policy for authored GLB/GLTF art.
# Keeps the hero visually expensive while scaling enemy materials/shadows/LODs for phones.

func _ready() -> void:
    if not MobileQualityManager.quality_changed.is_connected(_on_quality_changed):
        MobileQualityManager.quality_changed.connect(_on_quality_changed)

func register_authored_root(root: Node, role: String = "environment") -> void:
    if root == null:
        return
    root.add_to_group("mobile_authored_art")
    root.set_meta("mobile_art_role", role)
    optimize_subtree(root, role)

func optimize_subtree(root: Node, role: String = "environment") -> void:
    if root == null:
        return
    _optimize_node_recursive(root, role)

func _on_quality_changed(_tier_name: String) -> void:
    for root in get_tree().get_nodes_in_group("mobile_authored_art"):
        if not is_instance_valid(root):
            continue
        optimize_subtree(root, String(root.get_meta("mobile_art_role", "environment")))

func _optimize_node_recursive(node: Node, role: String) -> void:
    if node is MeshInstance3D:
        _optimize_mesh(node as MeshInstance3D, role)
    for child in node.get_children():
        _optimize_node_recursive(child, role)

func _optimize_mesh(mesh_instance: MeshInstance3D, role: String) -> void:
    var tier := MobileQualityManager.current_tier
    match tier:
        MobileQualityManager.QualityTier.PERFORMANCE:
            mesh_instance.lod_bias = 0.56
        MobileQualityManager.QualityTier.BALANCED:
            mesh_instance.lod_bias = 0.76
        MobileQualityManager.QualityTier.HIGH:
            mesh_instance.lod_bias = 1.0
        MobileQualityManager.QualityTier.ULTRA:
            mesh_instance.lod_bias = 1.32

    if role == "player":
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    elif role == "boss":
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if tier >= MobileQualityManager.QualityTier.BALANCED else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    elif role == "enemy":
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if tier >= MobileQualityManager.QualityTier.HIGH else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

    if mesh_instance.mesh == null:
        return
    for surface_index in range(mesh_instance.mesh.get_surface_count()):
        var material := mesh_instance.get_active_material(surface_index)
        if material is BaseMaterial3D:
            var base := material as BaseMaterial3D
            if tier >= MobileQualityManager.QualityTier.HIGH:
                base.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
            else:
                base.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
            # TSUYOMI: spend the material budget where the player actually looks.
            if role == "player" and tier >= MobileQualityManager.QualityTier.HIGH:
                base.rim_enabled = true
                base.rim = 0.16 if tier == MobileQualityManager.QualityTier.HIGH else 0.22
                base.rim_tint = 0.74
                base.clearcoat_enabled = tier == MobileQualityManager.QualityTier.ULTRA
                base.clearcoat = 0.24
                base.clearcoat_roughness = 0.34
            elif role == "boss" and tier >= MobileQualityManager.QualityTier.HIGH:
                base.rim_enabled = true
                base.rim = 0.14
                base.rim_tint = 0.62
                base.clearcoat_enabled = false
            else:
                base.rim_enabled = false
                base.clearcoat_enabled = false
