extends Node

## Optional live facial-capture receiver for authoring/testing.
## Disabled in shipping by default. Accepts UDP JSON packets:
## {"blendshapes":{"eyeBlinkLeft":0.2,"jawOpen":0.8,...}}

@export var enabled := false
@export var listen_port := 17171
@export var listen_address := "127.0.0.1"
@export var blendshape_bridge_path: NodePath = NodePath("../FacialBlendshapeBridge")

var udp := PacketPeerUDP.new()
var bridge: Node
var bound := false

func _ready() -> void:
    bridge = get_node_or_null(blendshape_bridge_path)
    if not enabled:
        set_process(false)
        return
    var err := udp.bind(listen_port, listen_address)
    bound = err == OK
    if not bound:
        push_warning("YOKAI facial capture UDP bind failed on %s:%d" % [listen_address, listen_port])
        set_process(false)

func _exit_tree() -> void:
    if bound:
        udp.close()
        bound = false

func _process(_delta: float) -> void:
    if bridge == null:
        return
    while udp.get_available_packet_count() > 0:
        var text := udp.get_packet().get_string_from_utf8()
        var parsed = JSON.parse_string(text)
        if not parsed is Dictionary:
            continue
        var payload := parsed as Dictionary
        var frame = payload.get("blendshapes", payload)
        if frame is Dictionary and bridge.has_method("apply_face_frame"):
            bridge.apply_face_frame(frame)
