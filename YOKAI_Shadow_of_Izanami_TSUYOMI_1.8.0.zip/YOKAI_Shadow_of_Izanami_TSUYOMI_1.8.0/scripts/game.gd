extends Node3D

const PLAYER_SCENE := preload("res://scenes/Player.tscn")
const AMBIENT_NIGHT = preload("res://audio/night_ambience.wav")
var spawned_players: Dictionary = {}
var paused := false
var hud_timer := 0.0
var current_interactable: Node = null

@onready var players_root: Node3D = $Players
@onready var pause_panel: Control = $UI/PausePanel
@onready var stats_panel: Control = $UI/StatsPanel
@onready var connection_label: Label = $UI/Connection
@onready var quest_label: Label = $UI/QuestPanel/Margin/Quest
@onready var zone_label: Label = $UI/Zone
@onready var level_label: Label = $UI/HUD/Margin/VBox/Level
@onready var rank_label: Label = $UI/HUD/Margin/VBox/Rank
@onready var hp_bar: ProgressBar = $UI/HUD/Margin/VBox/HP
@onready var spirit_bar: ProgressBar = $UI/HUD/Margin/VBox/Spirit
@onready var xp_bar: ProgressBar = $UI/HUD/Margin/VBox/XP
@onready var hp_text: Label = $UI/HUD/Margin/VBox/HPText
@onready var stats_text: Label = $UI/HUD/Margin/VBox/StatsMini
@onready var boss_warning: Label = $UI/BossWarning
@onready var level_banner: Label = $UI/LevelBanner
@onready var dialogue_panel: Panel = $UI/DialoguePanel
@onready var dialogue_speaker: Label = $UI/DialoguePanel/Margin/VBox/Speaker
@onready var dialogue_text: Label = $UI/DialoguePanel/Margin/VBox/Text
@onready var world_environment: WorldEnvironment = $WorldEnvironment
@onready var moon_light: DirectionalLight3D = $MoonLight
@onready var warm_fill: DirectionalLight3D = $WarmFill

var gear_label: Label
var sidequest_label: Label
var target_label: Label
var interact_prompt: Label
var loot_toast: Label
var boss_panel: Panel
var boss_name: Label
var boss_bar: ProgressBar
var resonance_label: Label
var threat_vignette: ColorRect
var party_panel: Panel
var party_labels: Array[Label] = []
var combat_state_label: Label
var lock_reticle: Label
var atmosphere_clock := 0.0
var ambient_player: AudioStreamPlayer
var quality_button: Button

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _build_runtime_ui()
    MobileQualityManager.apply_game_scene(self)
    MobileQualityManager.quality_changed.connect(_on_quality_changed)
    _start_ambient_audio()
    pause_panel.visible = false
    stats_panel.visible = false
    level_banner.visible = false
    dialogue_panel.visible = false
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    StoryManager.story_changed.connect(_refresh_story)
    Progression.profile_changed.connect(_refresh_hud)
    Progression.leveled_up.connect(_show_level_banner)
    InventoryManager.inventory_changed.connect(_refresh_hud)
    InventoryManager.item_obtained.connect(_show_loot_toast)
    QuestManager.quests_changed.connect(_refresh_sidequests)
    QuestManager.quest_completed.connect(_show_quest_complete)

    if multiplayer.multiplayer_peer is OfflineMultiplayerPeer:
        _spawn_player_local(1)
        connection_label.text = "SOLO • OPEN WORLD"
    elif multiplayer.is_server():
        _spawn_player_local(multiplayer.get_unique_id())
        connection_label.text = "HOST • %s:%d" % [NetworkManager.get_lan_ipv4(), NetworkManager.PORT]
    else:
        connection_label.text = "CLIENT • CONNECTED"
        call_deferred("_announce_ready")

    $UI/PauseButton.pressed.connect(_toggle_pause)
    $UI/StatsButton.pressed.connect(func(): stats_panel.call("toggle"))
    $UI/PausePanel/VBox/Resume.pressed.connect(_toggle_pause)
    $UI/PausePanel/VBox/Stats.pressed.connect(func(): stats_panel.visible = true; pause_panel.visible = false; get_tree().paused = false; paused = false)
    $UI/PausePanel/VBox/MainMenu.pressed.connect(_return_to_menu)
    $UI/DialoguePanel/Margin/VBox/Continue.pressed.connect(func(): dialogue_panel.visible = false)
    _refresh_story()
    _refresh_hud()
    _refresh_sidequests()
    call_deferred("_show_chapter_dialogue")

func _process(delta: float) -> void:
    hud_timer -= delta
    if hud_timer <= 0.0:
        hud_timer = 0.08
        _refresh_hud()
        _refresh_zone_boss_target()
        _refresh_interaction()
    _update_atmosphere(delta)

func _unhandled_input(event: InputEvent) -> void:
    if event.is_action_pressed("pause_game"):
        _toggle_pause()
    elif event.is_action_pressed("stats_menu"):
        stats_panel.call("toggle")
    elif event.is_action_pressed("interact"):
        _interact_world()

func _build_runtime_ui() -> void:
    gear_label = Label.new()
    gear_label.position = Vector2(20, 210)
    gear_label.size = Vector2(365, 28)
    gear_label.add_theme_font_size_override("font_size", 14)
    gear_label.add_theme_color_override("font_color", Color(1.0,0.72,0.3))
    $UI.add_child(gear_label)

    sidequest_label = Label.new()
    sidequest_label.position = Vector2(18, 250)
    sidequest_label.size = Vector2(345, 120)
    sidequest_label.add_theme_font_size_override("font_size", 13)
    sidequest_label.add_theme_color_override("font_color", Color(0.72,0.82,0.92))
    sidequest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    $UI.add_child(sidequest_label)

    target_label = Label.new()
    target_label.position = Vector2(455, 178)
    target_label.size = Vector2(370, 32)
    target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    target_label.add_theme_font_size_override("font_size", 16)
    target_label.add_theme_color_override("font_color", Color(0.72,0.88,1.0))
    $UI.add_child(target_label)

    interact_prompt = Label.new()
    interact_prompt.position = Vector2(390, 430)
    interact_prompt.size = Vector2(500, 44)
    interact_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    interact_prompt.add_theme_font_size_override("font_size", 20)
    interact_prompt.add_theme_color_override("font_color", Color(1.0,0.88,0.45))
    $UI.add_child(interact_prompt)

    loot_toast = Label.new()
    loot_toast.position = Vector2(420, 382)
    loot_toast.size = Vector2(440, 42)
    loot_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    loot_toast.add_theme_font_size_override("font_size", 18)
    loot_toast.visible = false
    $UI.add_child(loot_toast)

    boss_panel = Panel.new()
    boss_panel.position = Vector2(360, 230)
    boss_panel.size = Vector2(560, 66)
    boss_panel.visible = false
    boss_panel.add_theme_stylebox_override("panel", _runtime_panel_style(Color(0.74,0.15,0.16,0.82), Color(0.015,0.02,0.03,0.90)))
    $UI.add_child(boss_panel)
    boss_name = Label.new()
    boss_name.position = Vector2(12, 5)
    boss_name.size = Vector2(536, 25)
    boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    boss_name.add_theme_font_size_override("font_size", 17)
    boss_name.add_theme_color_override("font_color", Color(1.0,0.45,0.36))
    boss_panel.add_child(boss_name)
    boss_bar = ProgressBar.new()
    boss_bar.position = Vector2(18, 34)
    boss_bar.size = Vector2(524, 18)
    boss_bar.show_percentage = false
    boss_panel.add_child(boss_bar)

    resonance_label = Label.new()
    resonance_label.position = Vector2(470, 666)
    resonance_label.size = Vector2(340, 28)
    resonance_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    resonance_label.add_theme_font_size_override("font_size", 14)
    resonance_label.add_theme_color_override("font_color", Color(0.48,0.9,1.0))
    resonance_label.text = ""
    $UI.add_child(resonance_label)

    combat_state_label = Label.new()
    combat_state_label.position = Vector2(430, 615)
    combat_state_label.size = Vector2(420, 42)
    combat_state_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    combat_state_label.add_theme_font_size_override("font_size", 18)
    combat_state_label.add_theme_color_override("font_color", Color(1.0,0.84,0.48))
    combat_state_label.add_theme_color_override("font_outline_color", Color(0.02,0.025,0.035,0.95))
    combat_state_label.add_theme_constant_override("outline_size", 6)
    combat_state_label.text = ""
    $UI.add_child(combat_state_label)

    lock_reticle = Label.new()
    lock_reticle.size = Vector2(60, 60)
    lock_reticle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    lock_reticle.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    lock_reticle.add_theme_font_size_override("font_size", 38)
    lock_reticle.add_theme_color_override("font_color", Color(0.75,0.92,1.0,0.95))
    lock_reticle.add_theme_color_override("font_outline_color", Color(0.01,0.02,0.03,0.9))
    lock_reticle.add_theme_constant_override("outline_size", 5)
    lock_reticle.text = "◇"
    lock_reticle.visible = false
    lock_reticle.mouse_filter = Control.MOUSE_FILTER_IGNORE
    $UI.add_child(lock_reticle)

    party_panel = Panel.new()
    party_panel.position = Vector2(1000, 18)
    party_panel.size = Vector2(262, 158)
    party_panel.add_theme_stylebox_override("panel", _runtime_panel_style(Color(0.15,0.42,0.62,0.68), Color(0.012,0.022,0.034,0.86)))
    $UI.add_child(party_panel)
    var party_title := Label.new()
    party_title.position = Vector2(12, 8)
    party_title.size = Vector2(238, 24)
    party_title.text = "猟  HUNTER PARTY"
    party_title.add_theme_font_size_override("font_size", 16)
    party_title.add_theme_color_override("font_color", Color(0.82,0.91,1.0))
    party_panel.add_child(party_title)
    for i in range(4):
        var line := Label.new()
        line.position = Vector2(12, 36 + i * 28)
        line.size = Vector2(238, 26)
        line.add_theme_font_size_override("font_size", 13)
        line.add_theme_color_override("font_color", Color(0.76,0.82,0.9))
        line.text = "—"
        party_panel.add_child(line)
        party_labels.append(line)

    quality_button = Button.new()
    quality_button.text = "GRAPHICS • %s" % MobileQualityManager.quality_name()
    quality_button.tooltip_text = "Cycle mobile graphics preset"
    $UI/PausePanel/VBox.add_child(quality_button)
    quality_button.pressed.connect(MobileQualityManager.cycle_quality)

    threat_vignette = ColorRect.new()
    threat_vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    threat_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
    threat_vignette.color = Color(0.35,0.015,0.03,0.0)
    threat_vignette.z_index = -1
    $UI.add_child(threat_vignette)

func _on_quality_changed(tier_name: String) -> void:
    if quality_button != null:
        quality_button.text = "GRAPHICS • %s" % tier_name
    MobileQualityManager.apply_game_scene(self)

func _runtime_panel_style(border: Color, bg: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = bg
    style.border_color = border
    style.border_width_left = 2
    style.border_width_top = 2
    style.border_width_right = 2
    style.border_width_bottom = 2
    style.corner_radius_top_left = 12
    style.corner_radius_top_right = 12
    style.corner_radius_bottom_left = 12
    style.corner_radius_bottom_right = 12
    style.shadow_color = Color(0,0,0,0.36)
    style.shadow_size = 8
    return style

func _announce_ready() -> void:
    await get_tree().create_timer(0.15).timeout
    _client_ready.rpc_id(1)

@rpc("any_peer", "reliable")
func _client_ready() -> void:
    if not multiplayer.is_server():
        return
    var new_peer_id := multiplayer.get_remote_sender_id()
    for existing_id in spawned_players.keys():
        _spawn_player.rpc_id(new_peer_id, int(existing_id))
    _spawn_player.rpc(new_peer_id)

@rpc("authority", "call_local", "reliable")
func _spawn_player(peer_id: int) -> void:
    _spawn_player_local(peer_id)

func _spawn_player_local(peer_id: int) -> void:
    if spawned_players.has(peer_id):
        return
    var player := PLAYER_SCENE.instantiate()
    player.name = "Player_%d" % peer_id
    player.set_multiplayer_authority(peer_id)
    players_root.add_child(player, true)
    player.global_position = Vector3((peer_id % 4) * 1.6 - 2.4, 0.15, 8.0)
    spawned_players[peer_id] = player

func _local_player() -> Node:
    for p in spawned_players.values():
        if is_instance_valid(p) and p.is_multiplayer_authority():
            return p
    return null

func _refresh_hud() -> void:
    level_label.text = "LEVEL %d" % Progression.level
    rank_label.text = "RANK %s" % Progression.rank_name()
    xp_bar.max_value = Progression.xp_to_next()
    xp_bar.value = Progression.xp
    stats_text.text = "STR %d   VIT %d   AGI %d   SPI %d   FOC %d\nSTAT PTS %d  •  SKILL PTS %d" % [Progression.strength, Progression.vitality, Progression.agility, Progression.spirit, Progression.focus, Progression.stat_points, Progression.skill_points]
    gear_label.text = "GEAR SCORE %d  •  %s" % [InventoryManager.gear_score(), InventoryManager.item_name(String(InventoryManager.equipped.get("weapon", "iron_katana")))]
    var p = _local_player()
    if p != null:
        hp_bar.max_value = p._max_health()
        hp_bar.value = p.health
        spirit_bar.max_value = p._max_spirit()
        spirit_bar.value = p.spirit_energy
        hp_text.text = "HP %d/%d     SPIRIT %d/%d" % [p.health, p._max_health(), int(p.spirit_energy), p._max_spirit()]
        if p.downed:
            hp_text.text = "DOWNED • %.0fs • ALLY MUST REVIVE" % p.bleedout_remaining
        var allies_near := 0
        for ally in get_tree().get_nodes_in_group("players"):
            if ally != p and is_instance_valid(ally) and not ally.downed and p.global_position.distance_to(ally.global_position) <= 8.0:
                allies_near += 1
        resonance_label.text = "共鳴  HUNTER RESONANCE  +%d%% DAMAGE" % min(12, allies_near * 4) if allies_near > 0 else ""
        combat_state_label.text = p.combat_message
        if p.guard_active and p.combat_message.is_empty():
            combat_state_label.text = "GUARD • V / HOLD"
        elif p.sprinting and p.combat_message.is_empty():
            combat_state_label.text = "SPRINT • SHIFT"
    _refresh_party_panel()

func _refresh_story() -> void:
    quest_label.text = StoryManager.objective_text()
    if is_inside_tree():
        call_deferred("_show_chapter_dialogue")

func _refresh_sidequests() -> void:
    if sidequest_label != null:
        sidequest_label.text = "SIDE HUNTS\n" + QuestManager.active_summary()

func _show_chapter_dialogue() -> void:
    if StoryManager.chapter_intro().is_empty():
        return
    dialogue_speaker.text = StoryManager.chapter_speaker()
    dialogue_text.text = StoryManager.chapter_intro()
    dialogue_panel.visible = true

func _refresh_zone_boss_target() -> void:
    var p = _local_player()
    if p == null:
        return
    zone_label.text = _zone_name(p.global_position)
    if p.lock_on_target != null and is_instance_valid(p.lock_on_target):
        target_label.text = "LOCKED • %s • LV.%d • %.0fm" % [p.lock_on_target.enemy_name, p.lock_on_target.enemy_level, p.global_position.distance_to(p.lock_on_target.global_position)]
        if p.camera != null and not p.camera.is_position_behind(p.lock_on_target.global_position):
            var screen_pos := p.camera.unproject_position(p.lock_on_target.global_position + Vector3(0, 1.55, 0))
            lock_reticle.position = screen_pos - lock_reticle.size * 0.5
            lock_reticle.visible = true
        else:
            lock_reticle.visible = false
    else:
        target_label.text = ""
        lock_reticle.visible = false

    var nearest: Node = null
    var best := INF
    for b in get_tree().get_nodes_in_group("bosses"):
        if not is_instance_valid(b):
            continue
        var d := p.global_position.distance_to(b.global_position)
        if d < best:
            best = d
            nearest = b
    if nearest != null and best < 36.0:
        boss_warning.visible = true
        var danger := "DANGER" if Progression.level + 2 < nearest.recommended_level else "BOSS"
        boss_warning.text = "%s • %s • RECOMMENDED LV.%d • %.0fm" % [danger, nearest.boss_title, nearest.recommended_level, best]
        boss_panel.visible = true
        threat_vignette.color.a = lerpf(threat_vignette.color.a, 0.11 if nearest.phase < 3 else 0.18, 0.18)
        boss_name.text = "%s  •  PHASE %d  •  LV.%d" % [nearest.boss_title, nearest.phase, nearest.enemy_level]
        boss_bar.max_value = nearest.max_health
        boss_bar.value = nearest.health
    else:
        boss_warning.visible = false
        boss_panel.visible = false
        threat_vignette.color.a = lerpf(threat_vignette.color.a, 0.0, 0.14)

func _refresh_interaction() -> void:
    var p = _local_player()
    if p == null or p.downed:
        current_interactable = null
        interact_prompt.text = ""
        return
    for ally in get_tree().get_nodes_in_group("players"):
        if ally != p and is_instance_valid(ally) and ally.downed and p.global_position.distance_to(ally.global_position) < 3.2:
            var pct := int(clampf(p.revive_progress / 1.85, 0.0, 1.0) * 100.0)
            interact_prompt.text = "HOLD R / USE • REVIVE ALLY  %d%%" % pct
            current_interactable = null
            return
    current_interactable = null
    var best := 3.2
    for node in get_tree().get_nodes_in_group("world_loot") + get_tree().get_nodes_in_group("npcs") + get_tree().get_nodes_in_group("sanctuaries"):
        if not is_instance_valid(node):
            continue
        var d := p.global_position.distance_to(node.global_position)
        if d < best:
            best = d
            current_interactable = node
    if current_interactable == null:
        interact_prompt.text = ""
        return
    if current_interactable.is_in_group("world_loot"):
        var chest_id := String(current_interactable.get_meta("chest_id", ""))
        interact_prompt.text = "RELIC CACHE OPENED" if InventoryManager.is_world_loot_opened(chest_id) else "OPEN RELIC CACHE  •  R / INTERACT"
    elif current_interactable.is_in_group("sanctuaries"):
        interact_prompt.text = "PRAY • REST / SET CHECKPOINT  •  R / INTERACT"
    else:
        interact_prompt.text = "TALK  •  R / INTERACT"

func _interact_world() -> void:
    if current_interactable == null or not is_instance_valid(current_interactable):
        return
    if current_interactable.is_in_group("world_loot"):
        var chest_id := String(current_interactable.get_meta("chest_id", ""))
        var item_id := String(current_interactable.get_meta("item_id", ""))
        var amount := int(current_interactable.get_meta("amount", 1))
        if InventoryManager.claim_world_loot(chest_id, item_id, amount):
            current_interactable.scale.y = 0.45
    elif current_interactable.is_in_group("sanctuaries"):
        var p = _local_player()
        if p != null:
            p.set_checkpoint(current_interactable.global_position + Vector3(0,0.3,4.0))
            _show_loot_toast("healing_ofuda", 0)
            loot_toast.text = "SANCTUARY RESTORED • CHECKPOINT SET"
    elif current_interactable.is_in_group("npcs"):
        dialogue_speaker.text = String(current_interactable.get_meta("title", "TRAVELER"))
        dialogue_text.text = String(current_interactable.get_meta("dialogue", "...")) + "\n\n" + QuestManager.active_summary()
        dialogue_panel.visible = true

func _refresh_party_panel() -> void:
    var members := get_tree().get_nodes_in_group("players")
    members.sort_custom(func(a, b): return a.get_multiplayer_authority() < b.get_multiplayer_authority())
    for i in range(party_labels.size()):
        var label := party_labels[i]
        if i >= members.size():
            label.text = "—"
            label.modulate = Color(1,1,1,0.42)
            continue
        var member = members[i]
        if not is_instance_valid(member):
            label.text = "—"
            continue
        var local_mark := "YOU" if member.is_multiplayer_authority() else "ALLY"
        var state := "DOWNED %.0fs" % member.bleedout_remaining if member.downed else "%d/%d HP" % [member.health, member._max_health()]
        label.text = "%s • [%s] LV.%d • %s" % [local_mark, member.profile_rank, member.profile_level, state]
        label.modulate = Color(1.0,0.58,0.58,1.0) if member.downed else Color(0.82,0.91,1.0,1.0)

func _update_atmosphere(delta: float) -> void:
    var p = _local_player()
    if p == null or world_environment.environment == null:
        return
    atmosphere_clock += delta
    var env := world_environment.environment
    var fog_target := Color(0.20, 0.28, 0.39)
    var ambient_target := Color(0.28, 0.34, 0.50)
    var moon_target := Color(0.62, 0.73, 1.0)
    var fill_target := Color(1.0, 0.42, 0.25)
    var density_target := 0.007
    var pos: Vector3 = p.global_position
    if pos.z > 116 and abs(pos.x) < 36:
        fog_target = Color(0.24,0.055,0.16)
        ambient_target = Color(0.24,0.10,0.18)
        moon_target = Color(0.92,0.52,0.68)
        fill_target = Color(0.95,0.12,0.22)
        density_target = 0.016
    elif pos.x > 92 and abs(pos.z) < 36:
        fog_target = Color(0.08,0.34,0.39)
        ambient_target = Color(0.12,0.31,0.35)
        moon_target = Color(0.42,0.86,0.94)
        density_target = 0.014
    elif pos.x < -67 and pos.z > 62:
        fog_target = Color(0.18,0.30,0.18)
        ambient_target = Color(0.19,0.30,0.20)
        moon_target = Color(0.67,0.86,0.66)
        density_target = 0.010
    elif pos.z < -86 and abs(pos.x) < 27:
        fog_target = Color(0.25,0.12,0.38)
        ambient_target = Color(0.25,0.20,0.40)
        moon_target = Color(0.76,0.66,1.0)
        fill_target = Color(0.85,0.22,0.30)
        density_target = 0.012
    elif pos.x > 45 and pos.z > 2:
        fog_target = Color(0.12,0.28,0.22)
        ambient_target = Color(0.17,0.29,0.23)
        density_target = 0.013
    var boss_pressure := 0.0
    for b in get_tree().get_nodes_in_group("bosses"):
        if is_instance_valid(b):
            var d := p.global_position.distance_to(b.global_position)
            if d < 32.0:
                boss_pressure = maxf(boss_pressure, 1.0 - d / 32.0)
    if boss_pressure > 0.0:
        fill_target = fill_target.lerp(Color(1.0,0.10,0.14), boss_pressure * 0.7)
        density_target += boss_pressure * 0.004
    var pulse := sin(atmosphere_clock * 0.17) * 0.015
    env.fog_light_color = env.fog_light_color.lerp(fog_target, minf(delta * 0.65, 1.0))
    env.ambient_light_color = env.ambient_light_color.lerp(ambient_target, minf(delta * 0.55, 1.0))
    env.fog_density = lerpf(env.fog_density, density_target + pulse * density_target, minf(delta * 0.5, 1.0))
    moon_light.light_color = moon_light.light_color.lerp(moon_target, minf(delta * 0.45, 1.0))
    warm_fill.light_color = warm_fill.light_color.lerp(fill_target, minf(delta * 0.55, 1.0))
    warm_fill.light_energy = lerpf(warm_fill.light_energy, 0.31 + boss_pressure * 0.28, minf(delta * 0.8, 1.0))

func _start_ambient_audio() -> void:
    ambient_player = AudioStreamPlayer.new()
    ambient_player.stream = AMBIENT_NIGHT
    ambient_player.volume_db = -25.0
    ambient_player.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(ambient_player)
    ambient_player.finished.connect(_restart_ambient_audio)
    ambient_player.play()

func _restart_ambient_audio() -> void:
    if ambient_player != null and is_instance_valid(ambient_player):
        ambient_player.play()

func _zone_name(pos: Vector3) -> String:
    if pos.z > 116 and abs(pos.x) < 36: return "黄泉門 VEILED GATE • FINAL HUNT"
    if pos.x > 92 and abs(pos.z) < 36: return "水 DROWNED SHRINE"
    if pos.x < -67 and pos.z > 62: return "竹 BAMBOO HOLLOW"
    if pos.z < -86 and abs(pos.x) < 27: return "☾ MOONFALL SHRINE"
    if pos.x < -38 and pos.z < -14: return "狐 KITSUNE FOREST"
    if pos.x > 35 and pos.z < -38: return "天狗 TENGU RIDGE"
    if pos.x > 45 and pos.z > 2: return "黄泉 YOMI MARSH"
    if pos.z > 48 and pos.x > -18 and pos.x < 52: return "鬼 ONI HIGHLANDS"
    return "星川 HOSHIKAWA PROVINCE"

func _show_level_banner(new_level: int) -> void:
    level_banner.text = "LEVEL UP\n%d\n+3 STAT POINTS   +1 SKILL POINT" % new_level
    level_banner.visible = true
    level_banner.modulate.a = 0.0
    var tween := create_tween()
    tween.tween_property(level_banner, "modulate:a", 1.0, 0.25)
    tween.tween_interval(1.5)
    tween.tween_property(level_banner, "modulate:a", 0.0, 0.45)
    tween.tween_callback(func(): level_banner.visible = false)

func _show_loot_toast(item_id: String, amount: int) -> void:
    loot_toast.text = "+ LOOT  •  %s x%d  •  %s" % [InventoryManager.item_name(item_id), amount, InventoryManager.rarity(item_id)]
    loot_toast.add_theme_color_override("font_color", InventoryManager.rarity_color(item_id))
    loot_toast.visible = true
    loot_toast.modulate.a = 1.0
    var tween := create_tween()
    tween.tween_interval(1.8)
    tween.tween_property(loot_toast, "modulate:a", 0.0, 0.5)
    tween.tween_callback(func(): loot_toast.visible = false)

func _show_quest_complete(quest_id: String) -> void:
    var data: Dictionary = QuestManager.QUESTS.get(quest_id, {})
    level_banner.text = "HUNT COMPLETE\n%s\nREWARD CLAIMED" % String(data.get("title", quest_id))
    level_banner.visible = true
    level_banner.modulate.a = 1.0
    var tween := create_tween()
    tween.tween_interval(2.0)
    tween.tween_property(level_banner, "modulate:a", 0.0, 0.5)
    tween.tween_callback(func(): level_banner.visible = false)

func _on_peer_disconnected(peer_id: int) -> void:
    if spawned_players.has(peer_id):
        var player: Node = spawned_players[peer_id]
        if is_instance_valid(player):
            player.queue_free()
        spawned_players.erase(peer_id)

func _toggle_pause() -> void:
    paused = not paused
    pause_panel.visible = paused
    get_tree().paused = paused

func _return_to_menu() -> void:
    get_tree().paused = false
    NetworkManager.disconnect_network()
    get_tree().change_scene_to_file("res://scenes/Main.tscn")
