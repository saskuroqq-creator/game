extends CharacterBody3D

const SFX_IMPACT = preload("res://audio/impact.wav")
const SFX_PARRY = preload("res://audio/parry.wav")
const SFX_BOSS_ROAR = preload("res://audio/boss_roar.wav")

@export var enemy_name := "ONI"
@export var enemy_level := 1
@export var max_health := 80
@export var speed := 2.2
@export var damage := 10
@export var xp_reward := 45
@export var aggro_range := 18.0
@export var boss_id := ""
@export var boss_title := ""
@export var recommended_level := 1
@export var elite := false

var health := 80
var attack_timer := 0.0
var special_timer := 5.0
var special_busy := false
var attack_busy := false
var phase := 1
var dead := false
var last_attacker_peer := 1
var previous_attacker_peer := 0
var coop_chain_time := 0.0
var stagger := 0.0
var stagger_max := 100.0
var stagger_stun := 0.0
var special_index := 0
var party_scaled := false
var base_max_health := 80
var base_damage := 10
var movement_clock := 0.0
var orbit_sign := 1.0
var attack_range := 1.95
var ranged_profile := false
var ranged_timer := 1.8
var preferred_range := 5.0

# KAGE 1.7: cache group-heavy AI queries so large encounters stay smooth on phones.
var cached_target: Node3D = null
var target_refresh_timer := 0.0
var cached_separation := Vector3.ZERO
var separation_refresh_timer := 0.0
var cached_attack_slot := true
var attack_slot_refresh_timer := 0.0
var state_sync_timer := 0.0

@onready var hp_label: Label3D = $HPLabel
@onready var body: MeshInstance3D = $Body
@onready var aura: MeshInstance3D = $Aura

func _ready() -> void:
    add_to_group("enemies")
    if boss_id != "":
        add_to_group("bosses")
    base_max_health = max_health
    base_damage = damage
    health = max_health
    orbit_sign = -1.0 if int(get_instance_id()) % 2 == 0 else 1.0
    attack_range = 2.45 if boss_id != "" else 1.95
    _configure_combat_archetype()
    aura.visible = elite or boss_id != ""
    if aura.material_override != null:
        aura.material_override = aura.material_override.duplicate()
    _build_archetype_visuals()
    _update_hp()

func _physics_process(delta: float) -> void:
    if dead:
        return
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return

    attack_timer = maxf(attack_timer - delta, 0.0)
    ranged_timer = maxf(ranged_timer - delta, 0.0)
    coop_chain_time = maxf(coop_chain_time - delta, 0.0)
    stagger_stun = maxf(stagger_stun - delta, 0.0)
    stagger = maxf(stagger - (5.0 if boss_id != "" else 9.0) * delta, 0.0)
    special_timer = maxf(special_timer - delta, 0.0)
    if stagger_stun > 0.0:
        velocity = Vector3.ZERO
        _sync_state_budgeted(delta)
        return
    var target := _cached_nearest_player(delta)
    if target == null:
        velocity = Vector3.ZERO
        return

    if not party_scaled:
        _apply_party_scaling()
    movement_clock += delta
    var to_target: Vector3 = target.global_position - global_position
    var flat := Vector3(to_target.x, 0, to_target.z)
    if flat.length() > aggro_range:
        velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
        return

    if boss_id != "" and phase >= 2 and special_timer <= 0.0 and not special_busy:
        special_timer = 6.8 if phase == 2 else 4.8
        _boss_special()

    var phase_speed := speed * (1.0 + (phase - 1) * 0.14)
    var distance := flat.length()
    var dir := flat.normalized() if distance > 0.05 else -global_transform.basis.z
    var tangent := Vector3(-dir.z, 0.0, dir.x) * orbit_sign
    var separation := _cached_separation_vector(delta)
    var has_attack_slot := _cached_attack_slot_available(target, delta)
    if ranged_profile and distance > attack_range + 0.20:
        if ranged_timer <= 0.0 and distance <= 10.5 and not attack_busy and not special_busy:
            ranged_timer = randf_range(2.8, 4.4)
            _ranged_windup(target)
        var ranged_dir := dir
        if distance > preferred_range + 0.75:
            ranged_dir = (dir + separation * 0.72).normalized()
        elif distance < preferred_range - 0.75:
            ranged_dir = (-dir + tangent * 0.45 + separation * 0.9).normalized()
        else:
            ranged_dir = (tangent * 0.90 + separation * 0.75).normalized()
        var ranged_speed := phase_speed * (0.82 if attack_busy else 1.0)
        velocity.x = move_toward(velocity.x, ranged_dir.x * ranged_speed, 7.4 * delta)
        velocity.z = move_toward(velocity.z, ranged_dir.z * ranged_speed, 7.4 * delta)
        rotation.y = lerp_angle(rotation.y, atan2(-flat.normalized().x, -flat.normalized().z), (7.0 + phase) * delta)
        move_and_slide()
        _sync_state_budgeted(delta)
        return
    if distance > attack_range + 0.20:
        if distance < 7.5:
            var orbit_strength := 0.20 if boss_id != "" else (0.30 if not has_attack_slot else 0.10)
            dir = (dir + tangent * orbit_strength + separation * 0.82).normalized()
        var chase_accel := 7.5 + phase * 1.8
        velocity.x = move_toward(velocity.x, dir.x * phase_speed, chase_accel * delta)
        velocity.z = move_toward(velocity.z, dir.z * phase_speed, chase_accel * delta)
        rotation.y = lerp_angle(rotation.y, atan2(-flat.normalized().x, -flat.normalized().z), (7.0 + phase) * delta)
        move_and_slide()
    else:
        if attack_timer <= 0.0 and not special_busy and not attack_busy and has_attack_slot:
            velocity.x = move_toward(velocity.x, 0.0, 16.0 * delta)
            velocity.z = move_toward(velocity.z, 0.0, 16.0 * delta)
            attack_timer = maxf(0.78, 1.42 - (phase - 1) * 0.20)
            _melee_windup(target)
        else:
            var hold_dir := (tangent * 0.72 + separation * 1.15).normalized()
            var hold_speed := phase_speed * (0.42 if boss_id == "" else 0.32)
            velocity.x = move_toward(velocity.x, hold_dir.x * hold_speed, 8.0 * delta)
            velocity.z = move_toward(velocity.z, hold_dir.z * hold_speed, 8.0 * delta)
            rotation.y = lerp_angle(rotation.y, atan2(-flat.normalized().x, -flat.normalized().z), (7.0 + phase) * delta)
            move_and_slide()

    _sync_state_budgeted(delta)


func _cached_nearest_player(delta: float) -> Node3D:
    target_refresh_timer = maxf(target_refresh_timer - delta, 0.0)
    if cached_target == null or not is_instance_valid(cached_target) or cached_target.downed or target_refresh_timer <= 0.0:
        cached_target = _nearest_player()
        var interval := 0.12 if boss_id != "" else 0.18
        if cached_target != null:
            var distance_sq := global_position.distance_squared_to(cached_target.global_position)
            if distance_sq > 1600.0:
                interval = 0.46
            elif distance_sq > 400.0:
                interval = 0.30
        target_refresh_timer = interval
    return cached_target

func _cached_separation_vector(delta: float) -> Vector3:
    separation_refresh_timer = maxf(separation_refresh_timer - delta, 0.0)
    if separation_refresh_timer <= 0.0:
        cached_separation = _separation_vector()
        separation_refresh_timer = 0.08 if boss_id != "" else 0.14
    return cached_separation

func _cached_attack_slot_available(target: Node3D, delta: float) -> bool:
    if boss_id != "":
        return true
    attack_slot_refresh_timer = maxf(attack_slot_refresh_timer - delta, 0.0)
    if attack_slot_refresh_timer <= 0.0:
        cached_attack_slot = _attack_slot_available(target)
        attack_slot_refresh_timer = 0.12
    return cached_attack_slot

func _sync_state_budgeted(delta: float) -> void:
    state_sync_timer = maxf(state_sync_timer - delta, 0.0)
    if state_sync_timer > 0.0:
        return
    var interval := 0.05 if boss_id != "" else 0.075
    if cached_target != null and is_instance_valid(cached_target):
        var d := global_position.distance_to(cached_target.global_position)
        if d > 38.0:
            interval = 0.20
        elif d > 18.0:
            interval = 0.12
    state_sync_timer = interval
    _sync_state.rpc(global_position, rotation.y, health, phase)

func _configure_combat_archetype() -> void:
    ranged_profile = enemy_name.contains("Fox Shade") or enemy_name.contains("Tengu Scout") or enemy_name.contains("Yomi Wraith") or enemy_name.contains("Reed Specter")
    if ranged_profile:
        preferred_range = 5.0 + minf(enemy_level * 0.025, 0.65)
        ranged_timer = randf_range(1.1, 2.5)

func _ranged_windup(target: Node3D) -> void:
    if attack_busy or not is_instance_valid(target):
        return
    attack_busy = true
    var impact_position := target.global_position
    var cast_color := _spirit_projectile_color()
    _spirit_bolt_fx.rpc(impact_position, cast_color, 0.62)
    await get_tree().create_timer(0.62).timeout
    if dead:
        attack_busy = false
        return
    var hit_radius := 1.55 + minf(enemy_level * 0.008, 0.30)
    for p in get_tree().get_nodes_in_group("players"):
        if not is_instance_valid(p) or p.downed:
            continue
        var flat_delta: Vector3 = p.global_position - impact_position
        flat_delta.y = 0.0
        if flat_delta.length() <= hit_radius:
            p.receive_damage(maxi(1, int(damage * 0.74)), self)
    attack_busy = false

func _spirit_projectile_color() -> Color:
    if enemy_name.contains("Fox"):
        return Color(1.0, 0.24, 0.58)
    if enemy_name.contains("Tengu"):
        return Color(0.42, 0.78, 1.0)
    if enemy_name.contains("Wraith"):
        return Color(0.36, 1.0, 0.66)
    return Color(0.28, 0.92, 1.0)

@rpc("authority", "call_local", "reliable")
func _spirit_bolt_fx(impact_position: Vector3, color: Color, travel_time: float) -> void:
    var bolt := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.16
    mesh.height = 0.32
    bolt.mesh = mesh
    bolt.top_level = true
    bolt.global_position = global_position + Vector3(0.0, 1.45, 0.0)
    var mat := StandardMaterial3D.new()
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(color.r, color.g, color.b, 0.92)
    mat.emission_enabled = true
    mat.emission = color
    mat.emission_energy_multiplier = 6.5
    bolt.material_override = mat
    get_tree().current_scene.add_child(bolt)
    var bolt_allowed := MobileVFXBudget.try_register(bolt, 2, 1, 0.0)
    if not bolt_allowed:
        bolt.visible = false

    var marker := MeshInstance3D.new()
    var ring := CylinderMesh.new()
    ring.top_radius = 1.55
    ring.bottom_radius = 1.55
    ring.height = 0.035
    marker.mesh = ring
    marker.top_level = true
    marker.global_position = impact_position + Vector3(0.0, 0.035, 0.0)
    var marker_mat := StandardMaterial3D.new()
    marker_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    marker_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    marker_mat.albedo_color = Color(color.r, color.g, color.b, 0.22)
    marker_mat.emission_enabled = true
    marker_mat.emission = color
    marker_mat.emission_energy_multiplier = 2.8
    marker.material_override = marker_mat
    get_tree().current_scene.add_child(marker)
    MobileVFXBudget.try_register(marker, 1, 3, 0.0)

    var target_pos := impact_position + Vector3(0.0, 0.55, 0.0)
    var tween := create_tween().set_parallel(true)
    tween.tween_property(bolt, "global_position", target_pos, travel_time).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    tween.tween_property(marker, "scale", Vector3(1.18, 1.0, 1.18), travel_time)
    tween.tween_property(marker, "modulate:a", 0.55, travel_time * 0.82)
    await get_tree().create_timer(travel_time).timeout
    if is_instance_valid(bolt):
        var burst := create_tween().set_parallel(true)
        burst.tween_property(bolt, "scale", Vector3(2.7, 2.7, 2.7), 0.10)
        burst.tween_property(bolt, "modulate:a", 0.0, 0.12)
        burst.chain().tween_callback(bolt.queue_free)
    if is_instance_valid(marker):
        var fade := create_tween()
        fade.tween_property(marker, "modulate:a", 0.0, 0.14)
        fade.tween_callback(marker.queue_free)

func _attack_slot_available(target: Node3D) -> bool:
    if boss_id != "":
        return true
    var active_attackers := 0
    for e in get_tree().get_nodes_in_group("enemies"):
        if e == self or not is_instance_valid(e):
            continue
        if e.attack_busy and e.global_position.distance_to(target.global_position) < 4.2:
            active_attackers += 1
    return active_attackers < 2

func _separation_vector() -> Vector3:
    var force := Vector3.ZERO
    for e in get_tree().get_nodes_in_group("enemies"):
        if e == self or not is_instance_valid(e):
            continue
        var away := global_position - e.global_position
        away.y = 0.0
        var d := away.length()
        if d > 0.02 and d < 2.35:
            force += away.normalized() * ((2.35 - d) / 2.35)
    return force.normalized() if force.length() > 0.01 else Vector3.ZERO

func apply_damage(amount: int, attacker_peer: int = 1, stagger_bonus: float = 0.0) -> void:
    if dead:
        return
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    var coop_proc := previous_attacker_peer != 0 and previous_attacker_peer != attacker_peer and coop_chain_time > 0.0
    previous_attacker_peer = attacker_peer
    coop_chain_time = 1.35
    last_attacker_peer = attacker_peer
    if coop_proc:
        amount = int(amount * 1.18)
        stagger += 24.0 if boss_id != "" else 34.0
        _coop_resonance_fx.rpc()
    else:
        stagger += 8.0 if boss_id != "" else 14.0
    stagger += stagger_bonus * (0.72 if boss_id != "" else 1.0)
    if stagger >= stagger_max:
        stagger = 0.0
        stagger_stun = 0.75 if boss_id != "" else 1.35
        amount = int(amount * 1.32)
        _stagger_break_fx.rpc()
    _damage_number_fx.rpc(amount, coop_proc)
    health = maxi(health - amount, 0)
    if boss_id != "":
        if health <= int(max_health * 0.25) and phase < 3:
            phase = 3
            _phase_fx.rpc(phase)
        elif health <= int(max_health * 0.55) and phase < 2:
            phase = 2
            _phase_fx.rpc(phase)
    _hit_fx.rpc()
    _sync_health.rpc(health)
    if health <= 0:
        dead = true
        _reward_players()
        if boss_id != "":
            _boss_story_sync.rpc(boss_id)
        _die.rpc()

func _boss_special() -> void:
    special_busy = true
    velocity = Vector3.ZERO
    special_index += 1
    if phase >= 3 and special_index % 2 == 0 and boss_id != "":
        await _boss_signature_special()
        special_busy = false
        return
    var pattern := (special_index + phase + boss_id.length()) % 3
    var radius := 5.2 + phase * 0.9
    var multiplier := 1.05 + phase * 0.18
    var windup := 0.72 if phase == 2 else 0.56
    if pattern == 1:
        radius += 2.2
    elif pattern == 2:
        radius += 1.4
    _telegraph_fx.rpc(radius, phase, pattern)
    await get_tree().create_timer(windup).timeout
    if dead:
        special_busy = false
        return
    _apply_boss_pattern_damage(pattern, radius, multiplier)
    special_busy = false

func _apply_boss_pattern_damage(pattern: int, radius: float, multiplier: float) -> void:
    var forward := -global_transform.basis.z.normalized()
    for p in get_tree().get_nodes_in_group("players"):
        if not is_instance_valid(p) or p.downed:
            continue
        var to_player: Vector3 = p.global_position - global_position
        var flat := Vector3(to_player.x, 0.0, to_player.z)
        var dist := flat.length()
        var hit := false
        if pattern == 0:
            hit = dist <= radius
        elif pattern == 1:
            hit = dist <= radius and dist > 0.05 and forward.dot(flat.normalized()) > 0.38
        else:
            hit = dist >= 2.4 and dist <= radius
        if hit:
            p.receive_damage(int(damage * multiplier), self)

func _boss_signature_special() -> void:
    match boss_id:
        "jorogumo":
            await _signature_barrage("SILKEN GRAVE", Color(0.92, 0.20, 0.68), 3, 0.28, 1.18)
        "karasu_tengu":
            await _signature_barrage("TEMPEST FEATHERS", Color(0.40, 0.78, 1.0), 2, 0.18, 1.24)
        "gashadokuro":
            _signature_fx.rpc("BONE EARTHQUAKE", Color(0.82, 0.76, 0.56))
            _telegraph_fx.rpc(9.2, phase, 2)
            await get_tree().create_timer(0.72).timeout
            if not dead:
                _apply_boss_pattern_damage(2, 9.2, 1.34)
        "orochi_wraith":
            var target := _nearest_player()
            if target != null:
                var flat := target.global_position - global_position
                flat.y = 0.0
                if flat.length() > 0.05:
                    rotation.y = atan2(-flat.normalized().x, -flat.normalized().z)
            _signature_fx.rpc("OROCHI DEVOUR", Color(0.74, 0.28, 1.0))
            _telegraph_fx.rpc(10.0, phase, 1)
            await get_tree().create_timer(0.64).timeout
            if not dead:
                _apply_boss_pattern_damage(1, 10.0, 1.42)
        "nure_onna":
            await _signature_barrage("DROWNED REFLECTION", Color(0.18, 0.92, 1.0), 4, 0.22, 1.08)
        "namahage_lord":
            var target := _nearest_player()
            if target != null:
                var flat := target.global_position - global_position
                flat.y = 0.0
                if flat.length() > 0.05:
                    rotation.y = atan2(-flat.normalized().x, -flat.normalized().z)
            _signature_fx.rpc("WAR DRUM CHARGE", Color(1.0, 0.42, 0.18))
            _telegraph_fx.rpc(8.8, phase, 1)
            await get_tree().create_timer(0.46).timeout
            if not dead:
                var forward := -global_transform.basis.z.normalized()
                global_position += forward * 3.2
                _apply_boss_pattern_damage(1, 8.8, 1.36)
        "izanami_shadow":
            _signature_fx.rpc("MIRROR OF IZANAMI", Color(1.0, 0.22, 0.56))
            await _signature_barrage("", Color(1.0, 0.22, 0.56), 4, 0.16, 1.12)
            if not dead:
                _telegraph_fx.rpc(8.4, phase, 2)
                await get_tree().create_timer(0.52).timeout
                if not dead:
                    _apply_boss_pattern_damage(2, 8.4, 1.30)
        _:
            _signature_fx.rpc("CURSED ASCENSION", Color(0.86, 0.22, 0.30))
            _telegraph_fx.rpc(7.8, phase, 0)
            await get_tree().create_timer(0.58).timeout
            if not dead:
                _apply_boss_pattern_damage(0, 7.8, 1.28)

func _signature_barrage(title: String, color: Color, waves: int, spacing: float, multiplier: float) -> void:
    if title != "":
        _signature_fx.rpc(title, color)
    var snapshots: Array[Vector3] = []
    for wave in range(waves):
        snapshots.clear()
        for p in get_tree().get_nodes_in_group("players"):
            if not is_instance_valid(p) or p.downed:
                continue
            var offset := Vector3(
                sin(float(wave) * 1.7 + float(p.get_instance_id() % 7)) * 0.75,
                0.0,
                cos(float(wave) * 1.3 + float(p.get_instance_id() % 5)) * 0.75
            )
            var target_pos: Vector3 = p.global_position + offset
            snapshots.append(target_pos)
            _spirit_bolt_fx.rpc(target_pos, color, 0.56)
        await get_tree().create_timer(0.56).timeout
        if dead:
            return
        for impact in snapshots:
            _damage_players_near_point(impact, 1.72, multiplier)
        if wave < waves - 1:
            await get_tree().create_timer(spacing).timeout

func _damage_players_near_point(point: Vector3, radius: float, multiplier: float) -> void:
    for p in get_tree().get_nodes_in_group("players"):
        if not is_instance_valid(p) or p.downed:
            continue
        var delta_v: Vector3 = p.global_position - point
        delta_v.y = 0.0
        if delta_v.length() <= radius:
            p.receive_damage(maxi(1, int(damage * multiplier)), self)

func _melee_windup(target: Node3D) -> void:
    attack_busy = true
    _melee_telegraph_fx.rpc()
    await get_tree().create_timer(0.28 if boss_id == "" else 0.38).timeout
    if dead or not is_instance_valid(target):
        attack_busy = false
        return
    if global_position.distance_to(target.global_position) <= attack_range + (0.55 if boss_id != "" else 0.42):
        target.receive_damage(int(damage * (1.0 + (phase - 1) * 0.18)), self)
    attack_busy = false

func apply_deflect(attacker_peer: int, stagger_amount: float) -> void:
    if dead:
        return
    if not multiplayer.is_server() and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
        return
    last_attacker_peer = attacker_peer
    stagger += stagger_amount * (0.72 if boss_id != "" else 1.0)
    _deflect_fx.rpc()
    if stagger >= stagger_max:
        stagger = 0.0
        stagger_stun = 0.95 if boss_id != "" else 1.55
        _stagger_break_fx.rpc()

func _reward_players() -> void:
    for p in get_tree().get_nodes_in_group("players"):
        if not is_instance_valid(p):
            continue
        var reward := xp_reward if p.get_multiplayer_authority() == last_attacker_peer else int(xp_reward * 0.75)
        p.award_xp_server(reward)
        p.notify_kill_server(enemy_name)
        if boss_id != "":
            var item_id := _boss_drop()
            if item_id != "":
                p.award_loot_server(item_id, 1)
        elif randf() < 0.34:
            p.award_loot_server("spirit_shard", 1)

func _boss_drop() -> String:
    match boss_id:
        "akagane_oni": return "moonfang_katana"
        "jorogumo": return "spider_silk_haori"
        "karasu_tengu": return "tengu_edge"
        "gashadokuro": return "boneguard_armor"
        "orochi_wraith": return "orochi_fang"
        "nure_onna": return "foxfire_charm"
        "namahage_lord": return "raijin_charm"
        "izanami_shadow": return "veilbreaker_katana"
        _: return ""


@rpc("authority", "call_local", "unreliable")
func _damage_number_fx(amount: int, resonance: bool) -> void:
    var label := Label3D.new()
    label.text = str(amount)
    label.position = Vector3(randf_range(-0.22, 0.22), 2.25 + randf_range(-0.08, 0.18), 0.0)
    label.font_size = 34 if not resonance else 42
    label.outline_size = 9
    label.no_depth_test = true
    label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    label.modulate = Color(0.92, 0.96, 1.0, 1.0) if not resonance else Color(0.40, 0.95, 1.0, 1.0)
    add_child(label)
    var tween := create_tween().set_parallel(true)
    tween.tween_property(label, "position", label.position + Vector3(0.0, 0.85, 0.0), 0.52).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_property(label, "modulate:a", 0.0, 0.58).set_delay(0.12)
    tween.tween_property(label, "scale", Vector3(1.16, 1.16, 1.16), 0.20)
    tween.chain().tween_callback(label.queue_free)

@rpc("authority", "call_local", "reliable")
func _coop_resonance_fx() -> void:
    aura.visible = true
    var mat := aura.material_override as StandardMaterial3D
    if mat != null:
        mat.albedo_color = Color(0.42, 0.92, 1.0, 0.34)
        mat.emission = Color(0.28, 0.82, 1.0)
        mat.emission_energy_multiplier = 4.2
    aura.scale = Vector3(0.7, 0.12, 0.7)
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(2.4, 0.18, 2.4), 0.16)
    tween.tween_property(aura, "modulate:a", 0.0, 0.20)
    tween.tween_callback(func(): aura.modulate.a = 1.0; aura.visible = elite or boss_id != "")

@rpc("authority", "call_local", "reliable")
func _stagger_break_fx() -> void:
    hp_label.text = "STAGGER BREAK • %s" % enemy_name
    var start := scale
    var tween := create_tween()
    tween.tween_property(self, "scale", start * Vector3(1.12, 0.88, 1.12), 0.08)
    tween.tween_property(self, "scale", start, 0.16)
    tween.finished.connect(_update_hp)

@rpc("authority", "call_local", "reliable")
func _boss_story_sync(id: String) -> void:
    StoryManager.boss_defeated(id)

@rpc("authority", "call_local", "reliable")
func _sync_health(value: int) -> void:
    health = value
    _update_hp()

@rpc("authority", "call_local", "reliable")
func _hit_fx() -> void:
    _play_sfx(SFX_IMPACT, 0.86 + randf_range(-0.08, 0.10), -8.0)
    _spawn_hit_sparks()
    var old_scale := body.scale
    var tween := create_tween()
    tween.tween_property(body, "scale", old_scale * 1.08, 0.06)
    tween.tween_property(body, "scale", old_scale, 0.10)

@rpc("authority", "call_local", "reliable")
func _phase_fx(new_phase: int) -> void:
    _play_sfx(SFX_BOSS_ROAR, 0.88 + new_phase * 0.04, -3.0)
    aura.visible = true
    hp_label.text = "%s • PHASE %d" % [boss_title, new_phase]
    var target_scale := 1.55 if new_phase == 2 else 1.9
    var tween := create_tween().set_loops(3)
    tween.tween_property(aura, "scale", Vector3(target_scale,target_scale,target_scale), 0.16)
    tween.tween_property(aura, "scale", Vector3(1.0,1.45,1.0), 0.16)
    tween.finished.connect(_update_hp)

@rpc("authority", "call_local", "reliable")
func _signature_fx(title: String, color: Color) -> void:
    _play_sfx(SFX_BOSS_ROAR, 0.78, -1.5)
    hp_label.text = "%s • %s" % [boss_title if boss_title != "" else enemy_name, title]
    aura.visible = true
    var mat := aura.material_override as StandardMaterial3D
    if mat != null:
        mat.albedo_color = Color(color.r, color.g, color.b, 0.32)
        mat.emission = color
        mat.emission_energy_multiplier = 5.2
    var tween := create_tween().set_loops(2)
    tween.tween_property(aura, "scale", Vector3(2.2, 0.16, 2.2), 0.18)
    tween.tween_property(aura, "scale", Vector3(1.0, 1.45, 1.0), 0.16)
    tween.finished.connect(_update_hp)

@rpc("authority", "call_local", "reliable")
func _telegraph_fx(radius: float, new_phase: int, pattern: int) -> void:
    aura.visible = true
    var base_scale := Vector3(1.0, 1.45, 1.0)
    aura.scale = base_scale
    var target := Vector3(radius * 0.72, 0.12, radius * 0.72)
    if pattern == 1:
        hp_label.text = "%s • CLEAVING HOWL" % boss_title
        target = Vector3(radius * 0.46, 0.10, radius * 0.92)
    elif pattern == 2:
        hp_label.text = "%s • HOLLOW RING" % boss_title
    else:
        hp_label.text = "%s • CURSED PULSE" % boss_title
    var tween := create_tween()
    tween.tween_property(aura, "scale", target, 0.48 if new_phase >= 3 else 0.66)
    tween.tween_property(aura, "scale", base_scale, 0.12)
    tween.finished.connect(_update_hp)

@rpc("authority", "call_local", "reliable")
func _melee_telegraph_fx() -> void:
    aura.visible = true
    aura.scale = Vector3(0.72, 0.10, 0.72)
    var tween := create_tween()
    tween.tween_property(aura, "scale", Vector3(1.55, 0.12, 1.55), 0.24)
    tween.tween_property(aura, "scale", Vector3(1.0, 1.45, 1.0), 0.10)

@rpc("authority", "call_local", "reliable")
func _deflect_fx() -> void:
    _play_sfx(SFX_PARRY, 0.90, -6.0)
    _spawn_hit_sparks(Color(1.0, 0.70, 0.20))
    var start := rotation.z
    var tween := create_tween()
    tween.tween_property(self, "rotation:z", start + 0.14, 0.07)
    tween.tween_property(self, "rotation:z", start - 0.10, 0.07)
    tween.tween_property(self, "rotation:z", start, 0.10)

@rpc("authority", "call_local", "reliable")
func _die() -> void:
    var tween := create_tween()
    tween.tween_property(self, "scale", Vector3(1.0, 0.05, 1.0), 0.28)
    tween.tween_callback(queue_free)

@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_state(pos: Vector3, rot_y: float, hp_value: int, phase_value: int) -> void:
    global_position = global_position.lerp(pos, 0.34)
    rotation.y = lerp_angle(rotation.y, rot_y, 0.34)
    health = hp_value
    phase = phase_value
    _update_hp()

func _nearest_player() -> Node3D:
    var nearest: Node3D = null
    var best := INF
    for p in get_tree().get_nodes_in_group("players"):
        if not is_instance_valid(p) or p.downed:
            continue
        var d := global_position.distance_squared_to(p.global_position)
        if d < best:
            best = d
            nearest = p
    return nearest

func _update_hp() -> void:
    var prefix := "BOSS" if boss_id != "" else ("ELITE" if elite else "YŌKAI")
    hp_label.text = "%s • %s • LV.%d\n%d / %d" % [prefix, enemy_name, enemy_level, health, max_health]
    if boss_id != "":
        hp_label.text += "  •  P%d" % phase
    if stagger > 0.0:
        hp_label.text += "\nSTAGGER %d%%" % int(clampf(stagger / stagger_max, 0.0, 1.0) * 100.0)


func _apply_party_scaling() -> void:
    party_scaled = true
    var party_size := 0
    for p in get_tree().get_nodes_in_group("players"):
        if is_instance_valid(p):
            party_size += 1
    party_size = clampi(party_size, 1, 4)
    var hp_scale := 1.0 + (party_size - 1) * (0.48 if boss_id != "" else 0.30)
    var damage_scale := 1.0 + (party_size - 1) * (0.12 if boss_id != "" else 0.08)
    max_health = maxi(int(base_max_health * hp_scale), 1)
    health = max_health
    damage = maxi(int(base_damage * damage_scale), 1)
    stagger_max = 100.0 + (party_size - 1) * (22.0 if boss_id != "" else 12.0)
    _update_hp()

func _spawn_hit_sparks(color: Color = Color(0.85, 0.92, 1.0)) -> void:
    var spark_count := clampi(int(round(5.0 * MobileVFXBudget.density_multiplier())), 2, 8)
    var priority := 2 if boss_id != "" else 1
    for i in range(spark_count):
        var spark := MeshInstance3D.new()
        var mesh := BoxMesh.new()
        mesh.size = Vector3(0.035, 0.035, 0.42)
        spark.mesh = mesh
        spark.position = Vector3(0.0, 1.15 + randf_range(-0.25, 0.35), 0.0)
        spark.rotation = Vector3(randf_range(-0.6, 0.6), randf_range(-PI, PI), randf_range(-0.8, 0.8))
        var mat := StandardMaterial3D.new()
        mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        mat.albedo_color = Color(color.r, color.g, color.b, 0.95)
        mat.emission_enabled = true
        mat.emission = color
        mat.emission_energy_multiplier = 4.5 if MobileQualityManager.current_tier < MobileQualityManager.QualityTier.ULTRA else 6.0
        spark.material_override = mat
        add_child(spark)
        if not MobileVFXBudget.try_register(spark, 1, priority, 0.0):
            spark.queue_free()
            continue
        var dir := Vector3(randf_range(-1.0, 1.0), randf_range(0.35, 1.2), randf_range(-1.0, 1.0)).normalized()
        var tween := create_tween().set_parallel(true)
        tween.tween_property(spark, "position", spark.position + dir * randf_range(0.8, 1.8), 0.18)
        tween.tween_property(spark, "modulate:a", 0.0, 0.20)
        tween.tween_property(spark, "scale", Vector3(0.15, 0.15, 0.15), 0.20)
        tween.chain().tween_callback(spark.queue_free)

    # TSUYOMI: one budgeted impact ring sells contact better than dozens of extra particles.
    if MobileQualityManager.current_tier >= MobileQualityManager.QualityTier.HIGH:
        var ring := MeshInstance3D.new()
        var torus := TorusMesh.new()
        torus.inner_radius = 0.22
        torus.outer_radius = 0.29
        torus.rings = 16 if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.HIGH else 24
        torus.ring_segments = 6 if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.HIGH else 8
        ring.mesh = torus
        ring.position = Vector3(0.0, 1.18, 0.0)
        ring.rotation_degrees = Vector3(90.0, 0.0, 0.0)
        ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        var ring_mat := StandardMaterial3D.new()
        ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        ring_mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
        ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        ring_mat.albedo_color = Color(color.r, color.g, color.b, 0.78)
        ring_mat.emission_enabled = true
        ring_mat.emission = color
        ring_mat.emission_energy_multiplier = 4.2 if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.HIGH else 5.8
        ring.material_override = ring_mat
        add_child(ring)
        if MobileVFXBudget.try_register(ring, 2, priority, 0.0):
            var ring_tween := create_tween().set_parallel(true)
            ring_tween.tween_property(ring, "scale", Vector3.ONE * (2.4 if boss_id == "" else 3.4), 0.17).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
            ring_tween.tween_property(ring, "modulate:a", 0.0, 0.19)
            ring_tween.chain().tween_callback(ring.queue_free)
        else:
            ring.queue_free()

        # A tiny shadowless flash is reserved for near-field High/Ultra impacts.
        if MobileQualityManager.current_tier == MobileQualityManager.QualityTier.ULTRA:
            var flash_light := OmniLight3D.new()
            flash_light.light_color = color
            flash_light.light_energy = 1.1 if boss_id == "" else 1.65
            flash_light.omni_range = 2.8 if boss_id == "" else 3.8
            flash_light.shadow_enabled = false
            flash_light.distance_fade_enabled = true
            flash_light.distance_fade_begin = 8.0
            flash_light.distance_fade_length = 8.0
            flash_light.position = Vector3(0.0, 1.2, 0.0)
            add_child(flash_light)
            if MobileVFXBudget.try_register(flash_light, 3, 2 if boss_id == "" else 3, 0.0):
                var light_tween := create_tween()
                light_tween.tween_property(flash_light, "light_energy", 0.0, 0.095)
                light_tween.tween_callback(flash_light.queue_free)
            else:
                flash_light.queue_free()

func _play_sfx(stream: AudioStream, pitch: float = 1.0, volume_db: float = -8.0) -> void:
    var player := AudioStreamPlayer3D.new()
    player.stream = stream
    player.pitch_scale = pitch
    player.volume_db = volume_db
    player.max_distance = 34.0
    add_child(player)
    player.finished.connect(player.queue_free)
    player.play()

func _build_archetype_visuals() -> void:
    if boss_id == "izanami_shadow":
        _visual_sphere(Vector3(0,2.25,0), Vector3(0.72,0.86,0.58), Color(0.26,0.02,0.12))
        _visual_limb(Vector3(-0.72,1.55,0.08), Vector3(0.14,1.55,0.18), Vector3(0.05,0,-0.48), Color(0.08,0.015,0.05))
        _visual_limb(Vector3(0.72,1.55,0.08), Vector3(0.14,1.55,0.18), Vector3(0.05,0,0.48), Color(0.08,0.015,0.05))
        for i in range(5):
            var a := TAU * float(i) / 5.0
            _visual_sphere(Vector3(cos(a)*0.78,2.35+sin(a*2.0)*0.12,sin(a)*0.78), Vector3(0.16,0.16,0.16), Color(0.82,0.12,0.32))
    elif boss_id == "jorogumo":
        for side in [-1.0, 1.0]:
            for i in range(3):
                var z := -0.55 + i * 0.55
                _visual_limb(Vector3(side * 0.95, 1.0, z), Vector3(1.2, 0.12, 0.12), Vector3(0, 0, side * (0.42 + i * 0.10)), Color(0.18,0.03,0.12))
        _visual_sphere(Vector3(0,0.85,0.55), Vector3(0.72,0.55,0.8), Color(0.27,0.04,0.18))
    elif boss_id == "karasu_tengu" or enemy_name.contains("Tengu"):
        _visual_limb(Vector3(-0.82,1.45,0.18), Vector3(0.12,1.35,1.05), Vector3(0.2,0,-0.72), Color(0.035,0.05,0.085))
        _visual_limb(Vector3(0.82,1.45,0.18), Vector3(0.12,1.35,1.05), Vector3(0.2,0,0.72), Color(0.035,0.05,0.085))
        _visual_limb(Vector3(0,2.18,-0.32), Vector3(0.18,0.18,0.62), Vector3(-0.3,0,0), Color(0.62,0.2,0.12))
    elif boss_id == "gashadokuro":
        for i in range(5):
            var yy := 0.75 + i * 0.3
            _visual_limb(Vector3(0,yy,0), Vector3(1.35 - i*0.11,0.08,0.10), Vector3.ZERO, Color(0.78,0.75,0.62))
        _visual_limb(Vector3(0,1.35,0.12), Vector3(0.14,1.9,0.14), Vector3.ZERO, Color(0.78,0.75,0.62))
        _visual_sphere(Vector3(0,2.25,0), Vector3(0.68,0.78,0.62), Color(0.73,0.70,0.58))
    elif boss_id == "orochi_wraith":
        for i in range(3):
            var x := (i-1) * 0.55
            _visual_limb(Vector3(x,1.85,0.18), Vector3(0.22,1.15,0.22), Vector3(-0.32,0,(i-1)*0.20), Color(0.27,0.04,0.40))
            _visual_sphere(Vector3(x,2.48,0.48), Vector3(0.35,0.28,0.48), Color(0.42,0.08,0.57))
    elif boss_id == "nure_onna":
        for i in range(5):
            var t := float(i)
            _visual_sphere(Vector3(sin(t*0.75)*0.32,0.48-t*0.10,0.48+t*0.52), Vector3(0.58-t*0.06,0.34,0.68), Color(0.04,0.30+0.025*i,0.34))
        _visual_limb(Vector3(0,2.22,-0.12), Vector3(1.15,0.08,0.15), Vector3(0,0,0.12), Color(0.08,0.40,0.44))
    elif boss_id == "namahage_lord" or enemy_name.contains("Namahage"):
        _visual_limb(Vector3(0.62,1.0,-0.02), Vector3(0.16,1.9,0.18), Vector3(0,0,-0.55), Color(0.25,0.18,0.07))
        _visual_limb(Vector3(1.12,1.55,-0.02), Vector3(0.85,0.16,0.35), Vector3(0,0,-0.20), Color(0.38,0.42,0.14))
        _visual_sphere(Vector3(0,2.1,-0.34), Vector3(0.62,0.72,0.32), Color(0.55,0.12,0.08))
    elif enemy_name.contains("Fox"):
        _visual_limb(Vector3(0,1.0,0.62), Vector3(0.22,0.85,0.22), Vector3(-0.72,0,0), Color(0.62,0.12,0.36))

func _visual_limb(pos: Vector3, size: Vector3, rot: Vector3, color: Color) -> void:
    var m := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    m.mesh = box
    m.position = pos
    m.rotation = rot
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.82
    m.material_override = mat
    add_child(m)

func _visual_sphere(pos: Vector3, scale_v: Vector3, color: Color) -> void:
    var m := MeshInstance3D.new()
    var sm := SphereMesh.new()
    sm.radius = 0.5
    sm.height = 1.0
    m.mesh = sm
    m.position = pos
    m.scale = scale_v
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.78
    m.material_override = mat
    add_child(m)
