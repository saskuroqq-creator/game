extends Node

signal story_changed
signal boss_registered(boss_id: String)

const SAVE_PATH := "user://yokai_story.cfg"

var chapter: int = 1
var defeated_bosses: Dictionary = {}

const CHAPTERS := {
    1: {"title":"THE SHATTERED SEAL", "objective":"Defeat Akagane Oni at the Broken Torii", "boss":"akagane_oni", "recommended":1, "speaker":"SHRINE KEEPER HINA", "intro":"The Black Moon broke the old boundary. Akagane Oni carries the first seal shard. If it reaches Yomi, our village will disappear before dawn."},
    2: {"title":"FOX-FIRE WHISPERS", "objective":"Enter Kitsune Forest and defeat Jorōgumo", "boss":"jorogumo", "recommended":5, "speaker":"HINA", "intro":"The shard points west. Fox-fire is gathering around an abandoned loom shrine. Jorōgumo has woven the missing villagers into her curse."},
    3: {"title":"WINGS OVER THE RIDGE", "objective":"Climb Tengu Ridge and challenge Karasu-Tengu", "boss":"karasu_tengu", "recommended":9, "speaker":"RONIN GENSAI", "intro":"A Karasu-Tengu stole the wind seal and sealed the mountain paths. Break its storm before the gate above the ridge opens."},
    4: {"title":"THE DEAD WALK YOMI", "objective":"Break Gashadokuro's curse in Yomi Marsh", "boss":"gashadokuro", "recommended":14, "speaker":"HINA", "intro":"The marsh is speaking with the voices of the dead. Gashadokuro is feeding on forgotten names. Stay together; anyone isolated there becomes part of it."},
    5: {"title":"MOONFALL", "objective":"Reach Moonfall Shrine and defeat the Orochi Wraith", "boss":"orochi_wraith", "recommended":20, "speaker":"UNKNOWN VOICE", "intro":"Five seals. One gate. At Moonfall Shrine, the shadow of Orochi coils around Izanami's threshold. Break it before the Black Moon reaches its zenith."},
    6: {"title":"BENEATH THE REEDS", "objective":"Find the drowned shrine and defeat Nure-Onna", "boss":"nure_onna", "recommended":24, "speaker":"HINA", "intro":"The gate did not close. Something beneath the eastern reeds is drinking the water's reflection. The villagers call her Nure-Onna."},
    7: {"title":"BAMBOO BLOOD MOON", "objective":"Enter Bamboo Hollow and defeat the Namahage Lord", "boss":"namahage_lord", "recommended":28, "speaker":"GENSAI", "intro":"A war drum sounds from the southern bamboo. Namahage have begun taking masks from the living. Their lord carries a shard older than the Black Moon."},
    8: {"title":"THE VEILED GATE", "objective":"Cross the northern pass and defeat the Shadow of Izanami", "boss":"izanami_shadow", "recommended":32, "speaker":"HINA", "intro":"Seven shards answer one another. The northern veil has opened and a shadow wearing Izanami's name is crossing into Hoshikawa. This is the last hunt before dawn."},
    9: {"title":"DAWN AFTER THE BLACK MOON", "objective":"Hoshikawa is saved. Complete side hunts, perfect your build and return to the province whenever you wish.", "boss":"", "recommended":32, "speaker":"GENSAI", "intro":"The Black Moon breaks over the mountains. The gate is sealed, the dead are quiet, and Hoshikawa sees dawn again. Your name is now carried with the hunters who stood at the veil."}
}

func _ready() -> void:
    load_story()

func current_data() -> Dictionary:
    return CHAPTERS.get(chapter, CHAPTERS[9])

func objective_text() -> String:
    var d := current_data()
    return "CHAPTER %d • %s\n%s" % [chapter, d.get("title", ""), d.get("objective", "")]

func boss_defeated(boss_id: String) -> void:
    defeated_bosses[boss_id] = true
    while chapter < 9:
        var d := current_data()
        var required := String(d.get("boss", ""))
        if required == "" or not defeated_bosses.get(required, false):
            break
        chapter += 1
    save_story()
    story_changed.emit()

func chapter_speaker() -> String:
    return String(current_data().get("speaker", "HINA"))

func chapter_intro() -> String:
    return String(current_data().get("intro", ""))

func save_story() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("story", "chapter", chapter)
    cfg.set_value("story", "defeated", defeated_bosses)
    cfg.save(SAVE_PATH)

func load_story() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    chapter = int(cfg.get_value("story", "chapter", chapter))
    defeated_bosses = cfg.get_value("story", "defeated", defeated_bosses)

func reset_story() -> void:
    chapter = 1
    defeated_bosses = {}
    save_story()
    story_changed.emit()
