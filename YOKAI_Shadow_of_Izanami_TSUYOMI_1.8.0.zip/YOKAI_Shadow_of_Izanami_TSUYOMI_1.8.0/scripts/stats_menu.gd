extends Panel

@onready var info: Label = $Margin/VBox/Columns/Left/Info
@onready var skill_info: Label = $Margin/VBox/Columns/Left/SkillInfo
@onready var equipment_info: Label = $Margin/VBox/Columns/Right/EquipmentInfo
@onready var inventory_info: Label = $Margin/VBox/Columns/Right/InventoryInfo
@onready var quest_info: Label = $Margin/VBox/Columns/Right/QuestInfo

func _ready() -> void:
    visible = false
    Progression.profile_changed.connect(refresh)
    InventoryManager.inventory_changed.connect(refresh)
    QuestManager.quests_changed.connect(refresh)
    $Margin/VBox/Close.pressed.connect(func(): visible = false)
    $Margin/VBox/Columns/Left/Stats/STR.pressed.connect(func(): Progression.allocate_stat("strength"))
    $Margin/VBox/Columns/Left/Stats/VIT.pressed.connect(func(): Progression.allocate_stat("vitality"))
    $Margin/VBox/Columns/Left/Stats/AGI.pressed.connect(func(): Progression.allocate_stat("agility"))
    $Margin/VBox/Columns/Left/Stats/SPI.pressed.connect(func(): Progression.allocate_stat("spirit"))
    $Margin/VBox/Columns/Left/Stats/FOC.pressed.connect(func(): Progression.allocate_stat("focus"))
    $Margin/VBox/Columns/Left/Skills/MoonSlash.pressed.connect(func(): _skill_press("moon_slash", 1))
    $Margin/VBox/Columns/Left/Skills/KageStep.pressed.connect(func(): _skill_press("kage_step", 1))
    $Margin/VBox/Columns/Left/Skills/SpiritBurst.pressed.connect(func(): _skill_press("spirit_burst", 1))
    $Margin/VBox/Columns/Left/Skills/RaijinBreak.pressed.connect(func(): _skill_press("raijin_break", 2 if not Progression.has_skill("raijin_break") else 1))
    $Margin/VBox/Columns/Right/EquipBest.pressed.connect(func(): InventoryManager.equip_best())
    refresh()

func toggle() -> void:
    visible = not visible
    if visible:
        refresh()

func _skill_press(id: String, cost: int) -> void:
    if Progression.has_skill(id):
        Progression.upgrade_skill(id, cost)
    else:
        Progression.unlock_skill(id, cost)

func refresh() -> void:
    info.text = "RANK %s     LEVEL %d     GEAR SCORE %d\nXP %d / %d\n\nSTAT POINTS: %d\nSTR %d   VIT %d   AGI %d   SPI %d   FOC %d\n\nBASE ATK %d   BASE HP %d   BASE SPIRIT %d\nGEAR ATK +%d   GEAR HP +%d   CRIT +%.0f%%" % [
        Progression.rank_name(), Progression.level, InventoryManager.gear_score(), Progression.xp, Progression.xp_to_next(),
        Progression.stat_points, Progression.strength, Progression.vitality, Progression.agility,
        Progression.spirit, Progression.focus, Progression.attack_power(), Progression.max_health(),
        Progression.max_spirit(), int(InventoryManager.bonus("atk")), int(InventoryManager.bonus("hp")), InventoryManager.bonus("crit") * 100.0]
    skill_info.text = "SKILL POINTS: %d\nMoon Slash Lv.%d/5   Kage Step Lv.%d/5\nSpirit Burst Lv.%d/5   Raijin Break Lv.%d/5" % [
        Progression.skill_points, Progression.skill_level("moon_slash"), Progression.skill_level("kage_step"), Progression.skill_level("spirit_burst"), Progression.skill_level("raijin_break")]
    equipment_info.text = "EQUIPPED\n" + InventoryManager.equipment_summary()
    inventory_info.text = "INVENTORY\n" + InventoryManager.inventory_summary(9)
    quest_info.text = "ACTIVE SIDE HUNTS\n" + QuestManager.active_summary()

func _state(id: String) -> String:
    return "LV.%d" % Progression.skill_level(id) if Progression.has_skill(id) else "LOCKED"
