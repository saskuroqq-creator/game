extends Node

## Runtime animation-library merger for Quaternius UAL1/UAL2.
## This is intentionally conservative: it only remaps Skeleton3D bone tracks and
## skips incompatible scene-level tracks. UAL1/UAL2 and Universal Base Characters
## share Quaternius' modern humanoid bone naming, so the common case can work
## without modifying combat scripts.

@export var model_socket_path: NodePath = NodePath("../Visuals/ModelSocket")
@export var animation_bridge_path: NodePath = NodePath("../AnimationBridge")
@export var enabled := true
@export var import_root_motion := false

@export var source_scene_paths: Array[String] = [
    "res://assets/third_party/animations/UAL1/UAL1_Standard.glb",
    "res://assets/third_party/animations/UAL2/UAL2_Standard.glb",
    "res://assets/third_party/animations/UAL1/UAL1_Standard_RM.glb",
    "res://assets/third_party/animations/UAL2/UAL2_Standard_RM.glb"
]

var imported_count := 0

func _ready() -> void:
    if enabled:
        call_deferred("_bind_external_libraries")

func _bind_external_libraries() -> void:
    var socket := get_node_or_null(model_socket_path)
    if socket == null or socket.get_child_count() == 0:
        return
    var target_root: Node = socket.get_child(0)
    var target_skeleton := _find_skeleton(target_root)
    if target_skeleton == null:
        return
    var target_player := _find_animation_player(target_root)
    if target_player == null:
        target_player = AnimationPlayer.new()
        target_player.name = "YokaiExternalAnimationPlayer"
        target_root.add_child(target_player)
        target_player.root_node = NodePath("..")

    for source_path in source_scene_paths:
        if source_path.contains("_RM") and not import_root_motion:
            continue
        if not ResourceLoader.exists(source_path):
            continue
        _merge_source(source_path, target_root, target_skeleton, target_player)

    if imported_count > 0:
        var bridge := get_node_or_null(animation_bridge_path)
        if bridge != null and bridge.has_method("refresh"):
            bridge.call_deferred("refresh")

func _merge_source(source_path: String, target_root: Node, target_skeleton: Skeleton3D, target_player: AnimationPlayer) -> void:
    var packed := load(source_path)
    if not packed is PackedScene:
        return
    var source_root := (packed as PackedScene).instantiate()
    var source_player := _find_animation_player(source_root)
    var source_skeleton := _find_skeleton(source_root)
    if source_player == null or source_skeleton == null:
        source_root.free()
        return

    var source_bones := _bone_name_set(source_skeleton)
    var target_bones := _bone_name_set(target_skeleton)
    var shared := 0
    for bone_name in source_bones.keys():
        if target_bones.has(bone_name):
            shared += 1
    var compatibility := float(shared) / float(maxi(source_bones.size(), 1))
    if compatibility < 0.72:
        source_root.free()
        return

    var target_skeleton_path := target_root.get_path_to(target_skeleton)
    var library := _ensure_library(target_player, "yokai_ext")

    for raw_name in source_player.get_animation_list():
        var source_name := String(raw_name)
        if source_name == "RESET":
            continue
        var source_animation := source_player.get_animation(source_name)
        if source_animation == null:
            continue
        var remapped := _remap_animation(source_animation, source_root, source_skeleton, target_skeleton_path, target_bones)
        if remapped == null:
            continue
        var clean_name := _unique_animation_name(library, source_name)
        library.add_animation(clean_name, remapped)
        imported_count += 1

    source_root.free()

func _remap_animation(source: Animation, source_root: Node, source_skeleton: Skeleton3D, target_skeleton_path: NodePath, target_bones: Dictionary) -> Animation:
    var out := source.duplicate(true) as Animation
    var remove_tracks: Array[int] = []
    for i in range(out.get_track_count()):
        var track_path := out.track_get_path(i)
        var bone_name := _extract_bone_subname(track_path)
        if bone_name != "":
            if not target_bones.has(bone_name):
                remove_tracks.append(i)
                continue
            out.track_set_path(i, NodePath("%s:%s" % [String(target_skeleton_path), bone_name]))
            continue
        # Keep animation-method/value tracks only when they resolve inside the target model.
        # Scene/global/root-motion tracks are intentionally discarded by default.
        if out.track_get_type(i) in [Animation.TYPE_POSITION_3D, Animation.TYPE_ROTATION_3D, Animation.TYPE_SCALE_3D, Animation.TYPE_BLEND_SHAPE]:
            remove_tracks.append(i)
    remove_tracks.reverse()
    for index in remove_tracks:
        out.remove_track(index)
    if out.get_track_count() == 0:
        return null
    return out

func _extract_bone_subname(path: NodePath) -> String:
    if path.get_subname_count() <= 0:
        return ""
    # Skeleton bone tracks generally have one subname: Skeleton3D:BoneName.
    return String(path.get_subname(path.get_subname_count() - 1))

func _ensure_library(player: AnimationPlayer, name: StringName) -> AnimationLibrary:
    if player.has_animation_library(name):
        return player.get_animation_library(name)
    var library := AnimationLibrary.new()
    player.add_animation_library(name, library)
    return library

func _unique_animation_name(library: AnimationLibrary, source_name: String) -> StringName:
    var base := source_name.strip_edges()
    if not library.has_animation(base):
        return StringName(base)
    var suffix := 2
    while library.has_animation("%s_%d" % [base, suffix]):
        suffix += 1
    return StringName("%s_%d" % [base, suffix])

func _bone_name_set(skeleton: Skeleton3D) -> Dictionary:
    var result := {}
    for i in range(skeleton.get_bone_count()):
        result[String(skeleton.get_bone_name(i))] = true
    return result

func _find_skeleton(node: Node) -> Skeleton3D:
    if node is Skeleton3D:
        return node as Skeleton3D
    for child in node.get_children():
        var found := _find_skeleton(child)
        if found != null:
            return found
    return null

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node as AnimationPlayer
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found != null:
            return found
    return null
