extends Node3D

## Optional authored-art layer. It only activates assets that exist locally;
## otherwise YOKAI remains fully playable using the procedural world.
## Run tools/fetch_cc0_art.py before opening Godot to vendor the CC0 GLBs.

@export var enabled := true
@export var environment_scale := 0.92

const ART_PLACEMENTS := [
    {
        "path": "res://assets/third_party/environment/feudal_castle_market_shrine.glb",
        "name": "VeilCitadelAuthored",
        "position": Vector3(0.0, -0.03, -175.0),
        "rotation_y": PI,
        "scale": Vector3(0.92, 0.92, 0.92),
        "tint": Color(0.15, 0.21, 0.28, 0.09)
    },
    {
        "path": "res://assets/third_party/environment/feudal_stealth_rooftops.glb",
        "name": "MoonfallRooftopsAuthored",
        "position": Vector3(-14.0, 0.02, -101.0),
        "rotation_y": 0.55,
        "scale": Vector3(0.88, 0.88, 0.88),
        "tint": Color(0.09, 0.13, 0.23, 0.08)
    },
    {
        "path": "res://assets/third_party/characters/samurai_commander_memory.glb",
        "name": "AncestorMemory",
        "position": Vector3(5.6, 0.02, 7.0),
        "rotation_y": -2.35,
        "scale": Vector3(1.0, 1.0, 1.0),
        "tint": Color(0.12, 0.56, 0.92, 0.16)
    }
]

func _ready() -> void:
    if not enabled:
        return
    call_deferred("_load_authored_art")

func _load_authored_art() -> void:
    for placement in ART_PLACEMENTS:
        _instance_if_available(placement)

func _instance_if_available(placement: Dictionary) -> void:
    var path := String(placement["path"])
    if not ResourceLoader.exists(path):
        return
    var resource := load(path)
    if not resource is PackedScene:
        return
    var instance := (resource as PackedScene).instantiate()
    if not instance is Node3D:
        instance.queue_free()
        return
    var root := instance as Node3D
    root.name = String(placement["name"])
    root.position = placement["position"]
    root.rotation.y = float(placement["rotation_y"])
    root.scale = placement["scale"]
    add_child(root)
    _apply_yokai_finish(root, placement["tint"])
    _set_animation_idle(root)

func _apply_yokai_finish(node: Node, tint: Color) -> void:
    # A very light transparent material overlay pulls mismatched CC0 art into
    # YOKAI's moon-blue / oxidized-vermilion palette without destroying PBR maps.
    if node is MeshInstance3D:
        var mesh_instance := node as MeshInstance3D
        var overlay := StandardMaterial3D.new()
        overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        overlay.albedo_color = tint
        overlay.roughness = 0.72
        mesh_instance.material_overlay = overlay
        mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    for child in node.get_children():
        _apply_yokai_finish(child, tint)

func _set_animation_idle(node: Node) -> bool:
    if node is AnimationPlayer:
        var player := node as AnimationPlayer
        var names := player.get_animation_list()
        for preferred in ["idle", "Idle", "IDLE", "stand", "Stand"]:
            if preferred in names:
                player.play(preferred)
                return true
        if not names.is_empty():
            player.play(names[0])
            return true
    for child in node.get_children():
        if _set_animation_idle(child):
            return true
    return false
