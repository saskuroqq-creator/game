extends Node

## Blendshape bridge for authored faces.
## Input dictionaries may use MediaPipe/ARKit-like names such as eyeBlinkLeft,
## jawOpen, mouthSmileLeft, browInnerUp, etc. The bridge normalizes naming and
## applies values to any MeshInstance3D under ModelSocket that exposes a match.

@export var model_socket_path: NodePath = NodePath("../Visuals/ModelSocket")
@export_range(0.0, 30.0, 0.5) var smoothing_speed := 14.0
@export var enabled := true

var _targets: Dictionary = {}
var _desired: Dictionary = {}
var _current: Dictionary = {}

const ALIASES := {
    "eyeblinkleft": ["eyeblinkleft", "blinkleft", "eyeclosedleft", "eyelidcloseleft"],
    "eyeblinkright": ["eyeblinkright", "blinkright", "eyeclosedright", "eyelidcloseright"],
    "jawopen": ["jawopen", "mouthopen", "jawdrop"],
    "mouthsmileleft": ["mouthsmileleft", "smileleft"],
    "mouthsmileright": ["mouthsmileright", "smileright"],
    "mouthfrownleft": ["mouthfrownleft", "frownleft"],
    "mouthfrownright": ["mouthfrownright", "frownright"],
    "browinnerup": ["browinnerup", "innerbrowraise"],
    "browdownleft": ["browdownleft", "browlowerleft"],
    "browdownright": ["browdownright", "browlowerright"],
    "mouthpucker": ["mouthpucker", "pucker"],
    "mouthfunnel": ["mouthfunnel", "funnel"],
    "mouthclose": ["mouthclose", "lipclose"],
    "cheekpuff": ["cheekpuff", "puff"],
    "nosesneerleft": ["nosesneerleft", "sneerleft"],
    "nosesneerright": ["nosesneerright", "sneerright"]
}

func _ready() -> void:
    call_deferred("refresh")

func refresh() -> void:
    _targets.clear()
    var socket := get_node_or_null(model_socket_path)
    if socket == null:
        return
    _scan_node(socket)

func _scan_node(node: Node) -> void:
    if node is MeshInstance3D:
        var mesh_instance := node as MeshInstance3D
        if mesh_instance.mesh != null:
            for i in range(mesh_instance.mesh.get_blend_shape_count()):
                var raw_name := String(mesh_instance.mesh.get_blend_shape_name(i))
                var key := _canonical_key(raw_name)
                if not _targets.has(key):
                    _targets[key] = []
                (_targets[key] as Array).append([mesh_instance, i])
    for child in node.get_children():
        _scan_node(child)

func apply_face_frame(weights: Dictionary) -> void:
    if not enabled:
        return
    for raw_key in weights.keys():
        var canonical := _canonical_key(String(raw_key))
        var target_key := _resolve_alias(canonical)
        _desired[target_key] = clampf(float(weights[raw_key]), 0.0, 1.0)

func clear_expression() -> void:
    for key in _desired.keys():
        _desired[key] = 0.0

func set_expression(name: String, strength: float = 1.0) -> void:
    match name.to_lower():
        "focus":
            apply_face_frame({"browDownLeft": 0.45 * strength, "browDownRight": 0.45 * strength})
        "pain":
            apply_face_frame({"eyeBlinkLeft": 0.42 * strength, "eyeBlinkRight": 0.42 * strength, "mouthFrownLeft": 0.55 * strength, "mouthFrownRight": 0.55 * strength})
        "battle_cry":
            apply_face_frame({"jawOpen": 0.82 * strength, "browDownLeft": 0.50 * strength, "browDownRight": 0.50 * strength})
        "calm":
            clear_expression()

func _process(delta: float) -> void:
    if not enabled or _targets.is_empty():
        return
    var blend := 1.0 - exp(-maxf(smoothing_speed, 0.01) * delta)
    var keys := {}
    for k in _desired.keys(): keys[k] = true
    for k in _current.keys(): keys[k] = true
    for key in keys.keys():
        var desired := float(_desired.get(key, 0.0))
        var current := float(_current.get(key, 0.0))
        current = lerpf(current, desired, blend)
        _current[key] = current
        _apply_value(String(key), current)

func _apply_value(key: String, value: float) -> void:
    var resolved := _resolve_existing_target(key)
    if resolved == "":
        return
    for pair in (_targets[resolved] as Array):
        var mesh_instance: MeshInstance3D = pair[0]
        var index: int = pair[1]
        if is_instance_valid(mesh_instance):
            mesh_instance.set_blend_shape_value(index, value)

func _resolve_existing_target(key: String) -> String:
    if _targets.has(key):
        return key
    var aliases: Array = ALIASES.get(key, [])
    for alias in aliases:
        if _targets.has(alias):
            return alias
    for existing in _targets.keys():
        if String(existing).contains(key) or key.contains(String(existing)):
            return String(existing)
    return ""

func _resolve_alias(key: String) -> String:
    for canonical in ALIASES.keys():
        if key == canonical:
            return canonical
        if key in (ALIASES[canonical] as Array):
            return canonical
    return key

func _canonical_key(value: String) -> String:
    var out := value.to_lower()
    for token in ["mixamorig", "blendshape", "blend_shapes", "shape", "key", "left_", "right_"]:
        out = out.replace(token, token if token in ["left_", "right_"] else "")
    for char in [" ", "_", "-", ".", ":", "|", "/", "\\"]:
        out = out.replace(char, "")
    return out
