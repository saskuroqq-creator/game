extends Node

const PORT := 8910
const MAX_CLIENTS := 4

signal status_changed(message: String)

var peer: ENetMultiplayerPeer

func host_game() -> void:
    disconnect_network()
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_server(PORT, MAX_CLIENTS - 1)
    if err != OK:
        status_changed.emit("Host error: %s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    status_changed.emit("Room created on port %d" % PORT)
    call_deferred("_go_to_game")

func join_game(ip: String) -> void:
    disconnect_network()
    if ip.strip_edges().is_empty():
        status_changed.emit("Enter host IP address")
        return
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_client(ip.strip_edges(), PORT)
    if err != OK:
        status_changed.emit("Connection error: %s" % error_string(err))
        return
    multiplayer.multiplayer_peer = peer
    status_changed.emit("Connecting to %s:%d..." % [ip, PORT])
    multiplayer.connected_to_server.connect(_on_connected_to_server, CONNECT_ONE_SHOT)
    multiplayer.connection_failed.connect(_on_connection_failed, CONNECT_ONE_SHOT)

func start_solo() -> void:
    disconnect_network()
    get_tree().change_scene_to_file("res://scenes/Game.tscn")

func get_lan_ipv4() -> String:
    var addresses: PackedStringArray = IP.get_local_addresses()
    for address in addresses:
        if "." in address and not address.begins_with("127.") and not address.begins_with("169.254."):
            return address
    return "Check device Wi-Fi IP"

func disconnect_network() -> void:
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
    peer = null

func _on_connected_to_server() -> void:
    status_changed.emit("Connected")
    _go_to_game()

func _on_connection_failed() -> void:
    status_changed.emit("Could not connect")
    disconnect_network()

func _go_to_game() -> void:
    get_tree().change_scene_to_file("res://scenes/Game.tscn")
