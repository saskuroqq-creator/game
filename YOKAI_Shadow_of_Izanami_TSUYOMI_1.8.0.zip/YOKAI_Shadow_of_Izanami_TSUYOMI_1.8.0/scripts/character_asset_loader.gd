extends Node

## Production character socket loader.
## Keeps the procedural fallback alive when authored art is missing.
## Drop a rigged GLB/GLTF at one of the candidate paths and it will be instanced
## into Player/Visuals/ModelSocket without touching combat/gameplay code.

@export var model_socket_path: NodePath = NodePath("../Visuals/ModelSocket")
@export var animation_bridge_path: NodePath = NodePath("../AnimationBridge")
@export var facial_bridge_path: NodePath = NodePath("../FacialBlendshapeBridge")
@export var model_scale := Vector3.ONE
@export var model_rotation_degrees := Vector3.ZERO
@export var model_offset := Vector3.ZERO
@export var hide_procedural_body := true

@export var candidate_scene_paths: Array[String] = [
    "res://assets/third_party/characters/player_hunter.glb",
    "res://assets/third_party/characters/player_hunter.gltf",
    "res://assets/third_party/characters/quaternius/Superhero_Male_FullBody.gltf",
    "res://assets/third_party/characters/quaternius/Regular_Male_FullBody.gltf"
]

var loaded_model: Node3D = null

func _ready() -> void:
    call_deferred("_try_load_authored_character")

func _try_load_authored_character() -> void:
    var socket := get_node_or_null(model_socket_path) as Node3D
    if socket == null:
        return
    if socket.get_child_count() > 0:
        loaded_model = socket.get_child(0) as Node3D
        _finish_bind()
        return
    for path in candidate_scene_paths:
        if not ResourceLoader.exists(path):
            continue
        var resource := load(path)
        if resource is PackedScene:
            var instance := (resource as PackedScene).instantiate()
            if instance is Node3D:
                loaded_model = instance as Node3D
                loaded_model.name = "AuthoredHunter"
                socket.add_child(loaded_model)
                loaded_model.position = model_offset
                loaded_model.rotation_degrees = model_rotation_degrees
                loaded_model.scale = model_scale
                _finish_bind()
                return

func _finish_bind() -> void:
    if loaded_model == null:
        return
    if hide_procedural_body:
        _set_procedural_body_visible(false)
    MobileArtOptimizer.register_authored_root(loaded_model, "player")
    var animation_bridge := get_node_or_null(animation_bridge_path)
    if animation_bridge != null and animation_bridge.has_method("refresh"):
        animation_bridge.call_deferred("refresh")
    var facial_bridge := get_node_or_null(facial_bridge_path)
    if facial_bridge != null and facial_bridge.has_method("refresh"):
        facial_bridge.call_deferred("refresh")

func _set_procedural_body_visible(value: bool) -> void:
    var visuals := get_node_or_null("../Visuals")
    if visuals == null:
        return
    for child in visuals.get_children():
        if child.name == "ModelSocket" or child.name == "SwordPivot":
            continue
        if child is VisualInstance3D:
            (child as VisualInstance3D).visible = value
