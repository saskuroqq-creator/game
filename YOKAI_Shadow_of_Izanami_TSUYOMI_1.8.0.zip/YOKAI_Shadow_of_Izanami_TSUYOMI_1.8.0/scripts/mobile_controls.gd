extends CanvasLayer

var held_actions: Dictionary = {}

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _bind($Root/Left/Up, "move_forward")
    _bind($Root/Left/Down, "move_back")
    _bind($Root/Left/Left, "move_left")
    _bind($Root/Left/Right, "move_right")
    _bind($Root/Left/Sprint, "sprint")
    _bind($Root/Right/Attack, "attack")
    _bind($Root/Right/Dodge, "dodge")
    _bind($Root/Right/Jump, "jump")
    _bind($Root/Right/Skill1, "skill_1")
    _bind($Root/Right/Skill2, "skill_2")
    _bind($Root/Right/Skill3, "skill_3")
    _bind($Root/Right/Skill4, "skill_4")
    _bind($Root/Right/LockOn, "lock_on")
    _bind($Root/Right/Interact, "interact")
    _bind($Root/Right/Heal, "heal")
    _bind($Root/Right/Heavy, "heavy_attack")
    _bind($Root/Right/Guard, "guard")

func _exit_tree() -> void:
    for action in held_actions.keys():
        Input.action_release(action)

func _bind(button: BaseButton, action: StringName) -> void:
    button.button_down.connect(func():
        held_actions[action] = true
        Input.action_press(action)
    )
    button.button_up.connect(func():
        held_actions.erase(action)
        Input.action_release(action)
    )
