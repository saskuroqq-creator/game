extends Node

signal quality_changed(tier_name: String)

enum QualityTier { PERFORMANCE, BALANCED, HIGH, ULTRA }

const CONFIG_PATH := "user://graphics.cfg"
const SECTION := "graphics"
const TIER_NAMES := ["PERFORMANCE", "BALANCED", "HIGH", "ULTRA"]

var current_tier: int = QualityTier.HIGH
var target_fps := 60.0
var adaptive_guard_enabled := true
var _sample_time := 0.0
var _low_fps_time := 0.0
var _high_fps_time := 0.0
var _fps_accum := 0.0
var _fps_samples := 0
var _cooldown := 0.0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _load_config()
    _auto_select_if_first_run()
    call_deferred("apply_current_quality")

func _process(delta: float) -> void:
    if not adaptive_guard_enabled:
        return
    _cooldown = maxf(_cooldown - delta, 0.0)
    _sample_time += delta
    _fps_accum += Engine.get_frames_per_second()
    _fps_samples += 1
    if _sample_time < 2.0:
        return
    var avg_fps := _fps_accum / maxf(float(_fps_samples), 1.0)
    _sample_time = 0.0
    _fps_accum = 0.0
    _fps_samples = 0
    if avg_fps < target_fps - 10.0:
        _low_fps_time += 2.0
        _high_fps_time = 0.0
    elif avg_fps > target_fps - 2.0:
        _high_fps_time += 2.0
        _low_fps_time = maxf(_low_fps_time - 2.0, 0.0)
    else:
        _low_fps_time = maxf(_low_fps_time - 1.0, 0.0)
        _high_fps_time = maxf(_high_fps_time - 1.0, 0.0)
    # A tier change reallocates 3D buffers, so changes are deliberately infrequent.
    if _cooldown <= 0.0 and _low_fps_time >= 8.0 and current_tier > QualityTier.PERFORMANCE:
        set_quality(current_tier - 1, false)
        _cooldown = 14.0
        _low_fps_time = 0.0
    elif _cooldown <= 0.0 and _high_fps_time >= 28.0 and current_tier < QualityTier.ULTRA:
        set_quality(current_tier + 1, false)
        _cooldown = 24.0
        _high_fps_time = 0.0

func set_quality(tier: int, persist: bool = true) -> void:
    current_tier = clampi(tier, QualityTier.PERFORMANCE, QualityTier.ULTRA)
    apply_current_quality()
    if persist:
        _save_config()
    quality_changed.emit(quality_name())

func cycle_quality() -> void:
    set_quality((current_tier + 1) % 4)

func quality_name() -> String:
    return TIER_NAMES[current_tier]

func detail_multiplier() -> float:
    match current_tier:
        QualityTier.PERFORMANCE:
            return 0.58
        QualityTier.BALANCED:
            return 0.76
        QualityTier.HIGH:
            return 1.0
        _:
            return 1.18

func far_detail_distance(base_distance: float) -> float:
    match current_tier:
        QualityTier.PERFORMANCE:
            return base_distance * 0.62
        QualityTier.BALANCED:
            return base_distance * 0.78
        QualityTier.HIGH:
            return base_distance
        _:
            return base_distance * 1.15

func apply_current_quality() -> void:
    var viewport := get_tree().root
    var method := RenderingServer.get_current_rendering_method()
    var rd_available := method == "mobile" or method == "forward_plus"
    if rd_available:
        viewport.scaling_3d_mode = Viewport.SCALING_3D_MODE_FSR
    else:
        viewport.scaling_3d_mode = Viewport.SCALING_3D_MODE_BILINEAR

    match current_tier:
        QualityTier.PERFORMANCE:
            viewport.scaling_3d_scale = 0.59 if rd_available else 0.70
            viewport.fsr_sharpness = 0.36
            viewport.msaa_3d = Viewport.MSAA_DISABLED
            viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if rd_available else Viewport.SCREEN_SPACE_AA_DISABLED
            viewport.anisotropic_filtering_level = Viewport.ANISOTROPY_2X
        QualityTier.BALANCED:
            viewport.scaling_3d_scale = 0.67 if rd_available else 0.78
            viewport.fsr_sharpness = 0.26
            viewport.msaa_3d = Viewport.MSAA_2X if rd_available else Viewport.MSAA_DISABLED
            viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_FXAA if rd_available else Viewport.SCREEN_SPACE_AA_DISABLED
            viewport.anisotropic_filtering_level = Viewport.ANISOTROPY_4X
        QualityTier.HIGH:
            viewport.scaling_3d_scale = 0.77 if rd_available else 0.90
            viewport.fsr_sharpness = 0.18
            viewport.msaa_3d = Viewport.MSAA_2X if rd_available else Viewport.MSAA_DISABLED
            viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_SMAA if rd_available else Viewport.SCREEN_SPACE_AA_DISABLED
            viewport.anisotropic_filtering_level = Viewport.ANISOTROPY_8X
        QualityTier.ULTRA:
            viewport.scaling_3d_scale = 1.0
            viewport.fsr_sharpness = 0.16
            viewport.msaa_3d = Viewport.MSAA_4X if rd_available else Viewport.MSAA_DISABLED
            viewport.screen_space_aa = Viewport.SCREEN_SPACE_AA_SMAA if rd_available else Viewport.SCREEN_SPACE_AA_DISABLED
            viewport.anisotropic_filtering_level = Viewport.ANISOTROPY_16X

    if rd_available:
        # Mobile DOF uses a raster path. Keep it low quality outside Ultra to avoid bandwidth spikes.
        RenderingServer.camera_attributes_set_dof_blur_quality(RenderingServer.DOF_BLUR_QUALITY_MEDIUM if current_tier == QualityTier.ULTRA else RenderingServer.DOF_BLUR_QUALITY_LOW, false)

func apply_game_scene(game: Node) -> void:
    apply_current_quality()
    var world_environment := game.get_node_or_null("WorldEnvironment") as WorldEnvironment
    var moon_light := game.get_node_or_null("MoonLight") as DirectionalLight3D
    var warm_fill := game.get_node_or_null("WarmFill") as DirectionalLight3D
    if world_environment != null and world_environment.environment != null:
        var env := world_environment.environment
        # Glow forces extra screen work on the Mobile renderer, so reserve it for ULTRA.
        env.glow_enabled = current_tier == QualityTier.ULTRA and RenderingServer.get_current_rendering_method() != "gl_compatibility"
        env.glow_intensity = 0.72
        env.glow_bloom = 0.06
        env.fog_density = 0.0067 if current_tier >= QualityTier.HIGH else 0.0054
        env.fog_sun_scatter = 0.14 if current_tier >= QualityTier.HIGH else 0.08
        env.fog_aerial_perspective = 0.48 if current_tier == QualityTier.ULTRA else (0.38 if current_tier == QualityTier.HIGH else 0.24)
        env.fog_sky_affect = 0.76
        match current_tier:
            QualityTier.PERFORMANCE:
                env.adjustment_contrast = 1.05
                env.adjustment_saturation = 1.00
            QualityTier.BALANCED:
                env.adjustment_contrast = 1.08
                env.adjustment_saturation = 1.03
            QualityTier.HIGH:
                env.adjustment_contrast = 1.10
                env.adjustment_saturation = 1.06
            QualityTier.ULTRA:
                env.adjustment_contrast = 1.12
                env.adjustment_saturation = 1.08
    # Refresh all generated detail visibility when the player changes the tier.
    for detail_node in get_tree().get_nodes_in_group("mobile_detail"):
        var geometry := detail_node as GeometryInstance3D
        if geometry != null and geometry.has_meta("base_visibility"):
            var base_distance := float(geometry.get_meta("base_visibility"))
            geometry.visibility_range_end = far_detail_distance(base_distance)

    var lod_bias_value := 1.0
    match current_tier:
        QualityTier.PERFORMANCE:
            lod_bias_value = 0.58
        QualityTier.BALANCED:
            lod_bias_value = 0.78
        QualityTier.HIGH:
            lod_bias_value = 1.0
        QualityTier.ULTRA:
            lod_bias_value = 1.28
    for geometry_node in game.find_children("*", "GeometryInstance3D", true, false):
        var geo := geometry_node as GeometryInstance3D
        if geo != null:
            geo.lod_bias = lod_bias_value

    if warm_fill != null:
        warm_fill.light_energy = 0.20 if current_tier == QualityTier.PERFORMANCE else (0.27 if current_tier == QualityTier.BALANCED else 0.31)

    if moon_light != null:
        moon_light.shadow_enabled = current_tier >= QualityTier.BALANCED
        match current_tier:
            QualityTier.PERFORMANCE:
                moon_light.directional_shadow_max_distance = 42.0
            QualityTier.BALANCED:
                moon_light.directional_shadow_max_distance = 58.0
            QualityTier.HIGH:
                moon_light.directional_shadow_max_distance = 78.0
            QualityTier.ULTRA:
                moon_light.directional_shadow_max_distance = 96.0

    # Local lights get real distance LOD so mobile meshes stay below the renderer's
    # per-mesh light budget. Lantern lighting is reserved for Balanced+; spirit
    # lights remain readable even on Performance but at lower energy.
    for local_light_node in get_tree().get_nodes_in_group("mobile_local_light"):
        var local_light := local_light_node as OmniLight3D
        if local_light == null:
            continue
        var base_energy := float(local_light.get_meta("base_energy", local_light.light_energy))
        var role := String(local_light.get_meta("light_role", "spirit"))
        match current_tier:
            QualityTier.PERFORMANCE:
                local_light.visible = role == "spirit"
                local_light.light_energy = base_energy * 0.48
                local_light.distance_fade_begin = 16.0
                local_light.distance_fade_length = 6.0
            QualityTier.BALANCED:
                local_light.visible = true
                local_light.light_energy = base_energy * 0.68
                local_light.distance_fade_begin = 22.0
                local_light.distance_fade_length = 8.0
            QualityTier.HIGH:
                local_light.visible = true
                local_light.light_energy = base_energy * 0.88
                local_light.distance_fade_begin = 28.0
                local_light.distance_fade_length = 10.0
            QualityTier.ULTRA:
                local_light.visible = true
                local_light.light_energy = base_energy
                local_light.distance_fade_begin = 36.0
                local_light.distance_fade_length = 12.0

func _auto_select_if_first_run() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(CONFIG_PATH) == OK and cfg.has_section_key(SECTION, "tier"):
        return
    if OS.has_feature("mobile"):
        var size := DisplayServer.screen_get_size()
        var max_side := maxi(size.x, size.y)
        if max_side >= 2400:
            current_tier = QualityTier.HIGH
        elif max_side >= 1800:
            current_tier = QualityTier.BALANCED
        else:
            current_tier = QualityTier.PERFORMANCE
    else:
        current_tier = QualityTier.ULTRA

func _load_config() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(CONFIG_PATH) != OK:
        return
    current_tier = clampi(int(cfg.get_value(SECTION, "tier", current_tier)), 0, 3)
    adaptive_guard_enabled = bool(cfg.get_value(SECTION, "adaptive_guard", true))

func _save_config() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value(SECTION, "tier", current_tier)
    cfg.set_value(SECTION, "adaptive_guard", adaptive_guard_enabled)
    cfg.save(CONFIG_PATH)
