extends CharacterBody3D

func _enter_tree() -> void:
    add_to_group("players")
