extends Node

signal inventory_changed
signal item_obtained(item_id: String, amount: int)
signal item_equipped(item_id: String)

const SAVE_PATH := "user://yokai_inventory.cfg"

const ITEMS := {
    "iron_katana": {"name":"Iron Katana", "slot":"weapon", "rarity":"Common", "gear":12, "atk":4},
    "moonfang_katana": {"name":"Moonfang Katana", "slot":"weapon", "rarity":"Rare", "gear":48, "atk":14, "focus":2},
    "foxfire_blade": {"name":"Foxfire Blade", "slot":"weapon", "rarity":"Epic", "gear":85, "atk":25, "spirit":4, "crit":0.03},
    "tengu_edge": {"name":"Tengu Storm Edge", "slot":"weapon", "rarity":"Epic", "gear":115, "atk":34, "agility":5},
    "orochi_fang": {"name":"Orochi Fang", "slot":"weapon", "rarity":"Legendary", "gear":180, "atk":55, "strength":7, "spirit":6, "crit":0.05},
    "traveler_coat": {"name":"Traveler Coat", "slot":"armor", "rarity":"Common", "gear":10, "hp":20},
    "spider_silk_haori": {"name":"Spider-Silk Haori", "slot":"armor", "rarity":"Rare", "gear":62, "hp":60, "agility":2},
    "boneguard_armor": {"name":"Boneguard Armor", "slot":"armor", "rarity":"Epic", "gear":112, "hp":110, "vitality":5},
    "hina_charm": {"name":"Hina's Prayer Charm", "slot":"charm", "rarity":"Uncommon", "gear":20, "spirit_max":20},
    "foxfire_charm": {"name":"Foxfire Magatama", "slot":"charm", "rarity":"Rare", "gear":58, "spirit_max":45, "focus":3},
    "raijin_charm": {"name":"Raijin Thunder Seal", "slot":"charm", "rarity":"Legendary", "gear":155, "spirit_max":85, "crit":0.06},
    "veilbreaker_katana": {"name":"Veilbreaker Katana", "slot":"weapon", "rarity":"Legendary", "gear":240, "atk":78, "strength":9, "spirit":9, "crit":0.08},
    "healing_ofuda": {"name":"Healing Ofuda", "slot":"consumable", "rarity":"Common", "gear":0},
    "spirit_shard": {"name":"Spirit Shard", "slot":"material", "rarity":"Uncommon", "gear":0}
}

var inventory: Dictionary = {"iron_katana":1, "traveler_coat":1, "hina_charm":1, "healing_ofuda":3}
var equipped: Dictionary = {"weapon":"iron_katana", "armor":"traveler_coat", "charm":"hina_charm"}
var opened_world_loot: Dictionary = {}

func _ready() -> void:
    load_inventory()

func add_item(item_id: String, amount: int = 1) -> bool:
    if not ITEMS.has(item_id) or amount <= 0:
        return false
    inventory[item_id] = int(inventory.get(item_id, 0)) + amount
    save_inventory()
    item_obtained.emit(item_id, amount)
    inventory_changed.emit()
    return true

func consume_item(item_id: String, amount: int = 1) -> bool:
    if int(inventory.get(item_id, 0)) < amount or amount <= 0:
        return false
    inventory[item_id] = int(inventory[item_id]) - amount
    if int(inventory[item_id]) <= 0:
        inventory.erase(item_id)
    save_inventory()
    inventory_changed.emit()
    return true

func claim_world_loot(chest_id: String, item_id: String, amount: int = 1) -> bool:
    if opened_world_loot.get(chest_id, false):
        return false
    if not add_item(item_id, amount):
        return false
    opened_world_loot[chest_id] = true
    save_inventory()
    return true

func is_world_loot_opened(chest_id: String) -> bool:
    return bool(opened_world_loot.get(chest_id, false))

func equip(item_id: String) -> bool:
    if int(inventory.get(item_id, 0)) <= 0 or not ITEMS.has(item_id):
        return false
    var slot := String(ITEMS[item_id].get("slot", ""))
    if slot != "weapon" and slot != "armor" and slot != "charm":
        return false
    equipped[slot] = item_id
    save_inventory()
    item_equipped.emit(item_id)
    inventory_changed.emit()
    return true

func equip_best() -> void:
    for slot in ["weapon", "armor", "charm"]:
        var best_id := String(equipped.get(slot, ""))
        var best_gear := -1
        for id in inventory.keys():
            if int(inventory[id]) <= 0 or not ITEMS.has(id):
                continue
            var data: Dictionary = ITEMS[id]
            if String(data.get("slot", "")) == slot and int(data.get("gear", 0)) > best_gear:
                best_gear = int(data.get("gear", 0))
                best_id = String(id)
        if best_id != "":
            equipped[slot] = best_id
    save_inventory()
    inventory_changed.emit()

func item_name(item_id: String) -> String:
    if not ITEMS.has(item_id):
        return item_id
    return String(ITEMS[item_id].get("name", item_id))

func rarity(item_id: String) -> String:
    return String(ITEMS.get(item_id, {}).get("rarity", "Common"))

func rarity_color(item_id: String) -> Color:
    match rarity(item_id):
        "Uncommon": return Color(0.35, 0.9, 0.48)
        "Rare": return Color(0.3, 0.62, 1.0)
        "Epic": return Color(0.72, 0.36, 1.0)
        "Legendary": return Color(1.0, 0.64, 0.16)
        _: return Color(0.82, 0.84, 0.88)

func gear_score() -> int:
    var total := 0
    for slot in ["weapon", "armor", "charm"]:
        var id := String(equipped.get(slot, ""))
        total += int(ITEMS.get(id, {}).get("gear", 0))
    return total

func bonus(stat: String) -> float:
    var total := 0.0
    for slot in ["weapon", "armor", "charm"]:
        var id := String(equipped.get(slot, ""))
        total += float(ITEMS.get(id, {}).get(stat, 0.0))
    return total

func equipment_summary() -> String:
    var lines: Array[String] = []
    for slot in ["weapon", "armor", "charm"]:
        var id := String(equipped.get(slot, ""))
        var data: Dictionary = ITEMS.get(id, {})
        lines.append("%s  •  %s [%s]  GS %d" % [slot.to_upper(), item_name(id), rarity(id), int(data.get("gear", 0))])
    return "\n".join(lines)

func inventory_summary(max_lines: int = 8) -> String:
    var ids: Array = inventory.keys()
    ids.sort_custom(func(a, b): return int(ITEMS.get(a, {}).get("gear", 0)) > int(ITEMS.get(b, {}).get("gear", 0)))
    var lines: Array[String] = []
    for id in ids:
        if lines.size() >= max_lines:
            break
        lines.append("%s x%d  • %s" % [item_name(String(id)), int(inventory[id]), rarity(String(id))])
    return "\n".join(lines)

func save_inventory() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("inventory", "items", inventory)
    cfg.set_value("inventory", "equipped", equipped)
    cfg.set_value("world", "opened_loot", opened_world_loot)
    cfg.save(SAVE_PATH)

func load_inventory() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    inventory = cfg.get_value("inventory", "items", inventory)
    equipped = cfg.get_value("inventory", "equipped", equipped)
    opened_world_loot = cfg.get_value("world", "opened_loot", opened_world_loot)
