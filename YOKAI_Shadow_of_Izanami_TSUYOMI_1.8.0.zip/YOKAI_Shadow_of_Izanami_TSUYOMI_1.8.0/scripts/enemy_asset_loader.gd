extends Node

## Optional production-art loader for enemy/boss rigs.
## Drop a GLB/GLTF at one of the canonical paths below and the procedural
## proxy meshes are hidden automatically. AI, collision, HP and networking
## remain owned by enemy.gd, so art can be replaced without gameplay rewrites.

@export var model_socket_path: NodePath = NodePath("../ModelSocket")
@export var enabled := true
@export var model_scale := Vector3.ONE

var owner_enemy: CharacterBody3D
var model_root: Node3D
var animation_player: AnimationPlayer
var current_semantic := ""

const BOSS_PATHS := {
    "jorogumo": ["res://assets/third_party/enemies/boss_jorogumo.glb", "res://assets/third_party/enemies/boss_jorogumo.gltf"],
    "karasu_tengu": ["res://assets/third_party/enemies/boss_karasu_tengu.glb", "res://assets/third_party/enemies/boss_karasu_tengu.gltf"],
    "gashadokuro": ["res://assets/third_party/enemies/boss_gashadokuro.glb", "res://assets/third_party/enemies/boss_gashadokuro.gltf"],
    "orochi_wraith": ["res://assets/third_party/enemies/boss_orochi.glb", "res://assets/third_party/enemies/boss_orochi.gltf"],
    "nure_onna": ["res://assets/third_party/enemies/boss_nure_onna.glb", "res://assets/third_party/enemies/boss_nure_onna.gltf"],
    "namahage_lord": ["res://assets/third_party/enemies/boss_namahage.glb", "res://assets/third_party/enemies/boss_namahage.gltf"],
    "izanami_shadow": ["res://assets/third_party/enemies/boss_izanami_shadow.glb", "res://assets/third_party/enemies/boss_izanami_shadow.gltf"]
}

const ARCHETYPE_PATHS := {
    "tengu": ["res://assets/third_party/enemies/tengu.glb", "res://assets/third_party/enemies/tengu.gltf"],
    "oni": ["res://assets/third_party/enemies/oni.glb", "res://assets/third_party/enemies/oni.gltf"],
    "wraith": ["res://assets/third_party/enemies/wraith.glb", "res://assets/third_party/enemies/wraith.gltf"],
    "specter": ["res://assets/third_party/enemies/specter.glb", "res://assets/third_party/enemies/specter.gltf"],
    "namahage": ["res://assets/third_party/enemies/namahage.glb", "res://assets/third_party/enemies/namahage.gltf"],
    "fox": ["res://assets/third_party/enemies/kitsune_shade.glb", "res://assets/third_party/enemies/kitsune_shade.gltf"]
}

const SEMANTIC_ALIASES := {
    "idle": ["idle", "stand", "breath", "combatidle"],
    "run": ["run", "walk", "move", "locomotion"],
    "attack": ["attack", "melee", "strike", "bite", "slash", "claw"],
    "special": ["special", "cast", "roar", "skill", "spell", "attack2"],
    "hit": ["hit", "hurt", "damage", "stagger"],
    "death": ["death", "dead", "die", "fall"]
}

func _ready() -> void:
    if not enabled:
        set_process(false)
        return
    owner_enemy = get_parent() as CharacterBody3D
    call_deferred("_load_model")

func _load_model() -> void:
    if owner_enemy == null:
        return
    var socket := get_node_or_null(model_socket_path) as Node3D
    if socket == null:
        return
    for path in _candidate_paths():
        if not ResourceLoader.exists(path):
            continue
        var packed := load(path)
        if not packed is PackedScene:
            continue
        var instance := (packed as PackedScene).instantiate()
        if not instance is Node3D:
            instance.queue_free()
            continue
        model_root = instance as Node3D
        model_root.name = "AuthoredEnemyModel"
        model_root.scale = model_scale
        socket.add_child(model_root)
        _hide_procedural_proxy()
        _apply_yokai_finish(model_root)
        MobileArtOptimizer.register_authored_root(model_root, "boss" if String(owner_enemy.get("boss_id")) != "" else "enemy")
        animation_player = _find_animation_player(model_root)
        _play_semantic("idle", 1.0)
        return
    set_process(false)

func _candidate_paths() -> Array[String]:
    var result: Array[String] = []
    var boss_id := String(owner_enemy.get("boss_id"))
    if BOSS_PATHS.has(boss_id):
        result.append_array(BOSS_PATHS[boss_id])
    var name := String(owner_enemy.get("enemy_name")).to_lower()
    for key in ARCHETYPE_PATHS.keys():
        if name.contains(String(key)):
            result.append_array(ARCHETYPE_PATHS[key])
    if name.contains("war oni") and ARCHETYPE_PATHS.has("oni"):
        result.append_array(ARCHETYPE_PATHS["oni"])
    return result

func _process(_delta: float) -> void:
    if owner_enemy == null or model_root == null or animation_player == null:
        return
    var semantic := "idle"
    if bool(owner_enemy.get("dead")):
        semantic = "death"
    elif bool(owner_enemy.get("special_busy")):
        semantic = "special"
    elif bool(owner_enemy.get("attack_busy")):
        semantic = "attack"
    elif Vector2(owner_enemy.velocity.x, owner_enemy.velocity.z).length() > 0.35:
        semantic = "run"
    if semantic != current_semantic:
        _play_semantic(semantic, 1.0)

func _play_semantic(semantic: String, speed: float) -> bool:
    if animation_player == null:
        return false
    var aliases: Array = SEMANTIC_ALIASES.get(semantic, [semantic])
    var names := animation_player.get_animation_list()
    var chosen := ""
    for raw_alias in aliases:
        var alias := _normalize(String(raw_alias))
        for raw_name in names:
            var name := String(raw_name)
            var normalized := _normalize(name)
            if normalized == alias or normalized.contains(alias):
                chosen = name
                break
        if chosen != "":
            break
    if chosen == "":
        return false
    if animation_player.current_animation != chosen:
        animation_player.play(chosen, 0.12, speed)
    current_semantic = semantic
    return true

func _hide_procedural_proxy() -> void:
    for child in owner_enemy.get_children():
        if child is MeshInstance3D and String(child.name) != "Aura":
            (child as MeshInstance3D).visible = false

func _apply_yokai_finish(node: Node) -> void:
    if node is MeshInstance3D:
        var mesh := node as MeshInstance3D
        mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
        var overlay := StandardMaterial3D.new()
        overlay.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        overlay.albedo_color = Color(0.07, 0.09, 0.13, 0.045)
        overlay.roughness = 0.74
        mesh.material_overlay = overlay
    for child in node.get_children():
        _apply_yokai_finish(child)

func _find_animation_player(node: Node) -> AnimationPlayer:
    if node is AnimationPlayer:
        return node as AnimationPlayer
    for child in node.get_children():
        var found := _find_animation_player(child)
        if found != null:
            return found
    return null

func _normalize(value: String) -> String:
    var out := value.to_lower()
    for token in [" ", "_", "-", ".", ":", "/", "\\", "(", ")"]:
        out = out.replace(token, "")
    return out
