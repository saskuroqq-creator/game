extends Node

signal profile_changed
signal leveled_up(new_level: int)
signal skill_unlocked(skill_id: String)
signal skill_upgraded(skill_id: String, new_level: int)

const SAVE_PATH := "user://yokai_profile.cfg"
const MAX_SKILL_LEVEL := 5

var level: int = 1
var xp: int = 0
var stat_points: int = 0
var skill_points: int = 1
var strength: int = 5
var vitality: int = 5
var agility: int = 5
var spirit: int = 5
var focus: int = 5
var unlocked_skills: Dictionary = {"moon_slash": true}
var skill_levels: Dictionary = {"moon_slash": 1}

func _ready() -> void:
    load_profile()

func xp_to_next() -> int:
    return 100 + (level - 1) * 55 + int(pow(max(level - 1, 0), 1.35) * 10.0)

func add_xp(amount: int) -> void:
    xp += maxi(amount, 0)
    var leveled := false
    while xp >= xp_to_next():
        xp -= xp_to_next()
        level += 1
        stat_points += 3
        skill_points += 1
        leveled = true
        leveled_up.emit(level)
    if leveled:
        _auto_unlock_milestones()
    save_profile()
    profile_changed.emit()

func allocate_stat(stat_name: String) -> bool:
    if stat_points <= 0:
        return false
    match stat_name:
        "strength": strength += 1
        "vitality": vitality += 1
        "agility": agility += 1
        "spirit": spirit += 1
        "focus": focus += 1
        _: return false
    stat_points -= 1
    save_profile()
    profile_changed.emit()
    return true

func unlock_skill(skill_id: String, cost: int = 1) -> bool:
    if has_skill(skill_id):
        return upgrade_skill(skill_id, cost)
    if skill_points < cost:
        return false
    skill_points -= cost
    unlocked_skills[skill_id] = true
    skill_levels[skill_id] = 1
    save_profile()
    profile_changed.emit()
    skill_unlocked.emit(skill_id)
    return true

func upgrade_skill(skill_id: String, cost: int = 1) -> bool:
    if not has_skill(skill_id) or skill_points < cost:
        return false
    var current := skill_level(skill_id)
    if current >= MAX_SKILL_LEVEL:
        return false
    skill_points -= cost
    skill_levels[skill_id] = current + 1
    save_profile()
    profile_changed.emit()
    skill_upgraded.emit(skill_id, current + 1)
    return true

func has_skill(skill_id: String) -> bool:
    return bool(unlocked_skills.get(skill_id, false))

func skill_level(skill_id: String) -> int:
    return int(skill_levels.get(skill_id, 0)) if has_skill(skill_id) else 0

func max_health() -> int:
    return 105 + vitality * 13 + level * 4

func max_spirit() -> int:
    return 70 + spirit * 11 + level * 3

func attack_power() -> int:
    return 13 + strength * 4 + level * 2

func move_bonus() -> float:
    return agility * 0.035

func crit_chance() -> float:
    return clampf(0.04 + focus * 0.012, 0.04, 0.42)

func rank_name() -> String:
    if level >= 35: return "S"
    if level >= 25: return "A"
    if level >= 16: return "B"
    if level >= 9: return "C"
    if level >= 4: return "D"
    return "E"

func _auto_unlock_milestones() -> void:
    if level >= 3 and not has_skill("kage_step"):
        unlocked_skills["kage_step"] = true
        skill_levels["kage_step"] = 1
    if level >= 6 and not has_skill("spirit_burst"):
        unlocked_skills["spirit_burst"] = true
        skill_levels["spirit_burst"] = 1
    if level >= 12 and not has_skill("raijin_break"):
        unlocked_skills["raijin_break"] = true
        skill_levels["raijin_break"] = 1

func reset_profile() -> void:
    level = 1
    xp = 0
    stat_points = 0
    skill_points = 1
    strength = 5
    vitality = 5
    agility = 5
    spirit = 5
    focus = 5
    unlocked_skills = {"moon_slash": true}
    skill_levels = {"moon_slash": 1}
    save_profile()
    profile_changed.emit()

func save_profile() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("progress", "level", level)
    cfg.set_value("progress", "xp", xp)
    cfg.set_value("progress", "stat_points", stat_points)
    cfg.set_value("progress", "skill_points", skill_points)
    cfg.set_value("stats", "strength", strength)
    cfg.set_value("stats", "vitality", vitality)
    cfg.set_value("stats", "agility", agility)
    cfg.set_value("stats", "spirit", spirit)
    cfg.set_value("stats", "focus", focus)
    cfg.set_value("skills", "unlocked", unlocked_skills)
    cfg.set_value("skills", "levels", skill_levels)
    cfg.save(SAVE_PATH)

func load_profile() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) != OK:
        return
    level = int(cfg.get_value("progress", "level", level))
    xp = int(cfg.get_value("progress", "xp", xp))
    stat_points = int(cfg.get_value("progress", "stat_points", stat_points))
    skill_points = int(cfg.get_value("progress", "skill_points", skill_points))
    strength = int(cfg.get_value("stats", "strength", strength))
    vitality = int(cfg.get_value("stats", "vitality", vitality))
    agility = int(cfg.get_value("stats", "agility", agility))
    spirit = int(cfg.get_value("stats", "spirit", spirit))
    focus = int(cfg.get_value("stats", "focus", focus))
    unlocked_skills = cfg.get_value("skills", "unlocked", unlocked_skills)
    skill_levels = cfg.get_value("skills", "levels", skill_levels)
    for id in unlocked_skills.keys():
        if unlocked_skills[id] and not skill_levels.has(id):
            skill_levels[id] = 1
