extends Node

# KAGE 1.7 — shared transient VFX budget for mobile.
# Prevents combat bursts from allocating dozens of short-lived nodes on the same frame.

var live_cost := 0
var spawned_this_frame := 0
var _frame_id := -1

func _process(_delta: float) -> void:
    var frame := Engine.get_process_frames()
    if frame != _frame_id:
        _frame_id = frame
        spawned_this_frame = 0

func density_multiplier() -> float:
    match MobileQualityManager.current_tier:
        MobileQualityManager.QualityTier.PERFORMANCE:
            return 0.52
        MobileQualityManager.QualityTier.BALANCED:
            return 0.72
        MobileQualityManager.QualityTier.HIGH:
            return 1.0
        _:
            return 1.35

func _live_cap() -> int:
    match MobileQualityManager.current_tier:
        MobileQualityManager.QualityTier.PERFORMANCE:
            return 22
        MobileQualityManager.QualityTier.BALANCED:
            return 34
        MobileQualityManager.QualityTier.HIGH:
            return 50
        _:
            return 72

func _frame_cap() -> int:
    match MobileQualityManager.current_tier:
        MobileQualityManager.QualityTier.PERFORMANCE:
            return 5
        MobileQualityManager.QualityTier.BALANCED:
            return 8
        MobileQualityManager.QualityTier.HIGH:
            return 12
        _:
            return 18

func far_fx_distance() -> float:
    match MobileQualityManager.current_tier:
        MobileQualityManager.QualityTier.PERFORMANCE:
            return 18.0
        MobileQualityManager.QualityTier.BALANCED:
            return 26.0
        MobileQualityManager.QualityTier.HIGH:
            return 38.0
        _:
            return 54.0

func try_register(node: Node, cost: int = 1, priority: int = 0, distance_to_viewer: float = 0.0) -> bool:
    if node == null:
        return false
    if priority <= 0 and distance_to_viewer > far_fx_distance():
        return false
    if priority < 2 and spawned_this_frame >= _frame_cap():
        return false
    if priority < 3 and live_cost + cost > _live_cap():
        return false
    live_cost += cost
    spawned_this_frame += 1
    node.tree_exited.connect(func(): live_cost = maxi(live_cost - cost, 0))
    return true
