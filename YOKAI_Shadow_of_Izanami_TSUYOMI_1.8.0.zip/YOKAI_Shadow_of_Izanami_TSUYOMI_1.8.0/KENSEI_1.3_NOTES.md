# KENSEI 1.3 — Visual Combat / Rig Integration

Built directly on KENSEI 1.2.

## Added
- Local 3D lock-on reticle that follows the selected yōkai.
- Floating damage numbers, with distinct co-op resonance feedback.
- Stronger samurai placeholder silhouette: shoulder plates, waist armor, scabbard and hair knot.
- `ModelSocket` in the player scene for drop-in rigged GLB/TSCN characters.
- `AnimationBridge` that auto-detects an AnimationPlayer and maps combat states to common authored animation names.
- Authored animation hooks for light attacks, heavy attack, dodge, guard, parry, skills, downed/revive and locomotion.
- Fallback procedural animation remains intact when no rigged model is installed.

## Important
The project is now structurally ready for real skeletal assets, but no external copyrighted 3D model is bundled. The current geometry remains an original placeholder/fallback.
