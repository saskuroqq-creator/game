# YŌKAI: Shadows of Izanami — Ascendant Build v0.3.0

## Design pillars preserved
1. 1–4 player co-op remains the core identity.
2. Dark Japanese folklore / anime-inspired tone remains intact.
3. Seamless Hoshikawa Province remains the world structure.
4. Host-authoritative combat remains the multiplayer foundation.
5. Progression, ranks, loot, Gear Score, side hunts, bosses and revives remain compatible.

## New gameplay feel
- Hunter Resonance: allies within 8m grant +4% damage each, capped at +12%.
- Resonance Strikes: two different hunters hitting the same target in a short window cause bonus damage and stagger.
- Stagger Break: coordinated pressure creates a burst-damage opening.
- Perfect Dodge: a short invulnerability timing window restores Spirit and triggers a visual counter flash.
- Camera pass: shoulder offset, dynamic FOV and combat/dodge kick.

## New presentation pass
- Filmic tonemapping, stronger moon/key lighting and atmospheric fog.
- Drowned Shrine water planes and enhanced Yomi wetland mood.
- Bamboo Hollow receives actual bamboo dressing.
- Spirit lights placed throughout all major regions.
- Boss threat vignette and stronger boss-phase presentation.

## Production target
To reach literal commercial AAA visual quality, the next production pass should replace procedural prototype geometry with authored character/environment assets, skeletal animation, authored VFX, audio, PBR materials, cinematic boss animation and optimized LODs. The v0.3.0 codebase is structured to preserve co-op while those assets are swapped in.

## Preview notice
Images in docs/previews are design-target previews created from the v0.2.0 presentation baseline to show the intended v0.3.0 direction. They are not runtime captures from a Godot executable.
