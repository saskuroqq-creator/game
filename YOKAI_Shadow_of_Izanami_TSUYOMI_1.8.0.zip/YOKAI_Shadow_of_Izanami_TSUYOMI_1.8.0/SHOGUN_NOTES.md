# YŌKAI: Shadows of Izanami — Shogun Visual Build v0.4.0

## North star
Build an original co-op action RPG with premium combat readability, Japanese folklore atmosphere and a strong team identity without copying protected characters, worlds, UI, music, names, animation sets or art assets from other games.

## Combat changes
- Guard: hold V / mobile GUARD. Blocking reduces incoming damage but consumes Spirit.
- Perfect Parry: first 180 ms of guard. Restores Spirit and deals severe stagger to the attacker.
- Spirit Heavy: G / mobile HEAVY. Costs Spirit, has a deliberate wind-up and specializes in stagger damage.
- Enemy attacks now use readable wind-ups instead of unavoidable contact hits.
- Boss specials rotate between radial, cone and ring danger patterns.
- Perfect Dodge and Perfect Parry both contribute to co-op stagger pressure.

## Co-op changes
- Revive is now a 1.85 second channel instead of an instant interaction.
- The rescuer is slowed during the channel, creating a real protection decision for the rest of the party.
- Party HUD tracks up to four hunters and visibly surfaces DOWNED states.
- Existing Hunter Resonance and alternating-attacker Resonance Strikes remain intact.

## Presentation changes
- Dynamic atmosphere adapts to Drowned Shrine, Bamboo Hollow, Moonfall Shrine and Yomi Marsh.
- Boss proximity pushes warmer danger lighting and denser fog.
- Lock-on now has a projected target reticle in addition to target text.
- Combat feedback exposes parry, guard break, revive progress and heavy attacks without hiding the scene.

## Copyright / asset policy
This prototype uses only project-authored procedural geometry, code and UI. Future production assets should be original, commissioned with commercial rights, or sourced under licenses explicitly allowing commercial derivative use. Do not import ripped models, textures, audio, animations, logos, dialogue, maps or distinctive protected character designs from existing games/anime.

## Production reality
The codebase can support a much higher visual ceiling, but literal AAA presentation requires authored character models, skeletal animation, PBR environment assets, VFX, sound design, cinematics and device-specific optimization. Those are the next production layers; the gameplay code should remain compatible while placeholders are replaced.
