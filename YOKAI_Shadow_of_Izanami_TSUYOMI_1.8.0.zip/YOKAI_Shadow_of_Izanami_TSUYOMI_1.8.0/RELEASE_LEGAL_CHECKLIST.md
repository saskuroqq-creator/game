# YOKAI — release IP / provenance checklist

This checklist is operational, not legal advice.

Before a public Google Play release:

- [ ] Replace `[RIGHTSHOLDER LEGAL NAME]` in `LICENSE_PROJECT_PROPRIETARY.txt` with the actual person/company that will own/publish the project.
- [ ] Run `python tools/audit_release_licenses.py` and require PASS.
- [ ] Keep `ASSET_PROVENANCE_LEDGER.csv`, `assets/third_party/ASSET_MANIFEST.json`, and any download receipts in the release archive.
- [ ] For every newly bundled external model, texture, animation, font, sound, icon or plugin: record the exact source URL, license, acquisition date, and file hash before shipping.
- [ ] Default release whitelist is CC0 for third-party binary art. Anything else needs an explicit review before inclusion.
- [ ] Do not describe CC0/public-domain source assets as exclusive YOKAI creations.
- [ ] Use original store screenshots, key art, logo, music and marketing copy, or maintain equivalent license evidence for each item.
- [ ] Perform a jurisdiction-appropriate trademark/title clearance for `YOKAI: Shadows of Izanami` and the final logo before commercial launch. A web search is not a substitute for a trademark clearance.
- [ ] Keep the signed Android keystore controlled by the publisher; do not commit private signing keys into the project archive.
- [ ] Archive the final source snapshot and its SHA-256 manifest at each store release.
