# YOKAI SHINRA 1.6 — Mobile production guide

## Rendering strategy

- Default renderer: **Godot Mobile (Vulkan)**.
- Automatic fallback: **Compatibility / OpenGL 3** when Vulkan RenderingDevice is unavailable.
- Runtime profiles: PERFORMANCE / BALANCED / HIGH / ULTRA.
- FSR internal resolution scaling: 0.59 / 0.67 / 0.77 / 0.86 on Vulkan-capable paths.
- Only ULTRA enables glow. Decorative geometry normally does not cast dynamic shadows.
- One primary shadowed directional light is the target; decorative omni lights remain unshadowed.
- Vegetation/rocks/grass are batched with MultiMesh and distance ranges.
- Occlusion culling stays enabled; large future imported buildings should receive simple OccluderInstance3D proxies.

## Internal art budgets (project targets, not engine limits)

| Asset | Flagship target | Balanced target | Notes |
|---|---:|---:|---|
| Hero visible triangles | 35–55k | 25–40k | Preserve face/hands/silhouette; LOD body under armor |
| Standard enemy | 18–30k | 12–22k | 3 LOD levels where possible |
| Boss | 45–70k | 30–50k | Reserve budget for only one hero boss nearby |
| Hero textures | 2K sets | 1K–2K sets | Prefer atlases; face may keep separate high-detail map |
| Enemy textures | 1K–2K | 1K | Reuse material families |
| World props | 512–2K | 512–1K | Trim sheets/atlases preferred |
| Particles | short/local | shorter/local | Avoid full-screen translucent layers |

## Visual quality priorities

Spend GPU budget in this order: character silhouette/animation → material readability → contact/shadow grounding → weapon VFX → environment density. Do not spend mobile budget on invisible 4K maps, many shadowed lights, or dense geometry behind the player.

## Import rules

- Power-of-two textures. Source art can be 4K for authoring, but runtime imports should be capped per asset role.
- Prefer VRAM-compressed textures; use mobile high-quality compression only for hero/critical assets where the visual gain is visible.
- Generate mesh LODs or author explicit LOD/HLOD for large imported scenes.
- Use a few MultiMesh batches by geographic cell rather than one world-sized batch once foliage density grows.
