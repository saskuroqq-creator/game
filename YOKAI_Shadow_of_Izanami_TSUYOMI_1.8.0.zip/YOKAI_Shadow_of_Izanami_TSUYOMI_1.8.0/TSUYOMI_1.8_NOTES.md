# TSUYOMI 1.8 — Visual Production Milestone

TSUYOMI pushes the mobile branch toward a premium third-person action-RPG presentation without spending the performance budget on desktop-only effects.

## Visual direction
- Procedural night sky now supplies image-based ambient/specular response for authored PBR materials.
- Added a distant low-cost mountain silhouette layer and authored moon disc to deepen the skyline.
- Added a mobile wet-surface shader for roads, ground and rocks with controlled clearcoat/rim response.
- High/Ultra authored materials receive stronger filtering and hero/boss priority treatment.

## Camera
- Added practical camera attributes and restrained combat DOF on Ultra only.
- Lock-on framing now reacts to target side/distance and boss spacing while preserving shoulder readability.
- Sprint, combat and target states feed a smoother dynamic FOV/arm-length presentation.

## Combat VFX
- Sword ribbons now use additive blending for cleaner energy response.
- High/Ultra impacts add a budgeted expanding emissive ring.
- Ultra can add a very short shadowless impact light, still governed by the shared VFX budget.

## Mobile policy
- Performance/Balanced retain the core silhouette and timing while removing expensive cosmetic layers.
- High/Ultra spend extra budget on PBR filtering, impact readability, sky response and camera polish rather than uncontrolled light counts.
- Compatibility fallback remains available for devices that cannot use the Mobile/Vulkan path.

## Licensing
No new third-party runtime binary assets are bundled in this milestone. Project-original code/material logic is tracked separately from optional external CC0 art. Run `python tools/audit_release_licenses.py` before every distributable build.

## Validation limit
Static project QA and provenance audit are repeatable and included. This environment does not currently provide an executable Godot editor/Android SDK, so a real engine launch and Android export remain required before a store candidate is declared runtime-validated.
