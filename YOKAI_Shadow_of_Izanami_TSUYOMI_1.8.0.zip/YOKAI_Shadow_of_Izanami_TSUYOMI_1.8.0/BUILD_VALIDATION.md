# Build validation — Ronin 1.1

## Static QA passed
- all `res://` references resolve;
- no duplicate GDScript function declarations detected;
- bracket/delimiter structure scan passes;
- every referenced input action exists in `project.godot`;
- mobile Sprint control node and binding exist;
- Android export metadata points to Ronin 1.1;
- inherited campaign, co-op, inventory, quest and audio resources remain present.

See `QA_REPORT_RONIN_1.1.txt`.

## Runtime limitation
The execution container does not include the Godot editor/runtime, export templates or Android SDK. A real engine parse/playtest and APK export therefore cannot be truthfully claimed from this environment. Target engine is Godot 4.7.x stable.
