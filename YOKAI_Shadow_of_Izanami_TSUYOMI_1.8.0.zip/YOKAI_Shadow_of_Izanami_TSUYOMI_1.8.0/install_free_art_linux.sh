#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tools/fetch_cc0_art.py
printf '\nRestart Godot once so imported GLBs are indexed.\n'
