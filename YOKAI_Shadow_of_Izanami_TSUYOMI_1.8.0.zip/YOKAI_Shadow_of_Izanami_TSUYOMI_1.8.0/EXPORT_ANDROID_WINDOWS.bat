@echo off
setlocal
set "GODOT="
for %%G in (godot.exe godot4.exe) do (
  where %%G >nul 2>nul && set "GODOT=%%G"
)
if exist "%~dp0Godot_v4.7.2-stable_win64.exe" set "GODOT=%~dp0Godot_v4.7.2-stable_win64.exe"
if "%GODOT%"=="" (
  echo Godot 4.7.x not found.
  pause
  exit /b 1
)
if not exist "%~dp0build" mkdir "%~dp0build"
"%GODOT%" --headless --path "%~dp0" --export-release Android "build/YOKAI_Shadow_of_Izanami_COMPLETE_1.0_RC1.apk"
if errorlevel 1 (
  echo Export failed. Confirm Android SDK/JDK and Godot export templates are configured.
  pause
  exit /b 1
)
echo APK created in build\YOKAI_Shadow_of_Izanami_COMPLETE_1.0_RC1.apk
pause
