# YOKAI 1.3 — Rigged Character / Animation Drop-in

KENSEI 1.3 keeps the current procedural fighter as a fallback, but the player scene now contains:

`Player/Visuals/ModelSocket`

Instance a rigged `.glb` or `.tscn` character under `ModelSocket`. `AnimationBridge` recursively detects the first `AnimationPlayer`.

## Recommended animation names
The bridge checks aliases, so exact naming can vary. Preferred names:

- `idle`
- `run`
- `sprint`
- `attack_1`
- `attack_2`
- `attack_3`
- `heavy_attack`
- `dodge`
- `guard`
- `parry`
- `skill`
- `downed`
- `revive`

Combat timing and damage remain controlled by the gameplay scripts, not by the imported animation file. This lets visual assets be replaced without changing multiplayer authority or combat rules.

## Production path
For final-quality characters, replace the placeholder geometry with a licensed/original rigged model, PBR textures, authored animation clips and retargeted weapon sockets. This package provides the integration point; it does not pretend placeholder primitives are final AAA character art.
