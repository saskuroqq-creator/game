# Ronin 1.1 — Combat Feel Upgrade

This branch continues the third-person co-op Action RPG build from Complete RC1.

## Added
- Light-attack input buffering so fast combo inputs are not silently dropped.
- Sprint with Spirit cost, speed scaling and mobile sprint control.
- Lock-on target cycling (`C`) and tighter lock-on camera framing.
- Dynamic camera arm length, shoulder offset and FOV for sprint / lock-on / combat impact.
- Heavy attack now carries forward momentum for a more committed strike.
- Guard and perfect parry only protect the frontal combat arc instead of 360 degrees.
- Crowd-combat AI spacing: nearby yōkai separate and orbit instead of collapsing into one stack.
- Normal enemies use an attack-slot rule so no more than two nearby enemies begin melee windups together. Bosses ignore this restriction.
- Updated desktop/mobile control hints.

## Production note
The project still uses authored procedural placeholder geometry. The combat/camera/network foundation is being improved first so rigged character models, skeletal animation, PBR assets and authored VFX can replace placeholders without rewriting gameplay.
