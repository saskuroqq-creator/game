# Enemy art sockets

Drop final rigged GLB/GLTF files here using canonical names listed in `THIRD_PARTY_ART_PIPELINE.md`. The game automatically hides procedural proxies when a matching file exists.
