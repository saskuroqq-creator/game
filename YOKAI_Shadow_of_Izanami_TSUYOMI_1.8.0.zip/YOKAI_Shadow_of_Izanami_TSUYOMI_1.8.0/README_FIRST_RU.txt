YOKAI: Shadows of Izanami — RONIN 1.1

Это продолжение именно 3D third-person co-op Action RPG ветки.
Версия: 1.1.0-alpha-ronin

ГЛАВНЫЕ ИЗМЕНЕНИЯ
- Буфер ввода лёгких атак: комбо меньше теряет быстрые нажатия.
- Sprint: Shift на ПК + отдельная кнопка на мобильном управлении.
- Улучшенная камера от третьего лица: FOV, дистанция и плечо меняются при беге, lock-on и бою.
- C переключает цель при lock-on.
- Heavy attack получил импульс вперёд.
- Guard / Perfect Parry работают по фронтальной дуге, а не на 360 градусов.
- Ёкаи расталкиваются и обходят игрока, вместо наложения друг на друга.
- Обычные враги используют attack-slot: не более двух противников начинают ближнюю атаку одновременно рядом с одной целью.
- Сохранены кооп 1–4, revive, боссы, RPG-прогрессия, инвентарь, квесты и кампания RC1.

УПРАВЛЕНИЕ ПК
WASD — движение
Shift — sprint
Space — dodge
F / ЛКМ — лёгкая атака
G — Spirit Heavy
V — Guard / Perfect Parry
Q — lock-on / снять lock-on
C — следующая цель
1–4 — навыки
R — взаимодействие / revive
5 — Healing Ofuda

ЗАПУСК
Открыть project.godot в Godot 4.7.x и запустить Main.tscn.

ВАЖНО
В этой среде нет установленного Godot runtime/Android SDK, поэтому настоящий playtest и APK export здесь не выполнялись. Статическая QA-проверка проекта пройдена; результат лежит в QA_REPORT_RONIN_1.1.txt.

Визуальные модели пока остаются процедурными placeholder-моделями. Следующий крупный production-проход — rigged humanoid/yokai assets + skeletal AnimationTree + PBR environment/VFX.
