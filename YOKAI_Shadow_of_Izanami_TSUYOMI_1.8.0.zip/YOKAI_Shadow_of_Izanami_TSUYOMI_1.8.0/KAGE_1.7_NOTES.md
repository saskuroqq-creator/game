# KAGE 1.7.0 — Mobile Fidelity & Combat Budget Pass

KAGE keeps SHINRA's production/legal foundation and spends the recovered mobile budget on visible quality instead of uncontrolled transient work.

## Rendering / fidelity
- Added per-tier FSR sharpness and viewport anisotropic filtering (2x/4x/8x/16x).
- Added project-wide runtime mesh LOD bias per quality tier, including future imported GLB/GLTF meshes.
- Added authored-art optimizer for player, bosses and normal enemies.
- High/Ultra imported BaseMaterial3D textures use anisotropic mip filtering; lower tiers keep trilinear mip filtering.
- Player shadows stay prioritized. Normal enemy authored shadows begin at High; boss authored shadows begin at Balanced.
- Added distance-faded local lighting policy for spirit lights and village lanterns.
- Added real lantern OmniLights without shadow cost; Performance hides lantern lights while preserving spirit readability.
- Added cached procedural materials to reduce duplicate material resources.
- Added lightweight mobile vertex-wind shader for grass, bamboo and tree crowns.
- Rebuilt bamboo dressing as MultiMesh batches instead of dozens of individual MeshInstance3D nodes.

## Combat / CPU / network
- Added global MobileVFXBudget singleton with live and per-frame transient limits per quality tier.
- Weapon arcs and enemy sparks now respect the shared VFX budget; boss/high-priority telegraphs remain protected.
- Enemy target selection, separation scans and attack-slot checks are cached/throttled.
- Enemy state replication rate now scales by distance, keeping bosses and close combat responsive while reducing distant network work.

## Mobile production goals
- Preserve the hero and boss silhouette/detail first.
- Prefer stable frame pacing over expensive screen-space effects.
- Spend Ultra headroom on native resolution, material clarity, hero/boss LOD and controlled VFX.
- Keep the default external binary release whitelist CC0-only unless a specific asset is reviewed and recorded.

## Validation limitation
Godot 4.7.2 is the current stable release used as the compatibility target. The official native binary could not be downloaded into this isolated runtime, so editor/runtime/Android export validation is still required on a machine with Godot and Android SDK installed.

## Renderer resilience
- Mobile/Vulkan remains the primary Android renderer.
- RenderingDevice fallback to OpenGL 3 / Compatibility is explicitly enabled for unsupported Vulkan devices.
- Rendering pipeline cache is explicitly enabled to reduce repeat shader/pipeline setup cost where the driver supports it.
