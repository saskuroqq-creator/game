#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
GODOT="${GODOT:-$(command -v godot || command -v godot4 || true)}"
if [[ -z "$GODOT" ]]; then echo "Godot 4.7.x not found"; exit 1; fi
mkdir -p "$ROOT/build"
"$GODOT" --headless --path "$ROOT" --export-release Android "$ROOT/build/YOKAI_Shadow_of_Izanami_COMPLETE_1.0_RC1.apk"
