#!/usr/bin/env python3
"""Fail-closed license/provenance audit for YOKAI release packaging.

This does not replace legal review. It prevents accidental bundling of untracked
third-party binaries into the default release branch.
"""
from __future__ import annotations
import csv, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TP = ROOT / "assets" / "third_party"
MANIFEST = TP / "ASSET_MANIFEST.json"
LEDGER = ROOT / "ASSET_PROVENANCE_LEDGER.csv"
BINARY_EXTS = {".glb", ".gltf", ".bin", ".fbx", ".obj", ".blend", ".png", ".jpg", ".jpeg", ".webp", ".ktx", ".ktx2", ".ogg", ".wav", ".mp3", ".zip"}
DEFAULT_ALLOWED_LICENSE_PREFIXES = ("CC0",)


def norm(path: Path) -> str:
    return str(path.as_posix()).lstrip("./")


def main() -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    ledger_rows = list(csv.DictReader(LEDGER.open(encoding="utf-8")))
    destinations = {}
    for a in manifest.get("runtime_assets", []):
        if a.get("destination"):
            destinations[norm(Path(a["destination"]))] = a

    ledger_ids = {r["id"] for r in ledger_rows}
    errors = []
    tracked_binary_count = 0
    for file in TP.rglob("*"):
        if not file.is_file() or file.suffix.lower() not in BINARY_EXTS:
            continue
        rel = norm(file.relative_to(ROOT))
        asset = destinations.get(rel)
        if asset is None:
            errors.append(f"UNTRACKED third-party binary: {rel}")
            continue
        tracked_binary_count += 1
        license_name = str(asset.get("license", ""))
        if not license_name.upper().startswith(DEFAULT_ALLOWED_LICENSE_PREFIXES):
            errors.append(f"NON-WHITELISTED license for default bundle: {rel} -> {license_name}")
        if asset.get("id") not in ledger_ids:
            errors.append(f"MISSING ledger row for {asset.get('id')}: {rel}")
        if not asset.get("source"):
            errors.append(f"MISSING source URL for {asset.get('id')}: {rel}")

    if errors:
        print("YOKAI RELEASE LICENSE AUDIT: FAILED")
        for e in errors:
            print(" -", e)
        return 2
    print("YOKAI RELEASE LICENSE AUDIT: PASS")
    print(f"Tracked third-party runtime binaries currently bundled: {tracked_binary_count}")
    print("Default binary whitelist: CC0 only")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
