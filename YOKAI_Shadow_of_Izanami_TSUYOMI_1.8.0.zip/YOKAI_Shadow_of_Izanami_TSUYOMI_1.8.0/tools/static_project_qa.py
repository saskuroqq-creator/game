#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import re, sys, json, csv

ROOT = Path(__file__).resolve().parents[1]
TEXT_EXTS = {'.gd','.tscn','.tres','.godot','.cfg','.json','.csv','.shader'}
IGNORE_MISSING_PREFIXES = (
    'res://assets/third_party/',
)
errors: list[str] = []
warnings: list[str] = []


def clean_gd_line(line: str) -> str:
    out=[]; quote=None; esc=False
    for ch in line:
        if esc:
            esc=False
            if quote: out.append(' ')
            continue
        if ch=='\\' and quote:
            esc=True; out.append(' '); continue
        if quote:
            if ch==quote: quote=None
            out.append(' '); continue
        if ch in ('"', "'"):
            quote=ch; out.append(' '); continue
        if ch=='#': break
        out.append(ch)
    return ''.join(out)


def check_brackets(path: Path, text: str) -> None:
    pairs={')':'(',']':'[','}':'{'}
    stack=[]
    in_triple=None
    for lineno,line in enumerate(text.splitlines(),1):
        # Remove ordinary strings/comments. Triple strings are rare in scripts; skip their body.
        if in_triple:
            if in_triple in line:
                line=line.split(in_triple,1)[1]; in_triple=None
            else: continue
        for token in ('"""', "'''"):
            if token in line:
                before, after=line.split(token,1)
                if token in after:
                    after=after.split(token,1)[1]
                    line=before+' '+after
                else:
                    line=before; in_triple=token
                break
        code=clean_gd_line(line)
        for ch in code:
            if ch in '([{': stack.append((ch,lineno))
            elif ch in ')]}':
                if not stack or stack[-1][0] != pairs[ch]:
                    errors.append(f'{path.relative_to(ROOT)}:{lineno}: unmatched {ch}')
                    return
                stack.pop()
    if stack:
        ch,lineno=stack[-1]
        errors.append(f'{path.relative_to(ROOT)}:{lineno}: unclosed {ch}')


def check_funcs(path: Path, text: str) -> None:
    seen={}
    for lineno,line in enumerate(text.splitlines(),1):
        m=re.match(r'^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', line.strip())
        if not m: continue
        name=m.group(1)
        if name in seen:
            errors.append(f'{path.relative_to(ROOT)}:{lineno}: duplicate func {name} (first at {seen[name]})')
        else: seen[name]=lineno


def resolve_res(ref: str) -> Path:
    return ROOT / ref.removeprefix('res://')

refs_checked=0
for path in ROOT.rglob('*'):
    if not path.is_file() or path.suffix.lower() not in TEXT_EXTS: continue
    try: text=path.read_text(encoding='utf-8')
    except UnicodeDecodeError: continue
    if path.suffix.lower()=='.gd':
        check_brackets(path,text); check_funcs(path,text)
    for ref in re.findall(r'res://[^\s\"\'\)\]\},]+', text):
        ref=ref.rstrip('.,;:')
        # Runtime candidate strings under third_party are optional by design.
        if ref.startswith(IGNORE_MISSING_PREFIXES):
            continue
        refs_checked += 1
        if not resolve_res(ref).exists():
            errors.append(f'{path.relative_to(ROOT)}: missing resource {ref}')

# Project autoload resource validation.
project=(ROOT/'project.godot').read_text(encoding='utf-8')
for name,ref in re.findall(r'^([A-Za-z0-9_]+)="\*?(res://[^"]+)"$', project, flags=re.M):
    if not resolve_res(ref).exists(): errors.append(f'project.godot: autoload {name} missing {ref}')

# Manifests must parse.
for path in ROOT.rglob('*.json'):
    try: json.loads(path.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'{path.relative_to(ROOT)}: invalid JSON: {e}')
ledger=ROOT/'ASSET_PROVENANCE_LEDGER.csv'
if ledger.exists():
    try:
        rows=list(csv.DictReader(ledger.open(encoding='utf-8')))
        required={'id','source','license','bundled_in_repo','ownership_note'}
        if rows and not required.issubset(rows[0].keys()):
            errors.append('ASSET_PROVENANCE_LEDGER.csv: missing required columns')
    except Exception as e: errors.append(f'ASSET_PROVENANCE_LEDGER.csv: {e}')

# Required mobile production components.
for ref in [
    'res://scripts/mobile_quality_manager.gd',
    'res://scripts/mobile_vfx_budget.gd',
    'res://scripts/mobile_art_optimizer.gd',
    'res://scripts/character_asset_loader.gd',
    'res://scripts/enemy_asset_loader.gd',
]:
    if not resolve_res(ref).exists(): errors.append(f'required component missing {ref}')

print('YOKAI STATIC PROJECT QA')
print(f'Files scanned: {sum(1 for p in ROOT.rglob("*") if p.is_file())}')
print(f'Resource references checked: {refs_checked}')
print(f'Warnings: {len(warnings)}')
for w in warnings: print('WARN:',w)
print(f'Errors: {len(errors)}')
for e in errors[:100]: print('ERROR:',e)
if errors:
    sys.exit(1)
print('RESULT: PASS')
