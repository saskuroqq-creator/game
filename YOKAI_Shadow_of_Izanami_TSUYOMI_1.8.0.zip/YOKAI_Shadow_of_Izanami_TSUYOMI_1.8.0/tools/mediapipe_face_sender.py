#!/usr/bin/env python3
"""Webcam -> YOKAI facial blendshape UDP sender.

Dependencies (user-side):
  pip install mediapipe opencv-python

Requires an official MediaPipe Face Landmarker .task model supplied with --model.
No model binary is redistributed by YOKAI.
"""
import argparse, json, socket, time


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', required=True, help='Path to MediaPipe face_landmarker.task')
    ap.add_argument('--camera', type=int, default=0)
    ap.add_argument('--host', default='127.0.0.1')
    ap.add_argument('--port', type=int, default=17171)
    args = ap.parse_args()

    import cv2
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision

    options = vision.FaceLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=args.model),
        running_mode=vision.RunningMode.VIDEO,
        num_faces=1,
        output_face_blendshapes=True,
        output_facial_transformation_matrixes=False,
    )
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise SystemExit('Could not open camera')

    start = time.monotonic()
    with vision.FaceLandmarker.create_from_options(options) as landmarker:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
            timestamp_ms = int((time.monotonic() - start) * 1000)
            result = landmarker.detect_for_video(image, timestamp_ms)
            if result.face_blendshapes:
                weights = {
                    str(category.category_name): float(category.score)
                    for category in result.face_blendshapes[0]
                    if category.category_name
                }
                packet = json.dumps({'blendshapes': weights}, separators=(',', ':')).encode('utf-8')
                sock.sendto(packet, (args.host, args.port))
            cv2.imshow('YOKAI Facial Capture - ESC to quit', frame)
            if cv2.waitKey(1) & 0xFF == 27:
                break
    cap.release()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
