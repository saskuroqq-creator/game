#!/usr/bin/env python3
"""YOKAI CC0 art bootstrapper.

Downloads only redistributable CC0 assets used by the default SHINRA art layer.
The script intentionally does not scrape paid tiers or restricted marketplaces.
Run it from the project root before opening Godot so imported GLBs are available
as PackedScenes on the next editor launch.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "assets" / "third_party" / "ASSET_MANIFEST.json"
UA = "YOKAI-CC0-Asset-Bootstrap/1.6 (+Godot project; contact local developer)"

RECEIPTS = ROOT / "assets" / "third_party" / "DOWNLOAD_RECEIPTS.json"

ITCH = {
    "ual1": {
        "endpoint": "https://quaternius.itch.io/universal-animation-library/file/17958403?source=game_download&as_props=1",
        "sha256": "cc73fc4e495b82958207316596317a3f40b9fa38065bde1027937452da537724",
        "dest": ROOT / "assets" / "third_party" / "animations" / "UAL1_Standard.zip",
    },
    "ual2": {
        "endpoint": "https://quaternius.itch.io/universal-animation-library-2/file/17958478?source=game_download&as_props=1",
        "sha256": "4008ea208a604773a2b2177d965f0f5d3195498b5bf838c3f5785d68e95f2a68",
        "dest": ROOT / "assets" / "third_party" / "animations" / "UAL2_Standard.zip",
    },
}


def request(url: str, method: str = "GET") -> urllib.request.Request:
    return urllib.request.Request(url, method=method, headers={"User-Agent": UA})


def download(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    print(f"[download] {url}\n          -> {dest.relative_to(ROOT)}")
    with urllib.request.urlopen(request(url), timeout=120) as src, tmp.open("wb") as out:
        shutil.copyfileobj(src, out)
    tmp.replace(dest)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _load_receipts() -> dict:
    if RECEIPTS.exists():
        try:
            return json.loads(RECEIPTS.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"schema": 1, "generated_by": "YOKAI SHINRA 1.6 bootstrapper", "files": {}}


def record_receipt(asset_id: str, path: Path, source: str, license_name: str) -> None:
    receipts = _load_receipts()
    receipts.setdefault("files", {})[asset_id] = {
        "path": str(path.relative_to(ROOT)).replace("\\", "/"),
        "source": source,
        "license": license_name,
        "sha256": sha256(path),
        "bytes": path.stat().st_size,
    }
    RECEIPTS.write_text(json.dumps(receipts, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def fetch_manifest_assets() -> None:
    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    for asset in data.get("runtime_assets", []):
        if not asset.get("auto_fetch"):
            continue
        license_name = str(asset.get("license", "")).upper()
        if not license_name.startswith("CC0"):
            raise RuntimeError(f"Refusing auto-fetch of non-CC0 asset: {asset.get('id')} ({license_name})")
        dest = ROOT / asset["destination"]
        if dest.exists() and dest.stat().st_size > 1024:
            print(f"[keep] {dest.relative_to(ROOT)}")
        else:
            download(asset["download"], dest)
        record_receipt(asset["id"], dest, asset["source"], asset["license"])


def fetch_itch_free(key: str) -> None:
    item = ITCH[key]
    dest: Path = item["dest"]
    if dest.exists() and sha256(dest) == item["sha256"]:
        print(f"[keep] {dest.relative_to(ROOT)} (sha256 ok)")
        return
    print(f"[itch] resolving signed free-download URL for {key.upper()}")
    with urllib.request.urlopen(request(item["endpoint"], method="POST"), timeout=60) as resp:
        payload = json.loads(resp.read().decode("utf-8"))
    url = payload.get("url")
    if not url:
        raise RuntimeError(f"itch.io did not return a download URL for {key}: {payload}")
    download(url, dest)
    digest = sha256(dest)
    if digest != item["sha256"]:
        raise RuntimeError(f"SHA256 mismatch for {dest.name}: {digest}")
    print(f"[ok] {dest.name} sha256 verified")


def extract_godot_glbs(zip_path: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        candidates = [n for n in zf.namelist() if n.lower().endswith((".glb", ".gltf", ".bin", ".png", ".jpg", ".jpeg"))]
        for name in candidates:
            lower = name.lower()
            # Prefer the publisher's Godot/Unreal glTF path, but keep required
            # sidecar files if the archive uses .gltf rather than .glb.
            if "godot" not in lower and "unreal" not in lower and not lower.endswith(".glb"):
                continue
            target = out_dir / Path(name).name
            if target.exists():
                continue
            with zf.open(name) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            print(f"[extract] {target.relative_to(ROOT)}")


def write_license_notes() -> None:
    license_dir = ROOT / "assets" / "third_party" / "licenses"
    license_dir.mkdir(parents=True, exist_ok=True)
    (license_dir / "README.txt").write_text(
        "YOKAI third-party art policy\n\n"
        "Default vendored environment/prop assets: CC0 1.0.\n"
        "Quaternius Universal Animation Library 1/2 Standard: CC0 1.0.\n"
        "Quaternius Universal Base Characters Standard: CC0 1.0 (manual large download).\n"
        "Poly Haven assets: CC0 1.0 (add individually after art direction review).\n"
        "MakeHuman/MPFB core graphical assets and exported output: CC0.\n\n"
        "See ../ASSET_MANIFEST.json and THIRD_PARTY_ART_PIPELINE.md for source URLs.\n",
        encoding="utf-8",
    )


def main() -> int:
    os.chdir(ROOT)
    print("YOKAI SHINRA 1.6 — CC0 art bootstrap")
    print(f"Project: {ROOT}")
    fetch_manifest_assets()
    for key in ("ual1", "ual2"):
        try:
            fetch_itch_free(key)
            extract_godot_glbs(ITCH[key]["dest"], ROOT / "assets" / "third_party" / "animations" / key.upper())
        except Exception as exc:
            # World art still installs even if itch temporarily changes its signed-link endpoint.
            print(f"[warning] {key}: {exc}", file=sys.stderr)
    write_license_notes()
    print("\nDone. Re-open Godot so it imports new GLB/GLTF files.")
    print("For the playable humanoid base, download Quaternius Universal Base Characters Standard")
    print("and copy a Godot/UE male or female .gltf + sidecars into assets/third_party/characters/quaternius/.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
