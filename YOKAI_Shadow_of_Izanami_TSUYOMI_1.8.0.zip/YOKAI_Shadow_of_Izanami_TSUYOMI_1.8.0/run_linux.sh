#!/usr/bin/env bash
set -euo pipefail
GODOT="${GODOT:-$(command -v godot || command -v godot4 || true)}"
if [[ -z "$GODOT" ]]; then echo "Godot 4.7.x not found"; exit 1; fi
"$GODOT" --editor --path "$(cd "$(dirname "$0")" && pwd)"
