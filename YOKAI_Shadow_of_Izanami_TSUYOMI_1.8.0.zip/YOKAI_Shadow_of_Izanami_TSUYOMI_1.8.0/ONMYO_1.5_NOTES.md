# ONMYO 1.5.0 — Art Foundation

- CC0-first production-art manifest.
- Hero GLB loader + fuzzy animation bridge + UAL library merger.
- Facial blendshape bridge with combat expression hooks.
- Enemy/boss authored-model socket with procedural fallback.
- Setting-safe Feudal Japan authored world layer; Korean pagoda removed.
- Automated CC0 bootstrapper for 3DAssets + UAL1/UAL2.
- Curated Poly Haven realism surfaces and CMU mocap path documented.
- No gameplay/network logic depends on any third-party mesh.
