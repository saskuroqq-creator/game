# YOKAI — Production Art Pipeline (ONMYO 1.5)

## Art direction lock
The project now uses a **CC0-first** replacement pipeline so production art can be swapped in without touching combat/network code.

Visual target: grounded dark Sengoku-fantasy, wet stone, moss, soot-black lacquer, oxidized vermilion, dirty bronze, indigo cloth, moon-blue fog and restrained spirit cyan/magenta accents.

Avoid by default: glossy anime plastic, neon cyberpunk, generic European plate armor, Chinese/Korean architectural pieces in Japanese sacred spaces, oversized MMO weapons, saturated fantasy foliage.

## Playable hunter — free route
1. **Quaternius Universal Base Characters (CC0)** is the clean reference skeleton.
2. **Quaternius UAL1 + UAL2 (CC0)** supplies locomotion, dodge and melee animation libraries.
3. **LOWPO Samurai Free (CC0)** is the best setting-matched rigged interim samurai shell. Retarget to the YOKAI/UAL humanoid skeleton instead of replacing gameplay code.
4. **MakeHuman / MPFB** can generate a more realistic body/face base. Exported output/core assets can be used commercially; retarget the final mesh in Blender to the YOKAI humanoid skeleton.
5. A hero-quality sculpt can later replace only the skin/clothing meshes. Keep the skeleton contract and the game code stays unchanged.

Canonical hero drop-in paths:
- `assets/third_party/characters/player_hunter.glb`
- `assets/third_party/characters/player_hunter.gltf`

## Animation contract
Run `INSTALL_FREE_ART_WINDOWS.bat` (or `install_free_art_linux.sh`). It vendors UAL1/UAL2 Standard into the project. `ExternalAnimationImporter` merges compatible bone tracks into the hero AnimationPlayer; `AnimationBridge` fuzzy-matches gameplay semantics (`attack1`, `dodge`, `parry`, etc.).

Combat remains code-driven/root-motion-off by default so multiplayer hit timing stays deterministic. Root-motion can be enabled later per finisher/cinematic.

## Enemies / bosses
`EnemyAssetLoader` maps canonical GLB names to existing AI actors. Put final art here:
- `enemies/oni.glb`
- `enemies/tengu.glb`
- `enemies/wraith.glb`
- `enemies/specter.glb`
- `enemies/namahage.glb`
- `enemies/kitsune_shade.glb`
- `enemies/boss_jorogumo.glb`
- `enemies/boss_karasu_tengu.glb`
- `enemies/boss_gashadokuro.glb`
- `enemies/boss_orochi.glb`
- `enemies/boss_nure_onna.glb`
- `enemies/boss_namahage.glb`
- `enemies/boss_izanami_shadow.glb`

The loader hides proxy geometry while preserving CharacterBody3D collision, AI, health, stagger, networking and loot.

Quaternius Ultimate Monsters / Animated Monster Pack are CC0 and useful as **animation/rig donors**, but generic fantasy silhouettes should be remodeled before shipping so the game still reads as Japanese yokai rather than a stock fantasy pack.

## World dressing
`tools/fetch_cc0_art.py` auto-vendors setting-safe CC0 GLBs from 3DAssets.dev:
- Feudal Japan castle / moat / market / torii / shrine scene.
- Feudal Japan stealth rooftop route.
- Katana + saya prop.
- Samurai ancestor memory NPC.

The previously considered Korean stone pagoda is deliberately **not used** in ONMYO because it weakens setting accuracy.

Use Poly Haven CC0 materials for the realism pass: mossy rock, mossy forest floor, moss wood, worn rock tiles, mossy rock sets. Keep 2K in gameplay, 4K for hero assets/cinematics; do not ship 8K everywhere.

## Facial performance
`FacialBlendshapeBridge` accepts ARKit/MediaPipe-style blendshape names and now reacts to combat states (focus, pain, battle cry, calm). Final hero meshes should include facial blendshapes.

Recommended capture sources:
- MediaPipe Face Landmarker — Apache 2.0.
- OpenSeeFace — BSD-2-Clause.

Use these as capture/authoring inputs, not as a required runtime dependency for the shipped game.

## Mocap
Primary gameplay combat: UAL + hand-tuned timing.
Secondary cinematic/NPC motion: CMU Motion Capture Database. It contains thousands of captures and permits use in commercial products; do not redistribute/resell the raw database as a standalone asset product. Retarget and bake only cleaned clips needed by the game.

## Production rule
Never let an asset pack dictate mechanics or story. Every external asset enters through a socket/bridge and can be replaced independently. This is what keeps the project ready for later bespoke high-poly sculpts and professional mocap without a rewrite.
